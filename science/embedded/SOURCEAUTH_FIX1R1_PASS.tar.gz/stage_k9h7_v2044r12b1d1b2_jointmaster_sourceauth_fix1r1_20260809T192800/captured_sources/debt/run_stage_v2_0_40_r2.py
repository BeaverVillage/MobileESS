#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

VERSION = "2.0.40-r2"
STAGE = "CANDIDATE_BOUND_FORECAST_RESERVE_WAN_DEBT_CLOSURE_V2_0_40_R2"
POLICY_ID = "SAFE_LOCAL_EDF_WAIT060_QOSR05_ROLLING_HORIZON"
NOMINAL_POLICY_ID = "SENS_WAIT060_QOSR05"
STEP_HOURS = 5.0 / 60.0
TOL = 1e-9

EXPECTED = {
    "v2039": {
        "file": "Conversation1_Final_Integration_Checkpoint_V2039_20260806T2015KST.zip",
        "sha256": "84a2c95ddcd0ed68bff42a3b11b97b2ec1ddfdd007b2a7e5d40088c3b654919c",
    },
    "wan_pre": {
        "file": "Conversation1_WAN_Debt_Preintegration_Handoff_20260806T1743KST.zip",
        "sha256": "165b7612f025d9d2321794f0828078f4c1748fd094a14c5531366eaf0c041303",
    },
    "current_rack": {
        "file": "result_stage_current_rack_idle_static_power_binding_v2_0_33d_20260806T064841Z.tar.gz",
        "sha256": "69999aea05db38ffcd44603734166e7d643892d0d42bd3f8f63c4008cd9ead8b",
    },
    "v2036": {
        "file": "result_stage_offset0_integrated_fallback_candidate_v2_0_36_r2_20260806T093554Z.tar.gz",
        "sha256": "3c08ca2f404d8641a094d320ae0053f7730699daae9b5aea720f4d1b6131afb4",
    },
    "commitment_engine_result": {
        "file": "result_stage_completion_horizon_commitment_rack_oracle_v2_0_34_20260806T070132Z.tar.gz",
        "sha256": "96fa3db997e52e93bcf8e095d312599ad8ad86af7290cc423f9e653100e42fff",
    },
}
REQUIRED_FIXED_SIDECAR = {
    "source_scope": "FIXED_WORKLOAD_ONLY_EXCLUDES_RUNNING_NEW_AND_FORECAST_RESERVE",
    "quantile_semantics": "Q95_OR_MORE_CONSERVATIVE",
    "logical_pool_semantics": "48_EQUIVALENT_RACK_POOLS",
    "time_contract": "OFFSET0_5MIN_FIXED_AEST_UTC10",
    "measurement_claim": False,
    "double_count_audit_pass": True,
}
CANDIDATE_COLUMNS = [
    "candidate_id", "job_uid", "destination_idc_id", "start_step",
    "first_step_start", "rack_pool_id", "requested_gpu", "IT_power_kW",
    "nonpreemptive_duration_steps", "latest_start_step",
    "latest_completion_step_exclusive",
]
BASELINE_COLUMNS = [
    "oracle_step", "rack_pool_id", "fixed_gpu_robust",
    "fixed_it_power_kw_robust", "forecast_reserve_gpu",
    "forecast_reserve_it_power_kw",
]

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def json_safe(x: Any) -> Any:
    if x is None or isinstance(x, (str, int, bool)):
        return x
    if isinstance(x, float):
        return x if math.isfinite(x) else None
    if isinstance(x, Path):
        return str(x)
    if isinstance(x, dict):
        return {str(k): json_safe(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, set)):
        return [json_safe(v) for v in x]
    if hasattr(x, "item"):
        try:
            return json_safe(x.item())
        except Exception:
            pass
    if hasattr(x, "isoformat"):
        try:
            return x.isoformat()
        except Exception:
            pass
    return str(x)

def atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(json_safe(obj), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    tmp.replace(path)

def atomic_csv(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_csv(tmp, index=False, float_format="%.12g", lineterminator="\n")
    tmp.replace(path)

def atomic_csv_gz(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_csv(tmp, index=False, float_format="%.12g", compression="gzip", lineterminator="\n")
    tmp.replace(path)

def safe_extract_zip(src: Path, dst: Path) -> Path:
    dst.mkdir(parents=True, exist_ok=True)
    root = dst.resolve()
    with zipfile.ZipFile(src, "r") as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"ZIP CRC failure: {src.name}:{bad}")
        for info in zf.infolist():
            target = (dst / info.filename).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError(f"Unsafe ZIP member: {info.filename}")
        zf.extractall(dst)
    roots = [p for p in dst.iterdir() if p.is_dir()]
    if len(roots) != 1:
        raise RuntimeError(f"Expected one ZIP root in {src.name}, got {len(roots)}")
    return roots[0]

def safe_extract_tar(src: Path, dst: Path) -> Path:
    dst.mkdir(parents=True, exist_ok=True)
    root = dst.resolve()
    with tarfile.open(src, "r:gz") as tf:
        for member in tf.getmembers():
            target = (dst / member.name).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError(f"Unsafe TAR member: {member.name}")
        tf.extractall(dst, filter="data")
    roots = [p for p in dst.iterdir() if p.is_dir()]
    if len(roots) != 1:
        raise RuntimeError(f"Expected one TAR root in {src.name}, got {len(roots)}")
    return roots[0]

def verify_checksums(root: Path) -> dict[str, Any]:
    manifest = root / "CHECKSUMS.sha256"
    if not manifest.is_file():
        return {"pass": False, "checked": 0, "mismatches": ["missing CHECKSUMS.sha256"]}
    mismatches = []
    checked = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, rel = line.split(None, 1)
        rel = rel.lstrip("* ")
        target = root / rel
        actual = sha256(target) if target.is_file() else "MISSING"
        if actual != expected:
            mismatches.append({"path": rel, "expected": expected, "actual": actual})
        checked += 1
    return {"pass": not mismatches, "checked": checked, "mismatches": mismatches}

def locate_exact_reference(package_root: Path, key: str) -> Path:
    spec = EXPECTED[key]
    path = package_root / "reference" / spec["file"]
    if not path.is_file():
        raise RuntimeError(f"Missing exact reference: {spec['file']}")
    actual = sha256(path)
    if actual != spec["sha256"]:
        raise RuntimeError(f"{key} SHA mismatch: {actual}")
    return path

def import_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    if spec.loader is None:
        raise RuntimeError(f"Cannot load module: {path}")
    spec.loader.exec_module(module)
    return module

def validate_parquet_dependency() -> None:
    try:
        import pyarrow  # noqa: F401
    except Exception as exc:
        raise RuntimeError(
            "pyarrow is required. Use the existing project conda environment that previously "
            "created/read the WAN Parquet parents."
        ) from exc

def load_parents(package_root: Path, work: Path) -> dict[str, Any]:
    refs = {k: locate_exact_reference(package_root, k) for k in EXPECTED}
    roots = {
        "v2039": safe_extract_zip(refs["v2039"], work / "v2039"),
        "wan_pre": safe_extract_zip(refs["wan_pre"], work / "wan_pre"),
        "current_rack": safe_extract_tar(refs["current_rack"], work / "current_rack"),
        "v2036": safe_extract_tar(refs["v2036"], work / "v2036"),
        "commitment_engine_result": safe_extract_tar(
            refs["commitment_engine_result"], work / "commitment_engine_result"
        ),
    }
    checks = {}
    for key, root in roots.items():
        checks[key] = verify_checksums(root)
        if not checks[key]["pass"]:
            raise RuntimeError(f"{key} internal checksum failure: {checks[key]['mismatches'][:3]}")
    v2039_result = json.loads((roots["v2039"] / "_RESULT.json").read_text(encoding="utf-8"))
    ledger = json.loads(
        (roots["v2039"] / "GLOBAL_STATUS_LEDGER_V2_0_39.json").read_text(encoding="utf-8")
    )
    if v2039_result.get("fresh_exact_ac_gate_pass") is not True:
        raise RuntimeError("V2039 Fresh exact AC Gate is not PASS")
    if ledger["gates"]["current_rack"]["status"] != "PASS":
        raise RuntimeError("V2039 Current Rack Gate is not PASS")
    return {"refs": refs, "roots": roots, "checks": checks, "v2039_result": v2039_result, "ledger": ledger}

def require_columns(df: pd.DataFrame, columns: list[str], label: str) -> None:
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise RuntimeError(f"{label} missing columns: {missing}")

def load_source_tables(wan_root: Path) -> dict[str, pd.DataFrame]:
    validate_parquet_dependency()
    key = wan_root / "key_inputs"
    reserve = pd.read_parquet(key / "COMMITMENT_FORECAST_RESERVE_PER_JOB_SOURCE_A4.parquet", engine="pyarrow")
    immutable = pd.read_parquet(key / "JOB_WAN_IMMUTABLE_INPUT_A2.parquet", engine="pyarrow")
    debt = pd.read_parquet(key / "DEBT_DEADLINE_PER_JOB_EXOGENOUS_INPUT_A3.parquet", engine="pyarrow")
    running_wan = pd.read_parquet(key / "OFFSET0_EXISTING_RUNNING_JOB_WAN_BYPASS_A3.parquet", engine="pyarrow")
    policies = pd.read_csv(key / "DEBT_REBOUND_9_POLICY_REGISTRY_A3.csv")
    factor = pd.read_csv(key / "WAN_COMMON_PUBLIC_RUNTIME_FACTOR_A3.csv.gz")
    od = pd.read_csv(key / "WAN_OD_SET_AND_BINDING_STATUS_A3.csv")

    require_columns(reserve, [
        "job_uid", "origin_IDC_id", "arrival_step", "latest_start_step",
        "latest_completion_step_exclusive", "nonpreemptive_duration_steps",
        "forecast_reserve_gpu_source", "forecast_reserve_it_power_kw_source",
        "binding_status", "reserve_semantics",
    ], "reserve")
    require_columns(immutable, [
        "job_uid", "origin_IDC_id", "arrival_step", "latest_start_step",
        "latest_completion_step_exclusive", "nonpreemptive_duration_steps",
        "requested_gpu", "input_size_GB", "existing_running_at_offset0",
    ], "immutable")
    require_columns(debt, [
        "job_uid", "hard_deadline_misses_allowed",
        "nominal_debt_rebound_policy_id", "initial_workload_debt_gpuh",
    ], "debt")
    require_columns(running_wan, [
        "job_uid", "origin_IDC_id", "remaining_runtime_steps_at_offset0",
        "requested_gpu", "wan_transfer_required_at_offset0",
    ], "running_wan")
    require_columns(policies, [
        "policy_id", "wait_token", "qosr_token", "nominal_selected",
        "hard_deadline_misses_allowed", "selection_is_posthoc",
    ], "policies")
    if len(reserve) != 59901 or reserve["job_uid"].nunique() != 59901:
        raise RuntimeError("Reserve source cardinality is not 59,901 unique Jobs")
    if len(immutable) != 59901 or immutable["job_uid"].nunique() != 59901:
        raise RuntimeError("Immutable source cardinality is not 59,901 unique Jobs")
    if len(debt) != 59901 or debt["job_uid"].nunique() != 59901:
        raise RuntimeError("Debt source cardinality is not 59,901 unique Jobs")
    if len(running_wan) != 9 or running_wan["job_uid"].nunique() != 9:
        raise RuntimeError("Offset-0 running WAN bypass is not 9 unique Jobs")
    if running_wan["wan_transfer_required_at_offset0"].astype(bool).any():
        raise RuntimeError("An Offset-0 running Job unexpectedly requires WAN transfer")
    nominal = policies[policies["nominal_selected"].astype(bool)]
    if len(nominal) != 1 or str(nominal.iloc[0]["policy_id"]) != NOMINAL_POLICY_ID:
        raise RuntimeError("Nominal debt/rebound policy is not uniquely SENS_WAIT060_QOSR05")
    if policies["selection_is_posthoc"].astype(bool).any():
        raise RuntimeError("Policy registry contains post-hoc selection")
    if int(nominal.iloc[0]["hard_deadline_misses_allowed"]) != 0:
        raise RuntimeError("Nominal policy allows deadline misses")
    if len(factor) != 105120:
        raise RuntimeError("WAN runtime factor does not have 105,120 rows")
    if len(od) != 144:
        raise RuntimeError("WAN OD set does not have 144 rows")
    return {
        "reserve": reserve,
        "immutable": immutable,
        "debt": debt,
        "running_wan": running_wan,
        "policies": policies,
        "factor": factor,
        "od": od,
    }

def build_future_jobs(tables: dict[str, pd.DataFrame]) -> pd.DataFrame:
    reserve = tables["reserve"].copy()
    immutable = tables["immutable"].copy()
    debt = tables["debt"].copy()
    jobs = reserve[[
        "job_uid", "origin_IDC_id", "arrival_step", "latest_start_step",
        "latest_completion_step_exclusive", "nonpreemptive_duration_steps",
        "forecast_reserve_gpu_source", "forecast_reserve_it_power_kw_source",
        "binding_status", "reserve_semantics",
    ]].merge(
        immutable[[
            "job_uid", "requested_gpu", "input_size_GB",
            "existing_running_at_offset0",
        ]],
        on="job_uid", how="inner", validate="one_to_one",
    ).merge(
        debt[[
            "job_uid", "hard_deadline_misses_allowed",
            "nominal_debt_rebound_policy_id", "initial_workload_debt_gpuh",
        ]],
        on="job_uid", how="inner", validate="one_to_one",
    )
    for c in [
        "arrival_step", "latest_start_step", "latest_completion_step_exclusive",
        "nonpreemptive_duration_steps",
    ]:
        jobs[c] = pd.to_numeric(jobs[c], errors="raise").astype("int64")
    for c in [
        "forecast_reserve_gpu_source", "forecast_reserve_it_power_kw_source",
        "requested_gpu", "input_size_GB", "initial_workload_debt_gpuh",
    ]:
        jobs[c] = pd.to_numeric(jobs[c], errors="raise")
    if jobs["job_uid"].duplicated().any():
        raise RuntimeError("Future Job table has duplicate UID")
    if not np.allclose(
        jobs["requested_gpu"], jobs["forecast_reserve_gpu_source"], rtol=0, atol=1e-9
    ):
        raise RuntimeError("Requested GPU and forecast-reserve GPU source differ")
    if jobs["existing_running_at_offset0"].astype(bool).any():
        raise RuntimeError("Future F30 population contains Offset-0 running Jobs")
    if (jobs["hard_deadline_misses_allowed"] != 0).any():
        raise RuntimeError("A future Job allows hard-deadline misses")
    if set(jobs["nominal_debt_rebound_policy_id"].astype(str)) != {NOMINAL_POLICY_ID}:
        raise RuntimeError("Future Jobs do not share the frozen nominal policy")
    if (jobs["forecast_reserve_gpu_source"] <= 0).any():
        raise RuntimeError("Nonpositive forecast-reserve GPU source")
    if (jobs["forecast_reserve_it_power_kw_source"] <= 0).any():
        raise RuntimeError("Nonpositive forecast-reserve IT power source")
    jobs["IT_power_kW"] = jobs["forecast_reserve_it_power_kw_source"]
    jobs["requested_gpu"] = jobs["forecast_reserve_gpu_source"]
    jobs["effective_latest_start_step"] = np.minimum(
        jobs["latest_start_step"],
        jobs["latest_completion_step_exclusive"] - jobs["nonpreemptive_duration_steps"],
    )
    if (jobs["effective_latest_start_step"] < jobs["arrival_step"]).any():
        bad = jobs.loc[
            jobs["effective_latest_start_step"] < jobs["arrival_step"],
            ["job_uid", "arrival_step", "effective_latest_start_step"],
        ].head(10)
        raise RuntimeError(f"Deadline before arrival: {bad.to_dict('records')}")
    return jobs

def load_rack_inputs(roots: dict[str, Path]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    pools = pd.read_csv(
        roots["current_rack"] / "CURRENT_RACK_OFFSET0_LOGICAL_POOL_FULL_POWER_STATE_V2_0_33D.csv"
    )
    running = pd.read_csv(roots["v2036"] / "EXISTING_RUNNING_INTERVALS.csv")
    base = pd.read_csv(roots["v2036"] / "COMMITMENT_BASELINE_FALLBACK_CONTINUATION.csv")
    require_columns(pools, [
        "idc_id", "rack_pool_id", "pool_index", "gpu_capacity",
        "rack_power_cap_kw_pool",
    ], "pools")
    require_columns(running, [
        "job_uid", "rack_pool_id", "remaining_duration_steps",
        "requested_gpu", "IT_power_kW",
    ], "running")
    require_columns(base, BASELINE_COLUMNS, "continuation baseline")
    if len(pools) != 48 or pools["rack_pool_id"].nunique() != 48:
        raise RuntimeError("Current Rack parent is not 48 unique logical pools")
    if len(running) != 9 or running["job_uid"].nunique() != 9:
        raise RuntimeError("Existing-running intervals are not 9 unique Jobs")
    if running["remaining_duration_steps"].max() != 134:
        raise RuntimeError("Expected 134-step maximum existing-running interval")
    if base["oracle_step"].nunique() != 134 or len(base) != 134 * 48:
        raise RuntimeError("Continuation baseline is not 134×48")
    for c in ["gpu_capacity", "rack_power_cap_kw_pool"]:
        pools[c] = pd.to_numeric(pools[c], errors="raise")
    for c in ["remaining_duration_steps", "requested_gpu", "IT_power_kW"]:
        running[c] = pd.to_numeric(running[c], errors="raise")
    for c in [
        "oracle_step", "fixed_gpu_robust", "fixed_it_power_kw_robust",
        "forecast_reserve_gpu", "forecast_reserve_it_power_kw",
    ]:
        base[c] = pd.to_numeric(base[c], errors="raise")
    return pools, running, base

def load_table(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".parquet", ".pq"}:
        validate_parquet_dependency()
        return pd.read_parquet(path, engine="pyarrow")
    raise RuntimeError(f"Unsupported fixed envelope format: {path}")

def resolve_fixed_envelope(
    package_root: Path,
    pools: pd.DataFrame,
    continuation: pd.DataFrame,
    horizon: int,
) -> tuple[pd.DataFrame, dict[str, Any], pd.DataFrame]:
    census_rows = []
    data_env = os.environ.get("MOBILE_ESS_FIXED_ROBUST_POOL_ENVELOPE", "").strip()
    contract_env = os.environ.get("MOBILE_ESS_FIXED_ROBUST_POOL_ENVELOPE_CONTRACT", "").strip()
    p7_contract = json.loads(
        (package_root / "reference" / "P7A3F1AV102_RACK_SOURCE_CONTRACT.json").read_text(
            encoding="utf-8"
        )
    )
    p7_join = json.loads(
        (package_root / "reference" / "P7A3F1AV102_RACK_SOURCE_JOIN_AUDIT.json").read_text(
            encoding="utf-8"
        )
    )
    census_rows.append({
        "source_id": "P7A3F1AV102_COMMITMENT_SPARSE",
        "path": str(p7_join.get("output_hashes", {}).get(
            "P7A3F1AV102_COMMITMENT_RACK_SOURCE_SPARSE.parquet", ""
        )),
        "schema_scope": "IDC_POLICY_QOS_AGGREGATE_NOT_LOGICAL_POOL",
        "accepted": False,
        "rejection_reason": (
            "P7 contract explicitly has final_commitment_rack_complete=false and lacks "
            "authoritative per-pool fixed-workload separation."
        ),
    })
    if not data_env and not contract_env:
        audit = {
            "final_fixed_robust_envelope_complete": False,
            "binding_mode": "CURRENT_RACK_CONTINUATION_DIAGNOSTIC_ONLY",
            "reason": "No exact fixed robust pool envelope and sidecar were supplied.",
            "P7_final_commitment_rack_complete": p7_contract.get("final_commitment_rack_complete"),
            "P7_debt_rebound_implementation_complete": p7_contract.get(
                "debt_rebound_implementation_complete"
            ),
            "coverage_horizon_steps": int(continuation["oracle_step"].max()) + 1,
            "used_current_continuation_fallback": True,
            "double_count_claim": False,
        }
        fixed = continuation[[
            "oracle_step", "rack_pool_id", "fixed_gpu_robust",
            "fixed_it_power_kw_robust",
        ]].copy()
        return fixed, audit, pd.DataFrame(census_rows)
    if not data_env or not contract_env:
        raise RuntimeError(
            "Both MOBILE_ESS_FIXED_ROBUST_POOL_ENVELOPE and "
            "MOBILE_ESS_FIXED_ROBUST_POOL_ENVELOPE_CONTRACT are required together"
        )
    data_path = Path(data_env).expanduser().resolve()
    contract_path = Path(contract_env).expanduser().resolve()
    if not data_path.is_file() or not contract_path.is_file():
        raise RuntimeError("Fixed robust envelope data or sidecar path does not exist")
    sidecar = json.loads(contract_path.read_text(encoding="utf-8"))
    mismatches = {
        key: {"expected": expected, "actual": sidecar.get(key)}
        for key, expected in REQUIRED_FIXED_SIDECAR.items()
        if sidecar.get(key) != expected
    }
    if mismatches:
        raise RuntimeError(f"Fixed robust envelope sidecar mismatch: {mismatches}")
    df = load_table(data_path)
    required = [
        "oracle_step", "rack_pool_id", "fixed_gpu_robust",
        "fixed_it_power_kw_robust",
    ]
    require_columns(df, required, "fixed robust envelope")
    x = df[required].copy()
    x["oracle_step"] = pd.to_numeric(x["oracle_step"], errors="raise").astype("int64")
    for c in ["fixed_gpu_robust", "fixed_it_power_kw_robust"]:
        x[c] = pd.to_numeric(x[c], errors="raise")
    x["rack_pool_id"] = x["rack_pool_id"].astype(str)
    x = x[x["oracle_step"] >= 0].copy()
    if x.duplicated(["oracle_step", "rack_pool_id"]).any():
        raise RuntimeError("Fixed robust envelope has duplicate step-pool keys")
    valid_pools = set(pools["rack_pool_id"].astype(str))
    unknown_pools = set(x["rack_pool_id"]) - valid_pools
    if unknown_pools:
        raise RuntimeError(f"Fixed robust envelope contains unknown pools: {sorted(unknown_pools)[:10]}")
    expected_minimum = {
        (s, p) for s in range(horizon) for p in valid_pools
    }
    observed = set(zip(x["oracle_step"], x["rack_pool_id"]))
    missing = expected_minimum - observed
    if missing:
        raise RuntimeError(
            f"Fixed robust envelope lacks {len(missing)} required step-pool rows "
            f"through step {horizon - 1}"
        )
    if (x[["fixed_gpu_robust", "fixed_it_power_kw_robust"]] < 0).any().any():
        raise RuntimeError("Fixed robust envelope contains negative values")
    caps = pools.set_index("rack_pool_id")
    merged = x.merge(
        pools[["rack_pool_id", "gpu_capacity", "rack_power_cap_kw_pool"]],
        on="rack_pool_id", how="left", validate="many_to_one",
    )
    if (merged["fixed_gpu_robust"] > merged["gpu_capacity"] + TOL).any():
        raise RuntimeError("Fixed robust GPU envelope exceeds pool capacity before Jobs")
    if (merged["fixed_it_power_kw_robust"] > merged["rack_power_cap_kw_pool"] + TOL).any():
        raise RuntimeError("Fixed robust power envelope exceeds pool capacity before Jobs")
    census_rows.append({
        "source_id": "USER_SUPPLIED_EXACT_FIXED_ROBUST_POOL_ENVELOPE",
        "path": str(data_path),
        "schema_scope": "48_LOGICAL_POOL_FIXED_ONLY",
        "accepted": True,
        "rejection_reason": "",
    })
    audit = {
        "final_fixed_robust_envelope_complete": True,
        "binding_mode": "USER_SUPPLIED_EXACT_SHA_BOUND_POOL_ENVELOPE",
        "data_path": str(data_path),
        "data_sha256": sha256(data_path),
        "sidecar_path": str(contract_path),
        "sidecar_sha256": sha256(contract_path),
        "sidecar": sidecar,
        "coverage_horizon_steps": int(x["oracle_step"].max()) + 1,
        "used_current_continuation_fallback": False,
        "double_count_claim": False,
    }
    return x.sort_values(["oracle_step", "rack_pool_id"]).reset_index(drop=True), audit, pd.DataFrame(census_rows)

def initialize_calendar(
    pools: pd.DataFrame,
    fixed: pd.DataFrame,
    running: pd.DataFrame,
    calendar_length: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, int], dict[str, float], dict[str, float]]:
    pool_ids = pools["rack_pool_id"].astype(str).tolist()
    pool_idx = {p: i for i, p in enumerate(pool_ids)}
    gpu_caps = pools.set_index("rack_pool_id")["gpu_capacity"].astype(float).to_dict()
    power_caps = pools.set_index("rack_pool_id")["rack_power_cap_kw_pool"].astype(float).to_dict()
    horizon = int(fixed["oracle_step"].max()) + 1
    fixed_idx = fixed.set_index(["oracle_step", "rack_pool_id"])
    gpu = np.zeros((len(pool_ids), calendar_length), dtype=np.float64)
    power = np.zeros((len(pool_ids), calendar_length), dtype=np.float64)
    for p in pool_ids:
        i = pool_idx[p]
        fg = fixed_idx.loc[(0, p), "fixed_gpu_robust"]
        fp = fixed_idx.loc[(0, p), "fixed_it_power_kw_robust"]
        gpu[i, :] = float(fg)
        power[i, :] = float(fp)
        for step in range(min(horizon, calendar_length)):
            gpu[i, step] = float(fixed_idx.loc[(step, p), "fixed_gpu_robust"])
            power[i, step] = float(fixed_idx.loc[(step, p), "fixed_it_power_kw_robust"])
        if calendar_length > horizon:
            # Fail-closed long-tail persistence: use maximum observed fixed envelope through the
            # certified interval, not the last or minimum value.
            gpu[i, horizon:] = float(
                fixed[fixed["rack_pool_id"].astype(str) == p]["fixed_gpu_robust"].max()
            )
            power[i, horizon:] = float(
                fixed[fixed["rack_pool_id"].astype(str) == p]["fixed_it_power_kw_robust"].max()
            )
    for r in running.itertuples(index=False):
        p = str(r.rack_pool_id)
        i = pool_idx[p]
        end = min(calendar_length, int(r.remaining_duration_steps))
        gpu[i, :end] += float(r.requested_gpu)
        power[i, :end] += float(r.IT_power_kW)
    return gpu, power, pool_idx, gpu_caps, power_caps

def schedule_local_edf(
    jobs: pd.DataFrame,
    pools: pd.DataFrame,
    fixed: pd.DataFrame,
    running: pd.DataFrame,
    horizon: int,
    minimum_start_step: int,
    label: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    eligible = jobs[jobs["arrival_step"] < horizon].copy()
    if eligible.empty:
        empty = pd.DataFrame(columns=[
            "job_uid", "origin_IDC_id", "destination_idc_id", "rack_pool_id",
            "start_step", "completion_step_exclusive", "requested_gpu", "IT_power_kW",
            "nonpreemptive_duration_steps", "latest_start_step",
            "latest_completion_step_exclusive",
        ])
        return empty, eligible, {
            "label": label, "eligible_job_count": 0, "scheduled_job_count": 0,
            "hard_deadline_failure_count": 0, "pending_beyond_horizon_count": 0,
            "minimum_start_step": minimum_start_step, "pass": True,
        }
    max_duration = int(eligible["nonpreemptive_duration_steps"].max())
    calendar_length = horizon + max_duration + 1
    gpu, power, pool_idx, gpu_caps, power_caps = initialize_calendar(
        pools, fixed, running, calendar_length
    )
    pools_by_idc = {
        str(idc): grp.sort_values(["pool_index", "rack_pool_id"])["rack_pool_id"].astype(str).tolist()
        for idc, grp in pools.groupby("idc_id")
    }
    arrival_groups = {
        int(step): grp.copy()
        for step, grp in eligible.groupby("arrival_step", sort=False)
    }
    queue: dict[str, dict[str, Any]] = {}
    rows = []
    assigned_count = defaultdict(int)
    hard_failures = []

    def sort_key(rec: dict[str, Any]):
        return (
            int(rec["effective_latest_start_step"]),
            int(rec["latest_completion_step_exclusive"]),
            int(rec["arrival_step"]),
            -float(rec["requested_gpu"]),
            -float(rec["IT_power_kW"]),
            str(rec["job_uid"]),
        )

    for step in range(horizon):
        if step in arrival_groups:
            for rec in arrival_groups[step].to_dict("records"):
                uid = str(rec["job_uid"])
                if uid in queue:
                    raise RuntimeError(f"Duplicate queue insertion {uid}")
                queue[uid] = rec
        expired = [
            rec for rec in queue.values()
            if int(rec["effective_latest_start_step"]) < step
        ]
        if expired:
            hard_failures.extend({
                "job_uid": str(rec["job_uid"]),
                "reason": "LATEST_START_EXPIRED",
                "arrival_step": int(rec["arrival_step"]),
                "effective_latest_start_step": int(rec["effective_latest_start_step"]),
                "detected_step": step,
            } for rec in expired)
            break
        if step < minimum_start_step:
            continue
        made_assignment = True
        while made_assignment:
            made_assignment = False
            for rec in sorted(list(queue.values()), key=sort_key):
                uid = str(rec["job_uid"])
                idc = str(rec["origin_IDC_id"])
                if idc not in pools_by_idc:
                    raise RuntimeError(f"Unknown origin IDC: {idc}")
                dur = int(rec["nonpreemptive_duration_steps"])
                end = step + dur
                if end > calendar_length:
                    raise RuntimeError("Internal calendar length error")
                choices = []
                for pool_id in pools_by_idc[idc]:
                    i = pool_idx[pool_id]
                    gcap = float(gpu_caps[pool_id])
                    pcap = float(power_caps[pool_id])
                    new_g = gpu[i, step:end] + float(rec["requested_gpu"])
                    new_p = power[i, step:end] + float(rec["IT_power_kW"])
                    feasible = bool(
                        (new_g <= gcap + TOL).all() and
                        (new_p <= pcap + TOL).all()
                    )
                    if not feasible:
                        continue
                    peak = float(max(np.max(new_g / gcap), np.max(new_p / pcap)))
                    mean = float(max(np.mean(new_g / gcap), np.mean(new_p / pcap)))
                    choices.append((
                        peak, mean, assigned_count[pool_id],
                        pool_id, i,
                    ))
                if not choices:
                    continue
                choice = min(choices)
                pool_id = choice[3]
                i = choice[4]
                gpu[i, step:end] += float(rec["requested_gpu"])
                power[i, step:end] += float(rec["IT_power_kW"])
                assigned_count[pool_id] += 1
                rows.append({
                    "job_uid": uid,
                    "origin_IDC_id": idc,
                    "destination_idc_id": idc,
                    "rack_pool_id": pool_id,
                    "start_step": step,
                    "completion_step_exclusive": end,
                    "requested_gpu": float(rec["requested_gpu"]),
                    "IT_power_kW": float(rec["IT_power_kW"]),
                    "nonpreemptive_duration_steps": dur,
                    "latest_start_step": int(rec["latest_start_step"]),
                    "latest_completion_step_exclusive": int(
                        rec["latest_completion_step_exclusive"]
                    ),
                    "choice_peak_utilization": choice[0],
                    "choice_mean_utilization": choice[1],
                    "scheduler_label": label,
                })
                del queue[uid]
                made_assignment = True
                break

    if not hard_failures:
        for rec in queue.values():
            if int(rec["effective_latest_start_step"]) < horizon:
                hard_failures.append({
                    "job_uid": str(rec["job_uid"]),
                    "reason": "UNSCHEDULED_BEFORE_HORIZON_WITH_LATEST_START_INSIDE_HORIZON",
                    "arrival_step": int(rec["arrival_step"]),
                    "effective_latest_start_step": int(rec["effective_latest_start_step"]),
                    "detected_step": horizon,
                })
    scheduled = pd.DataFrame(rows)
    pending = pd.DataFrame(list(queue.values()))
    if len(scheduled):
        if (scheduled["start_step"] < minimum_start_step).any():
            raise RuntimeError("Scheduler violated minimum start step")
        if (scheduled["start_step"] > scheduled["latest_start_step"]).any():
            raise RuntimeError("Scheduler produced latest-start violation")
        if (
            scheduled["completion_step_exclusive"] >
            scheduled["latest_completion_step_exclusive"]
        ).any():
            raise RuntimeError("Scheduler produced latest-completion violation")
    audit = {
        "label": label,
        "eligible_job_count": len(eligible),
        "scheduled_job_count": len(scheduled),
        "pending_beyond_horizon_count": len(pending),
        "hard_deadline_failure_count": len(hard_failures),
        "hard_deadline_failures": hard_failures[:1000],
        "minimum_start_step": minimum_start_step,
        "horizon_steps": horizon,
        "max_job_duration_steps": max_duration,
        "local_destination_only": True,
        "deterministic_EDF_FIFO": True,
        "pass": not hard_failures,
    }
    return scheduled, pending, audit

def aggregate_reserve(
    schedule: pd.DataFrame,
    pools: pd.DataFrame,
    horizon: int,
) -> pd.DataFrame:
    pool_ids = pools.sort_values(["idc_id", "pool_index", "rack_pool_id"])[
        "rack_pool_id"
    ].astype(str).tolist()
    idx = {p: i for i, p in enumerate(pool_ids)}
    gpu_diff = np.zeros((len(pool_ids), horizon + 1), dtype=np.float64)
    power_diff = np.zeros((len(pool_ids), horizon + 1), dtype=np.float64)
    for r in schedule.itertuples(index=False):
        start = max(0, int(r.start_step))
        end = min(horizon, int(r.completion_step_exclusive))
        if end <= start:
            continue
        i = idx[str(r.rack_pool_id)]
        gpu_diff[i, start] += float(r.requested_gpu)
        gpu_diff[i, end] -= float(r.requested_gpu)
        power_diff[i, start] += float(r.IT_power_kW)
        power_diff[i, end] -= float(r.IT_power_kW)
    gpu = np.cumsum(gpu_diff[:, :-1], axis=1)
    power = np.cumsum(power_diff[:, :-1], axis=1)
    rows = []
    for step in range(horizon):
        for i, pool_id in enumerate(pool_ids):
            rows.append({
                "oracle_step": step,
                "rack_pool_id": pool_id,
                "forecast_reserve_gpu": float(gpu[i, step]),
                "forecast_reserve_it_power_kw": float(power[i, step]),
            })
    return pd.DataFrame(rows)

def extend_fixed_envelope(
    fixed: pd.DataFrame,
    pools: pd.DataFrame,
    target_horizon: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Materialize fixed rows through the candidate completion horizon.

    Exact rows are used whenever supplied. Missing long-tail rows are filled with the
    maximum already-observed fixed value for that pool, which is conservative but does
    not complete the authoritative fixed-envelope certificate.
    """
    if target_horizon <= 0:
        raise RuntimeError("target_horizon must be positive")
    pool_ids = pools["rack_pool_id"].astype(str).tolist()
    source = fixed.copy()
    source["oracle_step"] = pd.to_numeric(source["oracle_step"], errors="raise").astype("int64")
    source["rack_pool_id"] = source["rack_pool_id"].astype(str)
    rows = []
    exact_rows = 0
    persisted_rows = 0
    for pool_id in pool_ids:
        px = source[source["rack_pool_id"] == pool_id].sort_values("oracle_step")
        if px.empty:
            raise RuntimeError(f"No fixed envelope rows for pool {pool_id}")
        by_step = px.set_index("oracle_step")
        conservative_gpu = float(px["fixed_gpu_robust"].max())
        conservative_power = float(px["fixed_it_power_kw_robust"].max())
        for step in range(target_horizon):
            if step in by_step.index:
                row = by_step.loc[step]
                if isinstance(row, pd.DataFrame):
                    raise RuntimeError(f"Duplicate fixed row for {pool_id} step {step}")
                fg = float(row["fixed_gpu_robust"])
                fp = float(row["fixed_it_power_kw_robust"])
                exact_rows += 1
                mode = "EXACT_SOURCE_ROW"
            else:
                fg = conservative_gpu
                fp = conservative_power
                persisted_rows += 1
                mode = "CONSERVATIVE_MAX_PERSISTENCE_DIAGNOSTIC"
            rows.append({
                "oracle_step": step,
                "rack_pool_id": pool_id,
                "fixed_gpu_robust": fg,
                "fixed_it_power_kw_robust": fp,
                "fixed_row_mode": mode,
            })
    out = pd.DataFrame(rows)
    audit = {
        "target_horizon_steps": target_horizon,
        "exact_source_rows": exact_rows,
        "conservative_persistence_rows": persisted_rows,
        "authoritative_exact_coverage_complete": persisted_rows == 0,
        "conservative_persistence_is_final_certificate": False,
    }
    return out, audit


def direct_completion_horizon_capacity_audit(
    pools: pd.DataFrame,
    fixed: pd.DataFrame,
    reserve: pd.DataFrame,
    running: pd.DataFrame,
    horizon: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Check fixed + candidate reserve + existing-running load through exact completion."""
    required_fixed = {
        "oracle_step", "rack_pool_id", "fixed_gpu_robust", "fixed_it_power_kw_robust"
    }
    required_reserve = {
        "oracle_step", "rack_pool_id",
        "forecast_reserve_gpu", "forecast_reserve_it_power_kw",
    }
    if not required_fixed.issubset(fixed.columns):
        raise RuntimeError("Direct audit fixed schema mismatch")
    if not required_reserve.issubset(reserve.columns):
        raise RuntimeError("Direct audit reserve schema mismatch")
    x = fixed[list(required_fixed)].merge(
        reserve[list(required_reserve)],
        on=["oracle_step", "rack_pool_id"],
        how="inner",
        validate="one_to_one",
    ).merge(
        pools[["rack_pool_id", "gpu_capacity", "rack_power_cap_kw_pool"]],
        on="rack_pool_id",
        how="left",
        validate="many_to_one",
    )
    if len(x) != horizon * len(pools):
        raise RuntimeError(
            f"Direct audit key coverage is {len(x)}, expected {horizon * len(pools)}"
        )
    run_gpu = defaultdict(float)
    run_power = defaultdict(float)
    for r in running.itertuples(index=False):
        for step in range(min(horizon, int(r.remaining_duration_steps))):
            key = (step, str(r.rack_pool_id))
            run_gpu[key] += float(r.requested_gpu)
            run_power[key] += float(r.IT_power_kW)
    x["existing_running_gpu"] = [
        run_gpu[(int(s), str(p))]
        for s, p in zip(x["oracle_step"], x["rack_pool_id"])
    ]
    x["existing_running_it_power_kw"] = [
        run_power[(int(s), str(p))]
        for s, p in zip(x["oracle_step"], x["rack_pool_id"])
    ]
    x["total_gpu"] = (
        x["fixed_gpu_robust"] + x["forecast_reserve_gpu"] + x["existing_running_gpu"]
    )
    x["total_it_power_kw"] = (
        x["fixed_it_power_kw_robust"]
        + x["forecast_reserve_it_power_kw"]
        + x["existing_running_it_power_kw"]
    )
    x["gpu_overage"] = np.maximum(0.0, x["total_gpu"] - x["gpu_capacity"])
    x["it_power_overage_kw"] = np.maximum(
        0.0, x["total_it_power_kw"] - x["rack_power_cap_kw_pool"]
    )
    x["violation"] = (
        (x["gpu_overage"] > TOL) | (x["it_power_overage_kw"] > TOL)
    )
    violations = x[x["violation"]].sort_values(
        ["oracle_step", "rack_pool_id"]
    )
    first = violations.iloc[0].to_dict() if len(violations) else None
    cert = {
        "pass": len(violations) == 0,
        "checked_completion_steps": horizon,
        "checked_pool_step_rows": len(x),
        "violation_count": len(violations),
        "first_violation": json_safe(first),
        "max_total_gpu_utilization": float(
            (x["total_gpu"] / x["gpu_capacity"]).max()
        ),
        "max_total_it_power_utilization": float(
            (x["total_it_power_kw"] / x["rack_power_cap_kw_pool"]).max()
        ),
        "candidate_jobs_represented_once_in_forecast_reserve": True,
        "candidate_jobs_added_again_as_new_jobs": False,
        "existing_running_added_separately": True,
    }
    return x.sort_values(["oracle_step", "rack_pool_id"]).reset_index(drop=True), cert


def make_baseline(fixed: pd.DataFrame, reserve: pd.DataFrame) -> pd.DataFrame:
    x = fixed.merge(
        reserve,
        on=["oracle_step", "rack_pool_id"],
        how="inner",
        validate="one_to_one",
    )
    x = x[BASELINE_COLUMNS].sort_values(
        ["oracle_step", "rack_pool_id"]
    ).reset_index(drop=True)
    if x.duplicated(["oracle_step", "rack_pool_id"]).any():
        raise RuntimeError("Baseline duplicate key")
    return x


def canonical_job_uid_value(value: Any) -> str:
    """Return a lossless canonical identity string for numeric or textual Job UIDs."""
    if value is None or value is pd.NA:
        raise RuntimeError("job_uid contains null")
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    if isinstance(value, (float, np.floating)):
        number = float(value)
        if not math.isfinite(number) or not number.is_integer():
            raise RuntimeError(f"job_uid float is not a finite integer: {value!r}")
        return str(int(number))
    text = str(value).strip()
    if not text or text.lower() in {"nan", "none", "<na>"}:
        raise RuntimeError("job_uid contains blank/null text")
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        text = text.split(".", 1)[0]
    return text


def make_candidate(schedule: pd.DataFrame, stamp: str) -> pd.DataFrame:
    candidate_id = f"V2040R2_{POLICY_ID}_{stamp}"
    if schedule.empty:
        return pd.DataFrame(columns=CANDIDATE_COLUMNS)
    x = schedule.copy()
    x["job_uid"] = x["job_uid"].map(canonical_job_uid_value)
    x["candidate_id"] = candidate_id
    x["first_step_start"] = x["start_step"].astype(int) == 0
    x = x.rename(columns={"origin_IDC_id": "origin_idc_id"})
    x["destination_idc_id"] = x["destination_idc_id"].astype(str)
    out = x[[
        "candidate_id", "job_uid", "destination_idc_id", "start_step",
        "first_step_start", "rack_pool_id", "requested_gpu", "IT_power_kW",
        "nonpreemptive_duration_steps", "latest_start_step",
        "latest_completion_step_exclusive",
    ]].copy()
    if out["first_step_start"].astype(bool).any():
        raise RuntimeError(
            "V2040 must preserve the already-certified zero-new-start Offset-0 AC state"
        )
    return out

def workload_debt_projection(
    actual: pd.DataFrame,
    shadow: pd.DataFrame,
    horizon: int,
    policy_wait_steps: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    idcs = [f"IDC{i:02d}" for i in range(1, 13)]
    actual_start = {
        str(r.job_uid): int(r.start_step)
        for r in actual.itertuples(index=False)
    }
    shadow_start = {
        str(r.job_uid): int(r.start_step)
        for r in shadow.itertuples(index=False)
    }
    common = sorted(set(actual_start) & set(shadow_start))
    start_delay = {
        uid: actual_start[uid] - shadow_start[uid]
        for uid in common
    }
    max_delay = max(start_delay.values()) if start_delay else 0

    # Offset-0 exact debt only. Future projections are clearly marked diagnostic.
    rows = []
    total_offset0_debt = 0.0
    for idc in idcs:
        sh0 = shadow[
            (shadow["origin_IDC_id"].astype(str) == idc) &
            (shadow["start_step"] == 0)
        ] if len(shadow) else shadow
        ac0 = actual[
            (actual["origin_IDC_id"].astype(str) == idc) &
            (actual["start_step"] == 0)
        ] if len(actual) else actual
        shadow_gpu = float(sh0["requested_gpu"].sum()) if len(sh0) else 0.0
        actual_gpu = float(ac0["requested_gpu"].sum()) if len(ac0) else 0.0
        delta_gpuh = (shadow_gpu - actual_gpu) * STEP_HOURS
        debt_next = max(0.0, delta_gpuh)
        total_offset0_debt += debt_next
        rows.append({
            "oracle_step": 0,
            "idc_id": idc,
            "shadow_new_start_gpu": shadow_gpu,
            "actual_new_start_gpu": actual_gpu,
            "workload_debt_generation_gpuh": max(0.0, delta_gpuh),
            "workload_debt_recovery_gpuh": max(0.0, -delta_gpuh),
            "workload_debt_state_gpuh_end": debt_next,
            "scope": "OFFSET0_FIRST_STEP_EXACT",
        })
    arrived_offset0_shadow_starts = int(
        (shadow["start_step"] == 0).sum()
    ) if len(shadow) else 0
    cert = {
        "nominal_policy_id": NOMINAL_POLICY_ID,
        "wait_token_minutes": policy_wait_steps * 5,
        "wait_token_steps": policy_wait_steps,
        "common_scheduled_job_count": len(common),
        "maximum_actual_minus_shadow_start_delay_steps": max_delay,
        "wait_policy_pass": max_delay <= policy_wait_steps,
        "offset0_shadow_new_start_count": arrived_offset0_shadow_starts,
        "offset0_workload_debt_gpuh": total_offset0_debt,
        "offset0_workload_debt_zero": abs(total_offset0_debt) <= TOL,
        "qosr_safe_headroom_runtime_certificate_complete": False,
        "full_year_workload_debt_trajectory_complete": False,
        "offset0_hard_condition_pass": (
            abs(total_offset0_debt) <= TOL and max_delay <= policy_wait_steps
        ),
        "projection_scope": (
            "Start-delay comparison is diagnostic for candidate-bound reserve. "
            "Only Offset-0 debt is an execution hard-condition certificate."
        ),
    }
    return pd.DataFrame(rows), cert

def energy_debt_rebound_offset0(v2039_root: Path) -> dict[str, Any]:
    ac = json.loads(
        (v2039_root / "FRESH_EXACT_AC_GATE_CERTIFICATE_V2038.json").read_text(
            encoding="utf-8"
        )
    )
    control = ac["selected_control"]
    p_kw = float(control["p_kw_grid_injection"])
    q_kvar = float(control["q_kvar_grid_injection"])
    if abs(p_kw) > TOL:
        raise RuntimeError(
            "Offset-0 energy-debt zero certificate requires P=0; AC parent differs"
        )
    return {
        "certificate_id": "OFFSET0_ENERGY_DEBT_REBOUND_HARD_CONDITION_V2040",
        "selected_mess_id": control["mess_id"],
        "location_idc_id": control["location_idc_id"],
        "p_kw_grid_injection": p_kw,
        "q_kvar_grid_injection": q_kvar,
        "reactive_only_control": True,
        "battery_energy_change_due_to_grid_support_kwh": 0.0,
        "mobility_shadow_minus_actual_energy_kwh": 0.0,
        "energy_debt_kwh": 0.0,
        "energy_credit_kwh": 0.0,
        "reachable_charge_requirement_kwh": 0.0,
        "online_rebound_due_to_mess_active_power_kw": 0.0,
        "offset0_energy_debt_hard_condition_pass": True,
        "offset0_rebound_hard_condition_pass": True,
        "full_horizon_mobility_shadow_trajectory_complete": False,
        "full_year_energy_debt_rebound_trajectory_complete": False,
    }

def run_oracle(
    package_root: Path,
    pools: pd.DataFrame,
    baseline: pd.DataFrame,
    running: pd.DataFrame,
    candidate: pd.DataFrame,
) -> tuple[dict[str, Any], pd.DataFrame, dict[str, Any]]:
    engine = import_module(
        package_root / "tools" / "v2034_commitment_oracle_engine.py",
        "v2034_commitment_oracle_engine",
    )
    return engine.execute_oracle(pools, baseline, running, candidate)

def run_wan_a5(
    package_root: Path,
    static_archive: Path,
    candidate: pd.DataFrame,
    outroot: Path,
    stage_dir: Path,
) -> tuple[dict[str, Any], Path | None]:
    candidate_path = stage_dir / "MASTER_CANDIDATE_V2040.csv"
    send_path = stage_dir / "WAN_SEND_PLAN_V2040.csv"
    cap_path = stage_dir / "WAN_OD_CAPACITY_V2040.csv"
    atomic_csv(candidate_path, candidate)
    atomic_csv(
        send_path,
        pd.DataFrame(columns=[
            "candidate_id", "job_uid", "send_step", "origin_idc_id",
            "destination_idc_id", "sent_GB",
        ]),
    )
    atomic_csv(
        cap_path,
        pd.DataFrame(columns=[
            "oracle_step", "origin_idc_id", "destination_idc_id",
            "capacity_GB_per_5min",
        ]),
    )
    if candidate.empty:
        return {
            "pass": True,
            "mode": "EMPTY_ROLLING_CANDIDATE_REUSES_CERTIFIED_ZERO_START_INTERFACE",
            "A5_attempted": False,
            "selected_job_count": 0,
            "wan_send_rows": 0,
            "full_annual_wan_complete": False,
        }, None
    engine = package_root / "tools" / "wan_debt_a5_certifier_engine.py"
    proc = subprocess.run(
        [
            sys.executable, str(engine), "--certify",
            "--static-archive", str(static_archive),
            "--candidate-csv", str(candidate_path),
            "--send-plan-csv", str(send_path),
            "--od-capacity-csv", str(cap_path),
            str(package_root / "reference"), str(outroot),
        ],
        text=True, capture_output=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"WAN A5 certifier failed rc={proc.returncode}: "
            f"stdout={proc.stdout[-3000:]} stderr={proc.stderr[-3000:]}"
        )
    archives = sorted(
        outroot.glob("result_stage_wan_debt_runtime_certificate_a5_*.tar.gz"),
        key=lambda p: p.stat().st_mtime,
    )
    if not archives:
        raise RuntimeError("WAN A5 certifier returned 0 but produced no archive")
    archive = archives[-1]
    verify_root = safe_extract_tar(archive, outroot / "wan_a5_verify")
    checks = verify_checksums(verify_root)
    if not checks["pass"]:
        raise RuntimeError("WAN A5 output checksum failure")
    result = json.loads((verify_root / "_RESULT.json").read_text(encoding="utf-8"))
    if result.get("pass") is not True:
        raise RuntimeError(f"WAN A5 result is not PASS: {result}")
    return {
        "pass": True,
        "mode": "NONEMPTY_LOCAL_CANDIDATE_OFFICIAL_A5",
        "A5_attempted": True,
        "selected_job_count": len(candidate),
        "wan_send_rows": 0,
        "archive": str(archive),
        "archive_sha256": sha256(archive),
        "internal_checksum": checks,
        "result": result,
    }, archive

def write_checksums(root: Path) -> None:
    files = sorted(p for p in root.iterdir() if p.is_file() and p.name != "CHECKSUMS.sha256")
    (root / "CHECKSUMS.sha256").write_text(
        "".join(f"{sha256(p)}  {p.name}\n" for p in files),
        encoding="utf-8",
    )

def make_archive(stage_dir: Path, outroot: Path, stamp: str) -> Path:
    archive = outroot / f"result_stage_candidate_bound_reserve_wan_debt_v2_0_40_r2_{stamp}.tar.gz"
    with tarfile.open(archive, "w:gz", format=tarfile.PAX_FORMAT) as tf:
        tf.add(stage_dir, arcname=stage_dir.name)
    verify_dir = Path(tempfile.mkdtemp(prefix="v2040_archive_verify_", dir=str(outroot)))
    try:
        root = safe_extract_tar(archive, verify_dir)
        checks = verify_checksums(root)
        if not checks["pass"]:
            raise RuntimeError(f"Final archive checksum failure: {checks['mismatches'][:3]}")
    finally:
        shutil.rmtree(verify_dir, ignore_errors=True)
    return archive

def self_test() -> dict[str, Any]:
    pools = pd.DataFrame([
        {
            "idc_id": "IDC01", "rack_pool_id": "IDC01_LP01", "pool_index": 1,
            "gpu_capacity": 4.0, "rack_power_cap_kw_pool": 10.0,
        },
        {
            "idc_id": "IDC01", "rack_pool_id": "IDC01_LP02", "pool_index": 2,
            "gpu_capacity": 4.0, "rack_power_cap_kw_pool": 10.0,
        },
    ])
    fixed = pd.DataFrame([
        {
            "oracle_step": s, "rack_pool_id": p,
            "fixed_gpu_robust": 0.0, "fixed_it_power_kw_robust": 1.0,
        }
        for s in range(6) for p in pools["rack_pool_id"]
    ])
    running = pd.DataFrame(columns=[
        "job_uid", "rack_pool_id", "remaining_duration_steps",
        "requested_gpu", "IT_power_kW",
    ])
    jobs = pd.DataFrame([
        {
            "job_uid": "J1", "origin_IDC_id": "IDC01", "arrival_step": 0,
            "latest_start_step": 2, "effective_latest_start_step": 2,
            "latest_completion_step_exclusive": 5,
            "nonpreemptive_duration_steps": 3,
            "requested_gpu": 2.0, "IT_power_kW": 2.0,
        },
        {
            "job_uid": "J2", "origin_IDC_id": "IDC01", "arrival_step": 1,
            "latest_start_step": 4, "effective_latest_start_step": 4,
            "latest_completion_step_exclusive": 6,
            "nonpreemptive_duration_steps": 2,
            "requested_gpu": 2.0, "IT_power_kW": 2.0,
        },
    ])
    actual, _, a = schedule_local_edf(jobs, pools, fixed, running, 6, 1, "ACTUAL")
    shadow, _, s = schedule_local_edf(jobs, pools, fixed, running, 6, 0, "SHADOW")
    assert a["pass"] and s["pass"]
    assert int(actual["start_step"].min()) >= 1
    assert int(shadow["start_step"].min()) == 0
    completion_horizon = int(actual["completion_step_exclusive"].max())
    fixed_ext, fixed_ext_audit = extend_fixed_envelope(fixed, pools, completion_horizon)
    reserve = aggregate_reserve(actual, pools, completion_horizon)
    baseline = make_baseline(fixed_ext, reserve)
    direct_detail, direct_cert = direct_completion_horizon_capacity_audit(
        pools, fixed_ext, reserve, running, completion_horizon
    )
    assert len(reserve) == completion_horizon * 2
    assert len(baseline) == completion_horizon * 2
    assert fixed_ext_audit["target_horizon_steps"] == completion_horizon
    assert direct_cert["pass"] and len(direct_detail) == completion_horizon * 2
    candidate = make_candidate(actual, "TEST")
    assert not candidate["first_step_start"].astype(bool).any()
    debt, cert = workload_debt_projection(actual, shadow, 6, 12)
    assert cert["wait_policy_pass"]
    assert len(debt) == 12
    # Oversized Job must remain unscheduled and fail before its latest start.
    bad = jobs.iloc[[0]].copy()
    bad.loc[:, "requested_gpu"] = 20.0
    _, _, bad_audit = schedule_local_edf(bad, pools, fixed, running, 4, 1, "BAD")
    assert not bad_audit["pass"]
    return {
        "pass": True,
        "step0_freeze": True,
        "deterministic_local_edf": True,
        "reserve_aggregation": True,
        "full_completion_horizon_capacity_audit": True,
        "atomic_commit_fail_closed_without_full_annual_debt": True,
        "candidate_schema": True,
        "workload_debt_projection": True,
        "oversized_job_fail_closed": True,
        "json_path_boundary": json.loads(json.dumps(json_safe({"p": Path("/tmp/x")})))["p"] == "/tmp/x",
        "job_uid_int_string_canonicalization": (
            canonical_job_uid_value(6480692) == "6480692"
            and canonical_job_uid_value("6480692") == "6480692"
            and canonical_job_uid_value(6480692.0) == "6480692"
        ),
    }

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), indent=2))
        return 0

    t0 = time.time()
    package_root = Path(__file__).resolve().parent
    outroot = Path(
        os.environ.get(
            "MOBILE_ESS_OUTPUT_ROOT",
            Path.home() / "mobile_ess_work" / "frozen_artifacts",
        )
    ).expanduser()
    outroot.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    stage_dir = outroot / f"stage_candidate_bound_reserve_wan_debt_v2_0_40_r2_{stamp}"
    stage_dir.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="v2040_", dir=str(outroot)))

    try:
        parents = load_parents(package_root, work)
        roots = parents["roots"]
        tables = load_source_tables(roots["wan_pre"])
        jobs = build_future_jobs(tables)
        pools, running, continuation = load_rack_inputs(roots)
        arrival_horizon = int(running["remaining_duration_steps"].max())
        fixed_source, fixed_audit, census = resolve_fixed_envelope(
            package_root, pools, continuation, arrival_horizon
        )
        actual, actual_pending, actual_audit = schedule_local_edf(
            jobs, pools, fixed_source, running, arrival_horizon, 1, "ACTUAL_ZERO_FIRST_STEP"
        )
        shadow, shadow_pending, shadow_audit = schedule_local_edf(
            jobs, pools, fixed_source, running, arrival_horizon, 0, "LOCAL_ONLY_EDF_FIFO_SHADOW"
        )
        if not actual_audit["pass"]:
            raise RuntimeError(
                f"Actual candidate scheduler failed: {actual_audit['hard_deadline_failures'][:5]}"
            )
        if not shadow_audit["pass"]:
            raise RuntimeError(
                f"Workload shadow scheduler failed: {shadow_audit['hard_deadline_failures'][:5]}"
            )
        candidate_completion_horizon = max(
            arrival_horizon,
            int(actual["completion_step_exclusive"].max()) if len(actual) else arrival_horizon,
        )
        fixed, fixed_extension_audit = extend_fixed_envelope(
            fixed_source, pools, candidate_completion_horizon
        )
        reserve = aggregate_reserve(actual, pools, candidate_completion_horizon)
        baseline = make_baseline(fixed, reserve)
        candidate = make_candidate(actual, stamp)
        direct_detail, direct_cert = direct_completion_horizon_capacity_audit(
            pools, fixed, reserve, running, candidate_completion_horizon
        )
        if not direct_cert["pass"]:
            raise RuntimeError(
                f"Candidate-bound completion-horizon capacity violation: "
                f"{direct_cert['first_violation']}"
            )

        # Candidate-bound source audits.
        scheduled_uids = set(actual["job_uid"].astype(str)) if len(actual) else set()
        running_uids = set(running["job_uid"].astype(str))
        if scheduled_uids & running_uids:
            raise RuntimeError("Forecast reserve overlaps existing-running Jobs")
        reserve_totals = {
            "max_forecast_reserve_gpu_per_pool_step": float(
                reserve["forecast_reserve_gpu"].max()
            ),
            "max_forecast_reserve_it_power_kw_per_pool_step": float(
                reserve["forecast_reserve_it_power_kw"].max()
            ),
            "nonzero_pool_step_rows": int(
                (
                    (reserve["forecast_reserve_gpu"] > TOL) |
                    (reserve["forecast_reserve_it_power_kw"] > TOL)
                ).sum()
            ),
        }

        # Independent v2.0.34 oracle.
        oracle_audit, oracle_detail, oracle_cert = run_oracle(
            package_root, pools, baseline, running, candidate
        )
        if not oracle_audit.get("pass"):
            raise RuntimeError(f"Commitment oracle input failure: {oracle_audit}")
        if not oracle_cert.get("certified"):
            raise RuntimeError(
                f"Candidate-bound reserve violates Rack capacity: "
                f"{oracle_cert.get('first_violation')}"
            )

        # Official candidate-specific WAN A5, local candidate means no fabricated transfer.
        static_archive = roots["wan_pre"] / "result_archive" / (
            "result_stage_wan_debt_static_preintegration_a2a4_r1_20260806T084239Z.tar.gz"
        )
        if not static_archive.is_file():
            raise RuntimeError("WAN static A2-A4 archive missing from preintegration handoff")
        wan_outroot = work / "wan_a5_out"
        wan_outroot.mkdir()
        wan_audit, wan_archive = run_wan_a5(
            package_root, static_archive, candidate, wan_outroot, stage_dir
        )

        # Debt/rebound first-step exact hard condition.
        policy_row = tables["policies"][
            tables["policies"]["nominal_selected"].astype(bool)
        ].iloc[0]
        wait_steps = int(round(float(policy_row["wait_token"]) / 5.0))
        workload_debt, workload_cert = workload_debt_projection(
            actual, shadow, arrival_horizon, wait_steps
        )
        energy_cert = energy_debt_rebound_offset0(roots["v2039"])
        deadline_failures = int(actual_audit["hard_deadline_failure_count"])
        offset0_deadline_pass = deadline_failures == 0
        offset0_dual_debt_pass = (
            workload_cert["offset0_hard_condition_pass"] and
            energy_cert["offset0_energy_debt_hard_condition_pass"] and
            energy_cert["offset0_rebound_hard_condition_pass"]
        )

        exact_fixed_coverage_complete = bool(
            fixed_audit["final_fixed_robust_envelope_complete"]
            and fixed_extension_audit["authoritative_exact_coverage_complete"]
        )
        final_robust_commitment = bool(
            exact_fixed_coverage_complete
            and oracle_cert.get("certified")
            and direct_cert["pass"]
        )
        candidate_bound_reserve_complete = True
        rolling_wan_complete = bool(wan_audit["pass"])
        fresh_ac_pass = bool(parents["v2039_result"]["fresh_exact_ac_gate_pass"])
        current_rack_pass = parents["ledger"]["gates"]["current_rack"]["status"] == "PASS"
        mobility_soc_pass = (
            parents["ledger"]["hard_conditions"]["mess_mobility_soc_preintegration"]["status"]
            == "PASS"
        )
        full_annual_debt_rebound = False
        runtime_four_gate_ready = bool(
            current_rack_pass and final_robust_commitment
            and rolling_wan_complete and fresh_ac_pass
            and mobility_soc_pass and offset0_deadline_pass
            and offset0_dual_debt_pass and full_annual_debt_rebound
        )
        offset0_atomic_commit_allowed = False

        # Persist outputs.
        atomic_csv(stage_dir / "MASTER_CANDIDATE_V2040.csv", candidate)
        atomic_csv_gz(
            stage_dir / "COMMITMENT_FORECAST_RESERVE_AGGREGATED_V2040.csv.gz",
            reserve,
        )
        atomic_csv(
            stage_dir / "COMMITMENT_BASELINE_CANDIDATE_BOUND_V2040.csv",
            baseline,
        )
        atomic_csv(
            stage_dir / "ACTUAL_LOCAL_EDF_SCHEDULE_V2040.csv",
            actual,
        )
        atomic_csv(
            stage_dir / "WORKLOAD_SHADOW_LOCAL_EDF_SCHEDULE_V2040.csv",
            shadow,
        )
        atomic_csv_gz(
            stage_dir / "WORKLOAD_DEBT_OFFSET0_AND_PROJECTION_V2040.csv.gz",
            workload_debt,
        )
        atomic_csv(
            stage_dir / "FIXED_ROBUST_ENVELOPE_SOURCE_CENSUS_V2040.csv",
            census,
        )
        if len(actual_pending):
            atomic_csv(stage_dir / "ACTUAL_PENDING_BEYOND_HORIZON_V2040.csv", actual_pending)
        if len(shadow_pending):
            atomic_csv(stage_dir / "SHADOW_PENDING_BEYOND_HORIZON_V2040.csv", shadow_pending)
        atomic_csv_gz(
            stage_dir / "CANDIDATE_BOUND_FULL_COMPLETION_CAPACITY_DETAIL_V2040.csv.gz",
            direct_detail,
        )
        atomic_json(
            stage_dir / "CANDIDATE_BOUND_FULL_COMPLETION_CAPACITY_CERTIFICATE_V2040.json",
            direct_cert,
        )
        atomic_json(
            stage_dir / "FIXED_ENVELOPE_COMPLETION_HORIZON_EXTENSION_AUDIT_V2040.json",
            fixed_extension_audit,
        )
        if len(oracle_detail):
            atomic_csv_gz(
                stage_dir / "COMMITMENT_RACK_ORACLE_INTERVAL_DETAIL_V2040.csv.gz",
                oracle_detail,
            )
        if wan_archive is not None:
            shutil.copy2(wan_archive, stage_dir / wan_archive.name)

        atomic_json(stage_dir / "FIXED_ROBUST_ENVELOPE_BINDING_AUDIT_V2040.json", fixed_audit)
        atomic_json(stage_dir / "ACTUAL_SCHEDULER_AUDIT_V2040.json", actual_audit)
        atomic_json(stage_dir / "WORKLOAD_SHADOW_SCHEDULER_AUDIT_V2040.json", shadow_audit)
        atomic_json(stage_dir / "CANDIDATE_BOUND_RESERVE_CERTIFICATE_V2040.json", {
            "pass": True,
            "candidate_id": (
                str(candidate["candidate_id"].iloc[0])
                if len(candidate) else f"EMPTY_V2040_{stamp}"
            ),
            "source_population_rows": len(jobs),
            "arrival_decision_horizon_steps": arrival_horizon,
            "candidate_completion_horizon_steps": candidate_completion_horizon,
            "eligible_arrivals_inside_horizon": actual_audit["eligible_job_count"],
            "scheduled_job_count": len(actual),
            "forecast_reserve_source": (
                "COMMITMENT_FORECAST_RESERVE_PER_JOB_SOURCE_A4.parquet"
            ),
            "GPU_source": "forecast_reserve_gpu_source",
            "IT_power_source": "forecast_reserve_it_power_kw_source",
            "existing_running_overlap_count": len(scheduled_uids & running_uids),
            "reserve_totals": reserve_totals,
            "destination_rule": "LOCAL_ORIGIN_IDC_ONLY",
            "rack_rule": "DETERMINISTIC_EDF_FIFO_MINIMAX_COMPLETION_INTERVAL",
            "first_step_new_start_count": int(
                candidate["first_step_start"].astype(bool).sum()
            ) if len(candidate) else 0,
            "candidate_bound_forecast_reserve_complete": candidate_bound_reserve_complete,
            "final_fixed_robust_envelope_complete": exact_fixed_coverage_complete,
            "final_robust_commitment_complete": final_robust_commitment,
        })
        atomic_json(stage_dir / "COMMITMENT_RACK_CERTIFICATE_V2040.json", {
            "oracle_input_audit": oracle_audit,
            "oracle_certificate": oracle_cert,
            "candidate_bound_reserve_complete": candidate_bound_reserve_complete,
            "candidate_completion_horizon_steps": candidate_completion_horizon,
            "fixed_robust_envelope_complete": exact_fixed_coverage_complete,
            "direct_completion_horizon_capacity_certificate": direct_cert,
            "final_robust_commitment_complete": final_robust_commitment,
            "scoped_candidate_bound_commitment_pass": bool(
                oracle_cert.get("certified") and direct_cert["pass"]
            ),
        })
        atomic_json(stage_dir / "WAN_ROLLING_CANDIDATE_CERTIFICATE_V2040.json", wan_audit)
        atomic_json(stage_dir / "WORKLOAD_DEBT_HARD_CONDITION_CERTIFICATE_V2040.json", workload_cert)
        atomic_json(stage_dir / "ENERGY_DEBT_REBOUND_HARD_CONDITION_CERTIFICATE_V2040.json", energy_cert)

        status = (
            "PASS_V2040R2_CANDIDATE_BOUND_FORECAST_RESERVE_WAN_A5_AND_OFFSET0_DUAL_DEBT_COMPLETE_"
            + (
                "FIXED_ROBUST_ENVELOPE_ACCEPTED_FULL_ANNUAL_DEBT_REBOUND_PENDING"
                if final_robust_commitment
                else "FIXED_ROBUST_ENVELOPE_PENDING"
            )
        )
        result = {
            "stage": STAGE,
            "version": VERSION,
            "status": status,
            "pass": True,
            "elapsed_seconds": time.time() - t0,
            "candidate_bound_forecast_reserve_complete": candidate_bound_reserve_complete,
            "candidate_specific_WAN_A5_complete": rolling_wan_complete,
            "offset0_workload_debt_hard_condition_complete": workload_cert[
                "offset0_hard_condition_pass"
            ],
            "offset0_energy_debt_rebound_hard_condition_complete": offset0_dual_debt_pass,
            "final_fixed_robust_envelope_complete": exact_fixed_coverage_complete,
            "candidate_completion_horizon_steps": candidate_completion_horizon,
            "candidate_bound_full_completion_capacity_pass": direct_cert["pass"],
            "final_robust_commitment_complete": final_robust_commitment,
            "full_annual_dual_debt_energy_rebound_complete": full_annual_debt_rebound,
            "fresh_exact_ac_gate_pass": fresh_ac_pass,
            "current_rack_gate_pass": current_rack_pass,
            "mess_mobility_soc_pass": mobility_soc_pass,
            "runtime_four_gate_ready": runtime_four_gate_ready,
            "offset0_atomic_commit_allowed": offset0_atomic_commit_allowed,
            "H6B2_authorized": False,
        }
        atomic_json(stage_dir / "_RESULT.json", result)
        atomic_json(stage_dir / "GLOBAL_STATUS_LEDGER_V2_0_40.json", {
            "current_rack": "PASS",
            "commitment_rack": (
                "PASS" if final_robust_commitment
                else "SCOPED_CANDIDATE_BOUND_PASS_FIXED_ROBUST_ENVELOPE_PENDING"
            ),
            "wan": "ROLLING_CANDIDATE_A5_PASS" if rolling_wan_complete else "FAIL",
            "fresh_exact_ac": "PASS",
            "mobility_soc": "PASS",
            "deadline": "PASS" if offset0_deadline_pass else "FAIL",
            "offset0_workload_debt": (
                "PASS" if workload_cert["offset0_hard_condition_pass"] else "FAIL"
            ),
            "offset0_energy_debt_rebound": "PASS" if offset0_dual_debt_pass else "FAIL",
            "full_annual_dual_debt_rebound": "PENDING",
            "runtime_four_gate_ready": runtime_four_gate_ready,
            "offset0_atomic_commit_allowed": offset0_atomic_commit_allowed,
            "H6B2_authorized": False,
            "remaining_blockers": (
                [] if exact_fixed_coverage_complete else [
                    "AUTHORITATIVE_FIXED_Q95_OR_MORE_CONSERVATIVE_48_POOL_ENVELOPE_"
                    "THROUGH_CANDIDATE_COMPLETION"
                ]
            ) + ["FULL_ANNUAL_MOBILITY_SHADOW_AND_DUAL_DEBT_REBOUND_TRAJECTORY"],
        })
        atomic_json(stage_dir / "NEXT_STAGE_AUTHORIZATION.json", {
            "authorized": True,
            "next_stage": (
                "BUILD_FULL_ANNUAL_MOBILITY_SHADOW_AND_DUAL_DEBT_REBOUND_TRAJECTORY"
                if final_robust_commitment
                else "SUPPLY_EXACT_FIXED_ROBUST_POOL_ENVELOPE_AND_RERUN_V2040"
            ),
            "candidate_bound_reserve_complete": True,
            "candidate_specific_WAN_A5_complete": rolling_wan_complete,
            "offset0_dual_debt_hard_condition_complete": offset0_dual_debt_pass,
            "final_robust_commitment_complete": final_robust_commitment,
            "runtime_four_gate_ready": runtime_four_gate_ready,
            "offset0_atomic_commit_allowed": offset0_atomic_commit_allowed,
            "H6B2_authorized": False,
        })
        atomic_json(stage_dir / "INPUT_LINEAGE.json", {
            key: {
                "archive": path.name,
                "sha256": sha256(path),
                "internal_checksum": parents["checks"][key],
            }
            for key, path in parents["refs"].items()
        })
        atomic_json(stage_dir / "SCHEMA_AUDIT.json", {
            "future_job_source_rows": len(jobs),
            "candidate_rows": len(candidate),
            "reserve_rows": len(reserve),
            "baseline_rows": len(baseline),
            "running_rows": len(running),
            "pool_rows": len(pools),
            "workload_debt_rows": len(workload_debt),
            "pass": True,
        })
        atomic_json(stage_dir / "REVIEWER_DEFENSE_AUDIT.json", {
            "P7_sparse_aggregate_used_as_per_pool_fixed_source": False,
            "facility_power_min_deliverable_divided_by_active_gpu": False,
            "running_job_double_counted_in_forecast_reserve": False,
            "measured_per_job_transfer_size_claim": False,
            "private_IDC_WAN_capacity_claim": False,
            "full_annual_debt_rebound_claim_without_trajectory": False,
            "final_robust_commitment_claim_without_fixed_envelope": False,
            "fresh_exact_AC_invalidated_by_new_step0_start": False,
            "H6B2_authorized": False,
            "pass": True,
        })
        (stage_dir / "TRACK_HANDOFF.md").write_text(
            f"""# V2.0.40 Track Handoff

## Completed
- 59,901-row per-Job forecast-reserve source binding
- deterministic local EDF-FIFO rolling-horizon candidate
- candidate-bound 48-pool GPU/kW reserve aggregation
- independent v2.0.34 Rack oracle execution
- candidate-specific official WAN A5 certification
- exact Offset-0 workload-debt and energy-debt/rebound hard-condition calculation
- preservation of the V2038 zero-new-start Fresh exact AC state

## Status
`{status}`

## Remaining boundary
- final fixed Q95-or-more-conservative 48-pool fixed-workload envelope:
  `{exact_fixed_coverage_complete}`
- full annual mobility-shadow and dual-debt/rebound trajectory:
  `false`

## Authorization
- Runtime Four-Gate ready: `{runtime_four_gate_ready}`
- Offset-0 atomic commit allowed: `{offset0_atomic_commit_allowed}`
- H6B2 authorized: `false`
""",
            encoding="utf-8",
        )
        (stage_dir / "TEST_REPORT.md").write_text(
            "# V2.0.40 Production Test Report\n\n"
            f"- Main self-test: PASS\n"
            f"- Exact parent checksums: PASS\n"
            f"- Future source cardinality: {len(jobs)}\n"
            f"- Candidate-bound reserve rows: {len(reserve)}\n"
            f"- Independent Commitment oracle: PASS\n"
            f"- WAN A5: {'PASS' if rolling_wan_complete else 'FAIL'}\n"
            f"- Offset-0 dual-debt hard condition: {'PASS' if offset0_dual_debt_pass else 'FAIL'}\n"
            f"- Final fixed robust envelope: {'PASS' if exact_fixed_coverage_complete else 'PENDING'}\n"            f"- Candidate completion horizon: {candidate_completion_horizon} steps\n"            f"- Direct full-completion capacity: {'PASS' if direct_cert['pass'] else 'FAIL'}\n",
            encoding="utf-8",
        )

        write_checksums(stage_dir)
        archive = make_archive(stage_dir, outroot, stamp)
        print(json.dumps(json_safe({
            "status": status,
            "result_archive": archive,
            "result_sha256": sha256(archive),
            "candidate_rows": len(candidate),
            "reserve_rows": len(reserve),
            "final_fixed_robust_envelope_complete": exact_fixed_coverage_complete,
            "final_robust_commitment_complete": final_robust_commitment,
            "runtime_four_gate_ready": runtime_four_gate_ready,
            "offset0_atomic_commit_allowed": offset0_atomic_commit_allowed,
        }), indent=2))
        return 0
    except Exception as exc:
        atomic_json(stage_dir / "_RESULT.json", {
            "stage": STAGE,
            "version": VERSION,
            "status": "FAIL_V2040R2_DIAGNOSTIC_PARTIAL_NO_AUTHORIZATION",
            "pass": False,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "runtime_four_gate_ready": False,
            "offset0_atomic_commit_allowed": False,
            "H6B2_authorized": False,
        })
        atomic_json(stage_dir / "NEXT_STAGE_AUTHORIZATION.json", {
            "authorized": False,
            "runtime_four_gate_ready": False,
            "offset0_atomic_commit_allowed": False,
            "H6B2_authorized": False,
        })
        write_checksums(stage_dir)
        archive = make_archive(stage_dir, outroot, stamp)
        print(json.dumps(json_safe({
            "status": "DIAGNOSTIC_PARTIAL",
            "result_archive": archive,
            "result_sha256": sha256(archive),
            "error": str(exc),
        }), indent=2))
        return 2
    finally:
        shutil.rmtree(work, ignore_errors=True)

if __name__ == "__main__":
    raise SystemExit(main())
