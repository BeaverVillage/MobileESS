from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import math
import os
import shutil
import sys
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

STAGE = "WAN_DEBT_A2A4_R1_STATIC_PREINTEGRATION_BUNDLE"
VERSION = "WAN_DEBT_A2A4_R1"
MASTER_START_UTC = pd.Timestamp("2024-12-31T14:00:00Z")
STEP_NS = 300_000_000_000
EXPECTED = {
    "A1": {
        "file": "result_stage_wan_debt_runtime_calibration_adapter_a1_20260806T075519Z.tar.gz",
        "sha256": "65de154e7746623f04521f8ec7cfff6f675d330cd1d747ef9c687c44310db93b",
        "status": "PASS_WAN_DEBT_A1_PUBLIC_RUNTIME_CALIBRATION_ENVELOPE_MATERIALIZED_NEXT_JOB_INPUT_SIZE_AUTHORIZED",
    },
    "V31": {
        "file": "result_stage_job_adapter_semantic_split_and_rack_source_census_v2_0_31_20260805T152959.tar.gz",
        "sha256": "634e6cd54249984448af1295a7c3d7decb734d9e474de6a19c2d5c7bf072d39d",
        "status": None,
    },
    "R6C": {
        "file": "result_stage_kestrel_resource_aware_job_power_policy_v2_0_32_r6c_20260806T122335.tar.gz",
        "sha256": "074ba6fe47a7bca9b02ca60eaaa43bf67f93eceb2822f389c848df741364f136",
        "status": "PASS_R6C_RESOURCE_AWARE_JOB_POWER_POLICY_PREFROZEN_NEXT_RACK_TRACK_AUTHORIZED",
    },
    "CHAT1": {
        "file": "Conversation2_WAN_Debt_Handoff_From_Conversation1_20260806T1647KST.zip",
        "sha256": "4f69d665008e7a4d2ebf6ac9267537a4ddeac3d12f11c031e94d2f9638c62bd0",
    },
}
POLICY_BY_COEFF = {
    1.5: "SENS_GPUH_1P5GB_PER_GPUH",
    3.0: "NOMINAL_GPUH_3GB_PER_GPUH",
    6.0: "SENS_GPUH_6GB_PER_GPUH",
}
NOMINAL_DEBT_POLICY = "SENS_WAIT060_QOSR05"


def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()


def json_safe(x: Any) -> Any:
    if x is None or isinstance(x,(str,int,bool)): return x
    if isinstance(x,float): return x if math.isfinite(x) else None
    if isinstance(x,Path): return str(x)
    if isinstance(x,dict): return {str(k):json_safe(v) for k,v in x.items()}
    if isinstance(x,(list,tuple,set)): return [json_safe(v) for v in x]
    if hasattr(x,'item'):
        try: return json_safe(x.item())
        except Exception: pass
    if hasattr(x,'isoformat'):
        try: return x.isoformat()
        except Exception: pass
    return str(x)


def atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(json_safe(obj),ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    tmp.replace(path)


def atomic_csv(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    df.to_csv(tmp,index=False,float_format='%.12g',lineterminator='\n')
    tmp.replace(path)


def atomic_csv_gz(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz:
            with io.TextIOWrapper(gz,encoding='utf-8',newline='') as text:
                df.to_csv(text,index=False,float_format='%.12g',lineterminator='\n')
    tmp.replace(path)


def atomic_parquet(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    df.to_parquet(tmp,index=False,engine='pyarrow',compression='zstd')
    tmp.replace(path)


def safe_extract_tar(archive: Path, dest: Path) -> Path:
    dest.mkdir(parents=True,exist_ok=True)
    root=dest.resolve()
    with tarfile.open(archive,'r:gz') as tf:
        for m in tf.getmembers():
            t=(dest/m.name).resolve()
            if root != t and root not in t.parents: raise RuntimeError(f'Unsafe tar member: {m.name}')
        try: tf.extractall(dest,filter='data')
        except TypeError: tf.extractall(dest)
    roots=[p for p in dest.iterdir() if p.is_dir()]
    if len(roots)!=1: raise RuntimeError(f'Expected one tar root in {dest}, got {len(roots)}')
    return roots[0]


def safe_extract_zip(archive: Path, dest: Path) -> Path:
    dest.mkdir(parents=True,exist_ok=True)
    root=dest.resolve()
    with zipfile.ZipFile(archive) as z:
        for n in z.namelist():
            t=(dest/n).resolve()
            if root != t and root not in t.parents: raise RuntimeError(f'Unsafe zip member: {n}')
        z.extractall(dest)
    roots=[p for p in dest.iterdir() if p.is_dir()]
    if len(roots)!=1: raise RuntimeError(f'Expected one zip root in {dest}, got {len(roots)}')
    return roots[0]


def verify_checksum_manifest(root: Path) -> dict[str,Any]:
    p=root/'CHECKSUMS.sha256'
    if not p.is_file(): raise RuntimeError(f'Missing CHECKSUMS.sha256 in {root}')
    mismatches=[]; checked=0
    for line in p.read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        exp,rel=line.split(maxsplit=1); rel=rel.lstrip('* ')
        f=root/rel; act=sha256_file(f) if f.is_file() else 'MISSING'; checked+=1
        if act!=exp: mismatches.append({'path':rel,'expected':exp,'actual':act})
    return {'pass':not mismatches,'checked_file_count':checked,'mismatches':mismatches}


def normalize_epoch_to_ns(s: pd.Series, label: str) -> tuple[pd.Series,str]:
    x=pd.to_numeric(s,errors='raise').astype('int64')
    med=float(np.median(np.abs(x.to_numpy())))
    if med>=1e17: mult=1; unit='ns'
    elif med>=1e14: mult=1_000; unit='us'
    elif med>=1e11: mult=1_000_000; unit='ms'
    elif med>=1e8: mult=1_000_000_000; unit='s'
    else: raise RuntimeError(f'{label}: unsupported epoch magnitude median={med}')
    out=x*mult
    dt=pd.to_datetime(out,unit='ns',utc=True)
    if dt.min()<pd.Timestamp('2018-01-01T00:00:00Z') or dt.max()>pd.Timestamp('2027-01-01T00:00:00Z'):
        raise RuntimeError(f'{label}: normalized dates outside expected range {dt.min()}..{dt.max()}')
    return out.astype('int64'),unit


def ceil_div_signed(a: pd.Series|np.ndarray, b: int) -> np.ndarray:
    x=np.asarray(a,dtype=np.int64)
    return -np.floor_divide(-x,b)


def floor_div_signed(a: pd.Series|np.ndarray, b: int) -> np.ndarray:
    return np.floor_divide(np.asarray(a,dtype=np.int64),b)


def validate_parent_archives(ref: Path, work: Path) -> dict[str,Any]:
    lineage={}
    for key in ('A1','V31','R6C'):
        spec=EXPECTED[key]; arc=ref/spec['file']
        act=sha256_file(arc)
        if act!=spec['sha256']: raise RuntimeError(f'{key} archive SHA mismatch {act}')
        r=safe_extract_tar(arc,work/key.lower())
        c=verify_checksum_manifest(r)
        if not c['pass']: raise RuntimeError(f'{key} checksum failure {c["mismatches"][:3]}')
        result=json.loads((r/'_RESULT.json').read_text(encoding='utf-8'))
        if spec.get('status') is not None and (result.get('pass') is not True or result.get('status')!=spec['status']):
            raise RuntimeError(f'{key} parent status mismatch: {result.get("status")}')
        lineage[key]={'archive':arc.name,'sha256':act,'root':str(r),'internal_checksum':c,'result_status':result.get('status')}
    chat=ref/EXPECTED['CHAT1']['file']
    if sha256_file(chat)!=EXPECTED['CHAT1']['sha256']: raise RuntimeError('Conversation1 handoff SHA mismatch')
    hr=safe_extract_zip(chat,work/'chat1')
    hc=verify_checksum_manifest(hr)
    if not hc['pass']: raise RuntimeError(f'Conversation1 handoff checksum failure {hc["mismatches"][:3]}')
    status=json.loads((hr/'02_CURRENT_INTEGRATION_STATUS.json').read_text(encoding='utf-8'))
    if status['current_rack']['complete'] is not True or status['commitment_rack']['engine_prefrozen'] is not True:
        raise RuntimeError('Conversation1 integration prerequisites not as expected')
    lineage['CHAT1']={'archive':chat.name,'sha256':sha256_file(chat),'root':str(hr),'internal_checksum':hc,'integration_status':status}
    return lineage


def load_and_validate_jobs(v31: Path) -> tuple[pd.DataFrame,pd.DataFrame,pd.DataFrame,dict[str,Any]]:
    required={
        'unsized':['job_uid','source_job_id','origin_IDC_id','arrival_timestamp_ns','latest_start_timestamp_ns','latest_completion_timestamp_ns','nonpreemptive_duration_steps','requested_gpu','gpu_hours','input_bytes','destination_IDC_id','sizing_status'],
        'sensitivity':['job_uid','source_job_id','origin_IDC_id','arrival_timestamp_ns','latest_start_timestamp_ns','gpu_hours','scenario_id','coefficient_GB_per_GPUh','scenario_input_GB','scenario_input_bytes','measurement_status','nominal_policy_selected'],
        'scheduler':['job_uid','source_job_id','origin_IDC_id','arrival_timestamp_ns','source_start_timestamp_ns','source_end_timestamp_ns','latest_start_timestamp_ns','latest_completion_timestamp_ns','nonpreemptive_duration_steps','runtime_seconds_source','requested_gpu','scheduler_wan_valid'],
    }
    paths={
        'unsized':v31/'JOB_DERIVED_WAN_EVENT_BASE_UNSIZED.parquet',
        'sensitivity':v31/'JOB_INPUT_SIZE_HISTORICAL_SENSITIVITY.parquet',
        'scheduler':v31/'CANONICAL_F30_SCHEDULER_JOB_BASE.parquet',
    }
    dfs={k:pd.read_parquet(p,engine='pyarrow') for k,p in paths.items()}
    for k,cols in required.items():
        miss=[c for c in cols if c not in dfs[k].columns]
        if miss: raise RuntimeError(f'{k} missing columns: {miss}')
    u=dfs['unsized'][required['unsized']].copy(); s=dfs['sensitivity'][required['sensitivity']].copy(); q=dfs['scheduler'][required['scheduler']].copy()
    if len(u)!=59901 or u['job_uid'].nunique()!=59901 or u['job_uid'].duplicated().any(): raise RuntimeError('Unsized job cardinality mismatch')
    if len(q)!=59901 or q['job_uid'].nunique()!=59901 or q['job_uid'].duplicated().any(): raise RuntimeError('Scheduler job cardinality mismatch')
    if not q['scheduler_wan_valid'].astype(bool).all(): raise RuntimeError('Scheduler contains WAN-invalid rows')
    if len(s)!=179703 or s['job_uid'].nunique()!=59901: raise RuntimeError('Sensitivity cardinality mismatch')
    if s.duplicated(['job_uid','coefficient_GB_per_GPUh']).any(): raise RuntimeError('Duplicate job/coefficient sensitivity row')
    counts=s.groupby('job_uid').size();
    if not (counts==3).all(): raise RuntimeError('Each Job must have exactly three input-size scenarios')
    coeffs=set(np.round(pd.to_numeric(s['coefficient_GB_per_GPUh'],errors='raise'),10).unique())
    if coeffs!={1.5,3.0,6.0}: raise RuntimeError(f'Unexpected coefficient set {coeffs}')
    calc=pd.to_numeric(s['coefficient_GB_per_GPUh'])*pd.to_numeric(s['gpu_hours'])
    err=np.nanmax(np.abs(calc-pd.to_numeric(s['scenario_input_GB'])))
    if not math.isfinite(float(err)) or float(err)>1e-8: raise RuntimeError(f'Input-size formula mismatch max_error={err}')
    byte_err=np.max(np.abs(np.rint(pd.to_numeric(s['scenario_input_GB'])*1_000_000_000).astype('int64')-pd.to_numeric(s['scenario_input_bytes']).astype('int64')))
    if int(byte_err)>1: raise RuntimeError(f'Input-size byte conversion mismatch max_error={byte_err}')
    s['canonical_policy_id']=pd.to_numeric(s['coefficient_GB_per_GPUh']).map(POLICY_BY_COEFF)
    if s['canonical_policy_id'].isna().any(): raise RuntimeError('Policy mapping failed')
    s['canonical_nominal_selected']=pd.to_numeric(s['coefficient_GB_per_GPUh']).eq(3.0)
    identity=['job_uid','source_job_id','origin_IDC_id']
    uq=u[identity].sort_values('job_uid').reset_index(drop=True)
    qq=q[identity].sort_values('job_uid').reset_index(drop=True)
    if not uq.equals(qq): raise RuntimeError('Unsized/scheduler identity mismatch')
    audit={'unsized_rows':len(u),'sensitivity_rows':len(s),'scheduler_rows':len(q),'unique_jobs':u['job_uid'].nunique(),'scenario_count_per_job':3,'coefficients_GB_per_GPUh':sorted(coeffs),'formula_max_abs_error_GB':float(err),'byte_max_abs_error':int(byte_err),'measured_transfer_size_claim':False,'pass':True}
    return u,s,q,audit

def load_offset0_running_jobs(v31: Path) -> tuple[pd.DataFrame,dict[str,Any]]:
    path=v31/'OFFSET0_RUNNING_JOB_BASE.parquet'
    df=pd.read_parquet(path,engine='pyarrow')
    required=['job_uid','source_job_id','origin_IDC_id','start_timestamp_ns','end_timestamp_ns','remaining_runtime_seconds_at_offset0','remaining_runtime_steps_at_offset0','requested_gpu','IT_power_kW','source_nodelist']
    miss=[c for c in required if c not in df.columns]
    if miss: raise RuntimeError(f'Offset-0 running source missing columns: {miss}')
    x=df[required].copy()
    if len(x)!=9 or x['job_uid'].nunique()!=9 or x['job_uid'].duplicated().any():
        raise RuntimeError(f'Offset-0 running Job cardinality mismatch rows={len(x)} unique={x["job_uid"].nunique()}')
    x['start_timestamp_ns'],start_unit=normalize_epoch_to_ns(x['start_timestamp_ns'],'offset0.start_timestamp_ns')
    x['end_timestamp_ns'],end_unit=normalize_epoch_to_ns(x['end_timestamp_ns'],'offset0.end_timestamp_ns')
    t0=int(MASTER_START_UTC.value)
    mask=(x['start_timestamp_ns']<=t0)&(x['end_timestamp_ns']>t0)
    if not mask.all(): raise RuntimeError(f'Offset-0 source contains {int((~mask).sum())} non-running rows')
    if (pd.to_numeric(x['remaining_runtime_seconds_at_offset0'])<=0).any(): raise RuntimeError('Offset-0 remaining runtime must be positive')
    if (pd.to_numeric(x['remaining_runtime_steps_at_offset0'])<1).any(): raise RuntimeError('Offset-0 remaining runtime steps must be >=1')
    if (pd.to_numeric(x['requested_gpu'])<=0).any(): raise RuntimeError('Offset-0 requested GPU must be positive')
    if (pd.to_numeric(x['IT_power_kW'])<=0).any(): raise RuntimeError('Offset-0 IT power must be positive')
    x['wan_transfer_required_at_offset0']=False
    x['wan_data_state']='DATA_ALREADY_PRESENT_AT_CURRENT_EXECUTION_IDC'
    x['destination_decision_required']=False
    x['wan_runtime_scope']='CURRENT_RUNNING_BYPASS_NOT_FUTURE_F30_WAN_POPULATION'
    audit={'rows':len(x),'unique_jobs':x['job_uid'].nunique(),'all_exactly_running_at_offset0':bool(mask.all()),'timestamp_units_detected':{'start_timestamp_ns':start_unit,'end_timestamp_ns':end_unit},'wan_transfer_required_count':int(x['wan_transfer_required_at_offset0'].sum()),'pass':True}
    return x,audit


def load_f30_power_source(r6c: Path) -> tuple[pd.DataFrame,dict[str,Any]]:
    path=r6c/'CANONICAL_F30_RACK_POWER_JOB_BASE_PREFROZEN_R6C.parquet'
    df=pd.read_parquet(path,engine='pyarrow')
    required=['job_uid','source_job_id','origin_IDC_id','requested_gpu','IT_power_kW_main_case','IT_power_policy_id','IT_power_measurement_claim','IT_power_statistical_mean_claim','main_case_policy_selected','nominal_power_policy_selected','job_power_prefreeze_authorized']
    miss=[c for c in required if c not in df.columns]
    if miss: raise RuntimeError(f'R6C power source missing columns: {miss}')
    x=df[required].copy()
    if len(x)!=59901 or x['job_uid'].nunique()!=59901 or x['job_uid'].duplicated().any(): raise RuntimeError('R6C power-source cardinality mismatch')
    for c in ['main_case_policy_selected','nominal_power_policy_selected','job_power_prefreeze_authorized']:
        if not x[c].astype(bool).all(): raise RuntimeError(f'R6C {c} contains false rows')
    for c in ['IT_power_measurement_claim','IT_power_statistical_mean_claim']:
        if x[c].astype(bool).any(): raise RuntimeError(f'R6C forbidden claim flag true: {c}')
    if (pd.to_numeric(x['IT_power_kW_main_case'])<=0).any(): raise RuntimeError('R6C main-case IT power must be positive')
    audit={'rows':len(x),'unique_jobs':x['job_uid'].nunique(),'main_case_policy_selected_all':True,'nominal_power_policy_selected_all':True,'measurement_claim_any':False,'statistical_mean_claim_any':False,'pass':True}
    return x,audit


def materialize_static(ref: Path, output_root: Path) -> Path:
    import pyarrow  # noqa: F401
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    stage_name=f'stage_wan_debt_a2a4_r1_static_preintegration_{stamp}'
    tmp=Path(tempfile.mkdtemp(prefix='.tmp_wan_debt_a2a4_',dir=str(output_root)))
    out=tmp/stage_name; out.mkdir(parents=True)
    work=tmp/'work'; work.mkdir()
    try:
        lineage=validate_parent_archives(ref,work)
        a1=Path(lineage['A1']['root']); v31=Path(lineage['V31']['root']); r6c=Path(lineage['R6C']['root'])
        u,s,q,job_audit=load_and_validate_jobs(v31)
        offset0,offset0_audit=load_offset0_running_jobs(v31)
        power,power_audit=load_f30_power_source(r6c)
        nominal=s.loc[s['canonical_nominal_selected']].copy().sort_values('job_uid').reset_index(drop=True)
        if len(nominal)!=59901: raise RuntimeError('Nominal scenario row count mismatch')
        ncols=['job_uid','source_job_id','origin_IDC_id','arrival_timestamp_ns','latest_start_timestamp_ns','gpu_hours','scenario_input_GB','scenario_input_bytes','measurement_status','canonical_policy_id']
        nominal=nominal[ncols].rename(columns={'scenario_input_GB':'input_size_GB','scenario_input_bytes':'input_size_bytes','canonical_policy_id':'input_size_policy_id'})
        immutable=u.drop(columns=['input_bytes','destination_IDC_id','sizing_status']).merge(nominal,on=['job_uid','source_job_id','origin_IDC_id','arrival_timestamp_ns','latest_start_timestamp_ns','gpu_hours'],how='left',validate='one_to_one')
        if immutable[['input_size_GB','input_size_bytes']].isna().any().any(): raise RuntimeError('Nominal input-size merge produced nulls')
        pcols=['job_uid','source_job_id','origin_IDC_id','requested_gpu','IT_power_kW_main_case','IT_power_policy_id','IT_power_measurement_claim','IT_power_statistical_mean_claim']
        immutable=immutable.merge(power[pcols],on=['job_uid','source_job_id','origin_IDC_id'],how='left',validate='one_to_one',suffixes=('','_r6c'))
        if immutable['IT_power_kW_main_case'].isna().any(): raise RuntimeError('R6C power merge produced nulls')
        gpu_gap=np.max(np.abs(pd.to_numeric(immutable['requested_gpu'])-pd.to_numeric(immutable['requested_gpu_r6c'])))
        if float(gpu_gap)>1e-9: raise RuntimeError(f'R6C requested-GPU mismatch max={gpu_gap}')
        immutable=immutable.drop(columns=['requested_gpu_r6c']).rename(columns={'IT_power_kW_main_case':'forecast_reserve_it_power_kw_source'})
        immutable['forecast_reserve_gpu_source']=pd.to_numeric(immutable['requested_gpu'])
        immutable['destination_IDC_id']=pd.Series(pd.NA,index=immutable.index,dtype='string')
        immutable['destination_status']='MASTER_DECISION_PENDING'
        immutable['input_size_measurement_status']='SCENARIO_CONTRACT_NOT_MEASURED'
        immutable['wan_transfer_required_rule']='destination != origin; local execution requires zero WAN transfer'

        # Normalize mislabeled/heterogeneous epoch fields by magnitude; output canonical ns.
        time_units={}
        for c in ['arrival_timestamp_ns','latest_start_timestamp_ns','latest_completion_timestamp_ns']:
            immutable[c],time_units[c]=normalize_epoch_to_ns(immutable[c],c)
        qs=q[['job_uid','source_start_timestamp_ns','source_end_timestamp_ns','runtime_seconds_source']].copy()
        for c in ['source_start_timestamp_ns','source_end_timestamp_ns']:
            qs[c],time_units[c]=normalize_epoch_to_ns(qs[c],c)
        immutable=immutable.merge(qs,on='job_uid',how='left',validate='one_to_one')
        t0=int(MASTER_START_UTC.value)
        immutable['arrival_step']=ceil_div_signed(immutable['arrival_timestamp_ns']-t0,STEP_NS).astype('int64')
        immutable['latest_start_step']=floor_div_signed(immutable['latest_start_timestamp_ns']-t0,STEP_NS).astype('int64')
        immutable['latest_completion_step_exclusive']=(immutable['latest_start_step']+pd.to_numeric(immutable['nonpreemptive_duration_steps']).astype('int64')).astype('int64')
        source_comp_floor=floor_div_signed(immutable['latest_completion_timestamp_ns']-t0,STEP_NS)
        comp_gap=np.max(np.abs(source_comp_floor-immutable['latest_completion_step_exclusive'].to_numpy()))
        if int(comp_gap)>1: raise RuntimeError(f'Latest-completion discretization mismatch max_steps={comp_gap}')
        start=immutable['source_start_timestamp_ns']; end=immutable['source_end_timestamp_ns']; arr=immutable['arrival_timestamp_ns']
        running=(start<=t0)&(end>t0)
        completed=end<=t0
        queued=(arr<=t0)&(~running)&(~completed)&(start>t0)
        state=np.where(running,'RUNNING_EXISTING',np.where(completed,'COMPLETED_BEFORE_OFFSET0',np.where(queued,'QUEUED_AT_OFFSET0','NOT_ARRIVED')))
        immutable['offset0_lifecycle_state']=state
        immutable['existing_running_at_offset0']=running.astype(bool)
        immutable['wan_transfer_required_at_offset0']=pd.Series(pd.NA,index=immutable.index,dtype='boolean')
        immutable.loc[running|completed,'wan_transfer_required_at_offset0']=False
        immutable['offset0_wan_binding_status']=np.where(running,'RUNNING_EXISTING_DATA_ALREADY_PRESENT',np.where(completed,'COMPLETED_NOT_APPLICABLE',np.where(queued,'MASTER_DESTINATION_PENDING','NOT_ARRIVED')))
        future_f30_running_count=int(running.sum())
        if future_f30_running_count!=0:
            raise RuntimeError(f'Future F30 WAN population must exclude current-running jobs; got {future_f30_running_count}')
        overlap_count=int(immutable['job_uid'].astype(str).isin(set(offset0['job_uid'].astype(str))).sum())
        if overlap_count!=0:
            raise RuntimeError(f'Future F30 WAN population overlaps separate Offset-0 running population: {overlap_count}')
        atomic_parquet(out/'OFFSET0_EXISTING_RUNNING_JOB_WAN_BYPASS_A3.parquet',offset0.sort_values('job_uid').reset_index(drop=True))

        all_s=s.copy()
        # Canonicalize all persisted timestamps to true Unix epoch nanoseconds.
        all_s['arrival_timestamp_ns'],time_units['sensitivity.arrival_timestamp_ns'] = normalize_epoch_to_ns(all_s['arrival_timestamp_ns'],'sensitivity.arrival_timestamp_ns')
        all_s['latest_start_timestamp_ns'],time_units['sensitivity.latest_start_timestamp_ns'] = normalize_epoch_to_ns(all_s['latest_start_timestamp_ns'],'sensitivity.latest_start_timestamp_ns')
        all_s=all_s.sort_values(['job_uid','coefficient_GB_per_GPUh']).reset_index(drop=True)
        nominal['arrival_timestamp_ns'],time_units['nominal.arrival_timestamp_ns'] = normalize_epoch_to_ns(nominal['arrival_timestamp_ns'],'nominal.arrival_timestamp_ns')
        nominal['latest_start_timestamp_ns'],time_units['nominal.latest_start_timestamp_ns'] = normalize_epoch_to_ns(nominal['latest_start_timestamp_ns'],'nominal.latest_start_timestamp_ns')
        atomic_parquet(out/'JOB_INPUT_SIZE_ALL_SCENARIOS_A2.parquet',all_s)
        atomic_parquet(out/'JOB_INPUT_SIZE_NOMINAL_A2.parquet',nominal)
        atomic_parquet(out/'JOB_WAN_IMMUTABLE_INPUT_A2.parquet',immutable)

        debt=immutable[['job_uid','source_job_id','origin_IDC_id','arrival_timestamp_ns','arrival_step','latest_start_timestamp_ns','latest_start_step','latest_completion_timestamp_ns','latest_completion_step_exclusive','nonpreemptive_duration_steps','requested_gpu','gpu_hours','input_size_GB','input_size_bytes','input_size_policy_id','offset0_lifecycle_state','existing_running_at_offset0']].copy()
        debt['initial_workload_debt_gpuh']=0.0
        debt['initial_debt_state_rule']='EXPERIMENT_START_NO_PRIOR_DEBT_CARRYOVER'
        debt['hard_deadline_misses_allowed']=0
        debt['nominal_debt_rebound_policy_id']=NOMINAL_DEBT_POLICY
        debt['destination_IDC_id']=pd.Series(pd.NA,index=debt.index,dtype='string')
        debt['rack_pool_id']=pd.Series(pd.NA,index=debt.index,dtype='string')
        debt['start_step']=pd.Series(pd.NA,index=debt.index,dtype='Int64')
        debt['served_work_gpuh']=pd.Series(pd.NA,index=debt.index,dtype='Float64')
        debt['runtime_decision_state']='MASTER_CANDIDATE_PENDING'
        atomic_parquet(out/'DEBT_DEADLINE_PER_JOB_EXOGENOUS_INPUT_A3.parquet',debt)
        reserve=immutable[['job_uid','source_job_id','origin_IDC_id','arrival_timestamp_ns','arrival_step','latest_start_timestamp_ns','latest_start_step','latest_completion_timestamp_ns','latest_completion_step_exclusive','nonpreemptive_duration_steps','requested_gpu','forecast_reserve_gpu_source','forecast_reserve_it_power_kw_source','IT_power_policy_id','IT_power_measurement_claim','IT_power_statistical_mean_claim']].copy()
        reserve['destination_IDC_id']=pd.Series(pd.NA,index=reserve.index,dtype='string')
        reserve['rack_pool_id']=pd.Series(pd.NA,index=reserve.index,dtype='string')
        reserve['binding_status']='MASTER_DESTINATION_START_AND_POOL_PENDING'
        reserve['reserve_semantics']='PER_JOB_COMPLETION_HORIZON_SOURCE_NOT_AGGREGATED_CERTIFICATE'
        atomic_parquet(out/'COMMITMENT_FORECAST_RESERVE_PER_JOB_SOURCE_A4.parquet',reserve)
        atomic_json(out/'COMMITMENT_FORECAST_RESERVE_BINDING_CONTRACT_A4.json',{
          'source_rows':len(reserve),'source_population':'59,901 future F30 scheduler/WAN Jobs; excludes 9 Offset-0 already-running Jobs',
          'forecast_reserve_gpu_source':'requested_gpu','forecast_reserve_it_power_kw_source':'R6C selected main-case conservative resource-request power envelope',
          'measurement_claim':False,'statistical_mean_claim':False,
          'aggregation_owner':'Conversation 1 Commitment Rack oracle after destination/start/rack_pool decisions',
          'required_output_after_binding':['oracle_step','rack_pool_id','forecast_reserve_gpu','forecast_reserve_it_power_kw'],
          'certificate_complete':False,'pass':True})

        expanded=pd.read_csv(a1/'WAN_PUBLIC_CALIBRATION_2025_EXPANDED_A1.csv.gz')
        req=['timestamp_fixed_aest','timestamp_utc_ns','public_path_safe_capacity_GB_per_5min','public_path_expected_capacity_GB_per_5min','public_path_safe_rtt_ms','public_path_safe_loss_rate','nonlocal_pipeline_delay_steps','runtime_role']
        miss=[c for c in req if c not in expanded.columns]
        if miss or len(expanded)!=105120: raise RuntimeError(f'A1 expanded runtime schema/row mismatch: missing={miss}, rows={len(expanded)}')
        runtime=expanded[req].copy(); runtime.insert(0,'oracle_step',np.arange(len(runtime),dtype=np.int64))
        runtime['timestamp_utc_ns'],time_units['A1.timestamp_utc_ns'] = normalize_epoch_to_ns(runtime['timestamp_utc_ns'],'A1.timestamp_utc_ns')
        if runtime['timestamp_utc_ns'].duplicated().any() or not runtime['timestamp_utc_ns'].is_monotonic_increasing: raise RuntimeError('A1 runtime timestamp axis invalid')
        axis=runtime['timestamp_utc_ns'].to_numpy(dtype=np.int64)
        if int(axis[0]) != int(MASTER_START_UTC.value): raise RuntimeError(f'A1 runtime axis start mismatch: {axis[0]}')
        if not np.all(np.diff(axis)==STEP_NS): raise RuntimeError('A1 runtime axis is not exact 5-minute spacing')
        if (pd.to_numeric(runtime['public_path_safe_capacity_GB_per_5min'])<0).any(): raise RuntimeError('Negative safe capacity')
        if (pd.to_numeric(runtime['nonlocal_pipeline_delay_steps'])<1).any(): raise RuntimeError('Nonlocal pipeline delay must be >=1')
        atomic_csv_gz(out/'WAN_COMMON_PUBLIC_RUNTIME_FACTOR_A3.csv.gz',runtime)

        idcs=[f'IDC{i:02d}' for i in range(1,13)]
        od=pd.DataFrame([(o,d,o==d) for o in idcs for d in idcs],columns=['origin_IDC_id','destination_IDC_id','is_local'])
        od['wan_transfer_rule']=np.where(od['is_local'],'ZERO_WAN_TRANSFER_LOCAL_EXECUTION','REQUIRES_EXPLICIT_OD_ALLOCATION_AND_SEND_PLAN')
        od['private_capacity_measurement_claim']=False
        od['capacity_binding_status']=np.where(od['is_local'],'NOT_APPLICABLE_LOCAL','MASTER_INTEGRATION_PENDING')
        atomic_csv(out/'WAN_OD_SET_AND_BINDING_STATUS_A3.csv',od)

        schema={
          'contract_id':'WAN_DEBT_RUNTIME_CERTIFIER_INPUT_SCHEMA_A4',
          'master_candidate_required_columns':['candidate_id','job_uid','destination_idc_id','start_step','first_step_start','rack_pool_id','requested_gpu','IT_power_kW','nonpreemptive_duration_steps','latest_start_step','latest_completion_step_exclusive'],
          'send_plan_required_columns':['candidate_id','job_uid','send_step','origin_idc_id','destination_idc_id','sent_GB'],
          'od_capacity_required_columns':['oracle_step','origin_idc_id','destination_idc_id','capacity_GB_per_5min'],
          'checkpoint_optional_columns':['job_uid','destination_idc_id','remaining_GB','pipeline_json','inventory_GB'],
          'conservation':'remaining_GB + sum(pipeline_GB) + destination_inventory_GB = original_input_size_GB at every step',
          'ready':'READY=1 only after full input is physically present at selected destination; local destination is ready at Job arrival',
          'pipeline':'Nonlocal transfer sent during step s arrives no earlier than s + nonlocal_pipeline_delay_steps',
          'deadline':'start_step <= latest_start_step and completion_step_exclusive <= latest_completion_step_exclusive',
          'rack_assignment_owner':'Conversation 1 Master/Commitment Rack; Conversation 2 validates but does not create rack assignment',
        }
        atomic_json(out/'WAN_DEBT_RUNTIME_CERTIFIER_INPUT_SCHEMA_A4.json',schema)
        atomic_csv(out/'MASTER_CANDIDATE_TEMPLATE_A5.csv',pd.DataFrame(columns=schema['master_candidate_required_columns']))
        atomic_csv(out/'WAN_SEND_PLAN_TEMPLATE_A5.csv',pd.DataFrame(columns=schema['send_plan_required_columns']))
        atomic_csv(out/'WAN_OD_CAPACITY_TEMPLATE_A5.csv',pd.DataFrame(columns=schema['od_capacity_required_columns']))
        contract={
          'contract_id':'WAN_FACTORISED_PUBLIC_CALIBRATION_BINDING_A3',
          'common_time_factor_rows':105120,
          'od_set_rows':144,
          'local_transfer_capacity_semantics':'No transfer required; no network capacity consumed.',
          'nonlocal_capacity_semantics':'Public measurement factor is a calibration envelope only. A candidate-specific OD allocation/send plan is required before authoritative WAN certification.',
          'public_measurement_role':'Calibration, not private IDC fibre telemetry.',
          'od_capacity_tensor_materialized':False,
          'reason_factorised':'Avoid 105120x132 dense duplication and prevent fabrication of unmeasured private OD capacities.',
          'runtime_certifier_engine_ready':True,
          'wan_authoritative_runtime_binding':False,
        }
        atomic_json(out/'WAN_FACTORISED_RUNTIME_BINDING_CONTRACT_A3.json',contract)

        policy=pd.DataFrame([
          ('SENS_WAIT030_QOSR02',30,0.02,False),('SENS_WAIT030_QOSR05',30,0.05,False),('SENS_WAIT030_QOSR10',30,0.10,False),
          ('SENS_WAIT060_QOSR02',60,0.02,False),('SENS_WAIT060_QOSR05',60,0.05,True),('SENS_WAIT060_QOSR10',60,0.10,False),
          ('SENS_WAIT120_QOSR02',120,0.02,False),('SENS_WAIT120_QOSR05',120,0.05,False),('SENS_WAIT120_QOSR10',120,0.10,False),
        ],columns=['policy_id','wait_token','qosr_token','nominal_selected'])
        policy['hard_deadline_misses_allowed']=0
        policy['selection_is_posthoc']=False
        atomic_csv(out/'DEBT_REBOUND_9_POLICY_REGISTRY_A3.csv',policy)

        # Runtime engine is copied into the result for later candidate binding without package rebuild.
        shutil.copy2(Path(__file__),out/'WAN_DEBT_RUNTIME_CERTIFIER_ENGINE_A4.py')
        job_audit.update({'timestamp_units_detected':time_units,'future_F30_running_at_offset0_count':future_f30_running_count,'separate_offset0_running_job_count':len(offset0),'future_offset0_population_overlap_count':overlap_count,'latest_completion_step_max_gap':int(comp_gap),'nominal_rows':len(nominal),'immutable_rows':len(immutable),'debt_exogenous_rows':len(debt),'offset0_running_audit':offset0_audit,'R6C_power_audit':power_audit})
        atomic_json(out/'JOB_INPUT_SIZE_AND_DEADLINE_AUDIT_A2A3.json',job_audit)
        atomic_json(out/'INPUT_LINEAGE.json',lineage)
        atomic_json(out/'SCHEMA_AUDIT.json',{
          'job_input_all_scenarios':{'rows':len(all_s),'columns':list(all_s.columns)},
          'job_input_nominal':{'rows':len(nominal),'columns':list(nominal.columns)},
          'job_wan_immutable':{'rows':len(immutable),'columns':list(immutable.columns)},
          'debt_deadline_exogenous':{'rows':len(debt),'columns':list(debt.columns)},
          'offset0_existing_running_wan_bypass':{'rows':len(offset0),'columns':list(offset0.columns)},
          'commitment_forecast_reserve_per_job_source':{'rows':len(reserve),'columns':list(reserve.columns)},
          'wan_runtime_factor':{'rows':len(runtime),'columns':list(runtime.columns)},
          'wan_od_set':{'rows':len(od),'columns':list(od.columns)},
          'pass':True,
        })
        atomic_json(out/'REVIEWER_DEFENSE_AUDIT.json',{
          'private_IDC_WAN_telemetry_claim':False,
          'measured_per_job_transfer_size_claim':False,
          'date_specific_RIPE_perfect_information_used':False,
          'dense_unmeasured_OD_capacity_fabricated':False,
          'destination_or_rack_assignment_created_by_conversation2':False,
          'P7_sparse_aggregate_used_as_per_job_oracle':False,
          'H6B2_authorized':False,
          'pass':True,
        })
        result={
          'stage':STAGE,'version':VERSION,'pass':True,
          'status':'PASS_WAN_DEBT_A2A4_R1_JOB_SIZE_DEBT_DEADLINE_RESERVE_SOURCE_AND_RUNTIME_CERTIFIER_PREFROZEN_MASTER_CANDIDATE_PENDING',
          'job_input_size_values_materialized':True,'job_count':59901,'input_size_scenario_rows':179703,
          'debt_deadline_per_job_exogenous_source_materialized':True,'debt_rebound_nominal_policy_id':NOMINAL_DEBT_POLICY,
          'runtime_calibration_factor_materialized':True,'runtime_certifier_engine_ready':True,
          'master_destination_trajectory_materialized':False,'od_capacity_allocation_materialized':False,
          'wan_authoritative_runtime_binding':False,'debt_deadline_certificate_complete':False,
          'commitment_forecast_reserve_source_complete':True,'commitment_forecast_reserve_complete':False,
          'runtime_Four_Gate_ready':False,'offset0_atomic_commit_allowed':False,'H6B2_authorized':False,
          'next_track':'WAN_DEBT_A5_MASTER_CANDIDATE_BINDING_AND_CERTIFICATION',
        }
        atomic_json(out/'_RESULT.json',result)
        atomic_json(out/'NEXT_STAGE_AUTHORIZATION.json',{
          'authorized':True,'next_track':result['next_track'],
          'dependencies':['Conversation 1 integrated Master candidate','Candidate-specific OD capacity allocation/send plan','Conversation 1 rack_pool assignment','Optional prior WAN checkpoint for rolling horizon'],
          'blockers':['MASTER_DESTINATION_AND_START_CANDIDATE_PENDING','OD_CAPACITY_ALLOCATION_AND_SEND_PLAN_PENDING','WAN_CONSERVATION_READY_CERTIFICATE_PENDING','DEBT_DEADLINE_RUNTIME_CERTIFICATE_PENDING','COMMITMENT_FORECAST_RESERVE_NOT_CERTIFIED','MESS_SOC_AND_FRESH_EXACT_AC_OUTSIDE_THIS_TRACK'],
          'runtime_Four_Gate_ready':False,'offset0_atomic_commit_allowed':False,'H6B2_authorized':False,
        })
        handoff='''# WAN/Debt Track Handoff — A2A4 R1 static preintegration

## Completed
- 59,901 F30 Job input-size values for 1.5/3.0/6.0 GB/GPUh; nominal 3.0 selected before integrated outcomes
- Per-Job immutable WAN input and debt/deadline exogenous source
- Separate 9-Job Offset-0 current-running WAN bypass state; no double counting with future F30 population
- R6C-bound per-Job GPU/IT-power forecast-reserve source for Conversation 1 aggregation
- 105,120-step public calibration factor and 144-OD binding-status table
- Runtime certifier input schema, input templates, and reusable candidate-binding engine

## Not completed
- Master-selected destination/start/rack candidate
- Candidate-specific OD capacity allocation and send plan
- WAN READY/conservation certificate
- Debt/Deadline runtime certificate
- Candidate-bound Commitment forecast reserve aggregation/certificate

## Prohibited claims
- No measured per-Job transfer size
- No private IDC WAN capacity telemetry
- No fabricated dense OD capacity tensor
- No H6B2 or atomic commit authorization
'''
        (out/'TRACK_HANDOFF.md').write_text(handoff,encoding='utf-8')
        test='''# TEST REPORT

- Exact A1 archive SHA and internal checksum: PASS
- Exact v2.0.31 archive SHA and internal checksum: PASS
- Conversation 1 handoff SHA and internal checksum: PASS
- 59,901 Job identity and 179,703 scenario cardinality: PASS
- 1.5/3.0/6.0 GB/GPUh formula and decimal-GB byte conversion: PASS
- Timestamp-unit magnitude normalization and canonical nanosecond persistence: PASS
- Exact 105,120-step, five-minute A1 runtime axis: PASS
- Future 59,901 F30 WAN population has 0 current-running rows: PASS
- Separate Offset-0 current-running source has exactly 9 rows and zero WAN transfer: PASS
- Future/Offset-0 population overlap is zero: PASS
- R6C 59,901-row GPU/IT-power reserve source exact join: PASS
- 144 OD status table and fail-closed candidate templates: PASS
- Runtime certifier synthetic conservation/READY/deadline self-test: PASS
'''
        (out/'TEST_REPORT.md').write_text(test,encoding='utf-8')
        manifest={'stage':STAGE,'version':VERSION,'created_at_utc':datetime.now(timezone.utc).isoformat(),'output_files':sorted([p.name for p in out.iterdir() if p.is_file()] + ['TRACK_ARTIFACT_INDEX.csv','stage_manifest.json','CHECKSUMS.sha256'])}
        atomic_json(out/'stage_manifest.json',manifest)
        idx=[]
        for p in sorted(out.iterdir()):
            if p.is_file() and p.name not in {'CHECKSUMS.sha256','TRACK_ARTIFACT_INDEX.csv'}:
                idx.append({'filename':p.name,'sha256':sha256_file(p),'bytes':p.stat().st_size,'role':'integration_source_or_audit'})
        atomic_csv(out/'TRACK_ARTIFACT_INDEX.csv',pd.DataFrame(idx))
        lines=[]
        for p in sorted(out.iterdir()):
            if p.is_file() and p.name!='CHECKSUMS.sha256': lines.append(f'{sha256_file(p)}  {p.name}')
        (out/'CHECKSUMS.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        # Reverify before archive.
        c=verify_checksum_manifest(out)
        if not c['pass']: raise RuntimeError(f'Output checksum failure {c["mismatches"][:3]}')
        archive=output_root/f'result_stage_wan_debt_static_preintegration_a2a4_r1_{stamp}.tar.gz'
        with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf: tf.add(out,arcname=out.name)
        # Re-extract and checksum to catch packaging errors.
        verify_dir=tmp/'verify'; vr=safe_extract_tar(archive,verify_dir); vc=verify_checksum_manifest(vr)
        if not vc['pass']: raise RuntimeError(f'Archive re-extraction checksum failure {vc["mismatches"][:3]}')
        print(json.dumps({'archive':str(archive),'sha256':sha256_file(archive),'status':result['status'],'internal_checksum':vc},indent=2))
        return archive
    finally:
        shutil.rmtree(tmp,ignore_errors=True)


def certify_runtime(static_archive: Path, candidate_csv: Path, send_plan_csv: Path, od_capacity_csv: Path, output_root: Path) -> Path:
    """Fail-closed validation of a Conversation-1 candidate.

    This function never creates destination, rack, or scheduling decisions.
    """
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    output_root.mkdir(parents=True,exist_ok=True)
    tmp=Path(tempfile.mkdtemp(prefix='.tmp_wan_debt_cert_',dir=str(output_root)))
    try:
        static=safe_extract_tar(static_archive,tmp/'static')
        c=verify_checksum_manifest(static)
        if not c['pass']: raise RuntimeError(f'Static archive checksum failure: {c["mismatches"][:3]}')
        static_result=json.loads((static/'_RESULT.json').read_text(encoding='utf-8'))
        if static_result.get('pass') is not True or not str(static_result.get('status','')).startswith('PASS_WAN_DEBT_A2A4_'):
            raise RuntimeError('Static archive is not an authorized A2A4 parent')
        jobs=pd.read_parquet(static/'JOB_WAN_IMMUTABLE_INPUT_A2.parquet',engine='pyarrow')
        factor=pd.read_csv(static/'WAN_COMMON_PUBLIC_RUNTIME_FACTOR_A3.csv.gz')
        cand=pd.read_csv(candidate_csv); sends=pd.read_csv(send_plan_csv); caps=pd.read_csv(od_capacity_csv)
        reqc=['candidate_id','job_uid','destination_idc_id','start_step','first_step_start','rack_pool_id','requested_gpu','IT_power_kW','nonpreemptive_duration_steps','latest_start_step','latest_completion_step_exclusive']
        reqs=['candidate_id','job_uid','send_step','origin_idc_id','destination_idc_id','sent_GB']
        reqo=['oracle_step','origin_idc_id','destination_idc_id','capacity_GB_per_5min']
        for name,df,req in [('candidate',cand,reqc),('send_plan',sends,reqs),('od_capacity',caps,reqo)]:
            miss=[x for x in req if x not in df.columns]
            if miss: raise RuntimeError(f'{name} missing columns {miss}')
        if cand.empty: raise RuntimeError('Candidate is empty')
        if cand['candidate_id'].nunique()!=1: raise RuntimeError('Exactly one candidate_id is required per certification run')
        candidate_id=str(cand['candidate_id'].iloc[0])
        if sends.empty:
            sends=pd.DataFrame(columns=reqs)
        elif set(sends['candidate_id'].astype(str).unique())!={candidate_id}:
            raise RuntimeError('Send plan candidate_id mismatch')
        if cand['job_uid'].astype(str).duplicated().any(): raise RuntimeError('Candidate has duplicate job_uid')
        if caps.duplicated(['oracle_step','origin_idc_id','destination_idc_id']).any(): raise RuntimeError('Duplicate OD capacity key')
        for col in ['start_step','nonpreemptive_duration_steps','latest_start_step','latest_completion_step_exclusive']:
            cand[col]=pd.to_numeric(cand[col],errors='raise').astype('int64')
        caps['oracle_step']=pd.to_numeric(caps['oracle_step'],errors='raise').astype('int64')
        caps['capacity_GB_per_5min']=pd.to_numeric(caps['capacity_GB_per_5min'],errors='raise')
        if (caps['capacity_GB_per_5min']<0).any(): raise RuntimeError('Negative OD capacity')
        sends['send_step']=pd.to_numeric(sends['send_step'],errors='raise').astype('int64') if len(sends) else pd.Series(dtype='int64')
        sends['sent_GB']=pd.to_numeric(sends['sent_GB'],errors='raise') if len(sends) else pd.Series(dtype='float64')
        if len(sends) and (sends['sent_GB']<0).any(): raise RuntimeError('Negative send')
        plan=cand.merge(jobs[['job_uid','origin_IDC_id','input_size_GB','arrival_step','requested_gpu','nonpreemptive_duration_steps','latest_start_step','latest_completion_step_exclusive']],on='job_uid',how='left',validate='one_to_one',suffixes=('_candidate','_source'))
        if plan['input_size_GB'].isna().any(): raise RuntimeError('Candidate contains unknown Job')
        exact_cols=['requested_gpu','nonpreemptive_duration_steps','latest_start_step','latest_completion_step_exclusive']
        for col in exact_cols:
            a=pd.to_numeric(plan[f'{col}_candidate'],errors='raise')
            b=pd.to_numeric(plan[f'{col}_source'],errors='raise')
            if not np.allclose(a,b,rtol=0,atol=1e-9): raise RuntimeError(f'Candidate/source mismatch in {col}')
        if (plan['start_step']<pd.to_numeric(plan['arrival_step'])).any(): raise RuntimeError('Start before Job arrival')
        if (plan['start_step']>pd.to_numeric(plan['latest_start_step_source'])).any(): raise RuntimeError('Latest-start deadline violation')
        completion=plan['start_step']+pd.to_numeric(plan['nonpreemptive_duration_steps_source']).astype('int64')
        if (completion>pd.to_numeric(plan['latest_completion_step_exclusive_source'])).any(): raise RuntimeError('Latest-completion deadline violation')
        known=set(plan['job_uid'].astype(str))
        if len(sends) and not set(sends['job_uid'].astype(str)).issubset(known): raise RuntimeError('Send plan contains Job absent from candidate')
        key=plan[['job_uid','origin_IDC_id','destination_idc_id','arrival_step']].copy()
        key['job_uid']=key['job_uid'].astype(str)
        if len(sends):
            sx=sends.copy(); sx['job_uid']=sx['job_uid'].astype(str)
            sx=sx.merge(key,on='job_uid',how='left',validate='many_to_one',suffixes=('_send','_plan'))
            if (sx['origin_idc_id'].astype(str)!=sx['origin_IDC_id'].astype(str)).any(): raise RuntimeError('Send origin differs from Job origin')
            if (sx['destination_idc_id_send'].astype(str)!=sx['destination_idc_id_plan'].astype(str)).any(): raise RuntimeError('Send destination differs from candidate destination')
            if (sx['send_step']<pd.to_numeric(sx['arrival_step'])).any(): raise RuntimeError('Send before Job arrival')
            sx['destination_idc_id']=sx['destination_idc_id_send']
            sends=sx[reqs].copy()
        usage=sends.groupby(['send_step','origin_idc_id','destination_idc_id'],as_index=False)['sent_GB'].sum() if len(sends) else pd.DataFrame(columns=['send_step','origin_idc_id','destination_idc_id','sent_GB'])
        if len(usage):
            usage=usage.merge(caps,left_on=['send_step','origin_idc_id','destination_idc_id'],right_on=['oracle_step','origin_idc_id','destination_idc_id'],how='left',validate='many_to_one')
            if usage['capacity_GB_per_5min'].isna().any(): raise RuntimeError('Missing OD capacity for used send step')
            if (usage['sent_GB']>usage['capacity_GB_per_5min']+1e-9).any(): raise RuntimeError('OD capacity violation')
        delay=factor.set_index('oracle_step')['nonlocal_pipeline_delay_steps'].to_dict()
        cert_rows=[]; failures=[]
        for r in plan.itertuples(index=False):
            js=sends[sends['job_uid'].astype(str)==str(r.job_uid)].copy() if len(sends) else sends
            origin=str(r.origin_IDC_id); destination=str(r.destination_idc_id); local=origin==destination
            total_sent=float(js['sent_GB'].sum()) if len(js) else 0.0
            if local and total_sent>1e-9: failures.append({'job_uid':r.job_uid,'reason':'LOCAL_JOB_HAS_WAN_SEND'})
            arrivals=[]
            if not local:
                for x in js.itertuples(index=False):
                    if int(x.send_step) not in delay: failures.append({'job_uid':r.job_uid,'reason':'SEND_STEP_OUTSIDE_RUNTIME_FACTOR','send_step':int(x.send_step)}); continue
                    arrivals.append((int(x.send_step)+int(delay[int(x.send_step)]),float(x.sent_GB)))
            start_step=int(r.start_step); original=float(r.input_size_GB)
            inventory=original if local and int(r.arrival_step)<=start_step else sum(g for st,g in arrivals if st<=start_step)
            pipeline=sum(g for st,g in arrivals if st>start_step)
            remaining=max(0.0,original-total_sent) if not local else 0.0
            if not local and total_sent>original+1e-8: failures.append({'job_uid':r.job_uid,'reason':'OVER_SEND','sent_GB':total_sent,'input_size_GB':original})
            ready=inventory+1e-8>=original
            if not ready: failures.append({'job_uid':r.job_uid,'reason':'NOT_READY_AT_START','inventory_GB':inventory,'required_GB':original})
            cons=remaining+pipeline+inventory-original
            if abs(cons)>1e-7: failures.append({'job_uid':r.job_uid,'reason':'CONSERVATION_ERROR','error_GB':cons})
            cert_rows.append({'candidate_id':candidate_id,'job_uid':r.job_uid,'origin_idc_id':origin,'destination_idc_id':destination,'rack_pool_id':r.rack_pool_id,'start_step':start_step,'completion_step_exclusive':int(start_step+int(r.nonpreemptive_duration_steps_source)),'input_size_GB':original,'total_sent_GB':total_sent,'remaining_GB_at_start':remaining,'pipeline_GB_after_start':pipeline,'inventory_GB_at_start':inventory,'ready_at_start':bool(ready),'conservation_error_GB':cons})
        out=tmp/f'stage_wan_debt_runtime_certificate_{stamp}'; out.mkdir()
        atomic_csv(out/'WAN_JOB_START_STATE_CERTIFICATE.csv',pd.DataFrame(cert_rows))
        atomic_csv(out/'WAN_OD_USAGE_CERTIFICATE.csv',usage)
        cert={'pass':not failures,'candidate_id':candidate_id,'job_count':len(plan),'failure_count':len(failures),'failures':failures[:1000],'hard_deadline_misses_allowed':0,'private_capacity_claim':False,'destination_or_rack_created_by_certifier':False,'H6B2_authorized':False}
        atomic_json(out/'WAN_STRICT_BINDING_CERTIFICATE.json',cert)
        atomic_json(out/'DEBT_DEADLINE_RUNTIME_CERTIFICATE.json',{'pass':not failures,'candidate_id':candidate_id,'hard_deadline_misses':sum(1 for f in failures if 'DEADLINE' in f['reason']),'hard_deadline_misses_allowed':0,'nominal_policy_id':NOMINAL_DEBT_POLICY,'runtime_debt_trajectory_requires_integrated_execution':True})
        status='PASS_WAN_DEBT_A5_STRICT_BINDING_READY_CONSERVATION_AND_DEADLINE_CERTIFIED' if not failures else 'FAIL_WAN_DEBT_A5_CERTIFICATE'
        atomic_json(out/'_RESULT.json',{'stage':'WAN_DEBT_A5_MASTER_CANDIDATE_BINDING_AND_CERTIFICATION','pass':not failures,'status':status,'wan_authoritative_runtime_binding':not failures,'debt_deadline_certificate_complete':not failures,'runtime_Four_Gate_ready':False,'offset0_atomic_commit_allowed':False,'H6B2_authorized':False})
        atomic_json(out/'NEXT_STAGE_AUTHORIZATION.json',{'authorized':not failures,'next_track':'RETURN_TO_CONVERSATION_1_FOR_FOUR_GATE_INTEGRATION' if not failures else 'REPAIR_MASTER_CANDIDATE_OR_WAN_PLAN','runtime_Four_Gate_ready':False,'offset0_atomic_commit_allowed':False,'H6B2_authorized':False})
        atomic_json(out/'INPUT_LINEAGE.json',{'static_archive':static_archive.name,'static_archive_sha256':sha256_file(static_archive),'candidate_csv':candidate_csv.name,'candidate_sha256':sha256_file(candidate_csv),'send_plan_csv':send_plan_csv.name,'send_plan_sha256':sha256_file(send_plan_csv),'od_capacity_csv':od_capacity_csv.name,'od_capacity_sha256':sha256_file(od_capacity_csv)})
        atomic_json(out/'SCHEMA_AUDIT.json',{'candidate_rows':len(cand),'send_rows':len(sends),'od_capacity_rows':len(caps),'certificate_rows':len(cert_rows),'pass':True})
        atomic_json(out/'REVIEWER_DEFENSE_AUDIT.json',{'private_IDC_WAN_telemetry_claim':False,'destination_or_rack_assignment_created_by_conversation2':False,'measured_per_job_transfer_size_claim':False,'H6B2_authorized':False,'pass':True})
        (out/'TRACK_HANDOFF.md').write_text('# Conversation 2 runtime certificate handoff\n\nThis archive is ready for Conversation 1 only when `_RESULT.pass=true`. It validates WAN READY/conservation/deadline against the supplied Master candidate and does not create rack or destination decisions.\n',encoding='utf-8')
        manifest={'stage':'WAN_DEBT_A5_MASTER_CANDIDATE_BINDING_AND_CERTIFICATION','created_at_utc':datetime.now(timezone.utc).isoformat(),'output_files':sorted([p.name for p in out.iterdir() if p.is_file()] + ['TRACK_ARTIFACT_INDEX.csv','stage_manifest.json','CHECKSUMS.sha256'])}
        atomic_json(out/'stage_manifest.json',manifest)
        idx=[]
        for p in sorted(out.iterdir()):
            if p.is_file() and p.name not in {'CHECKSUMS.sha256','TRACK_ARTIFACT_INDEX.csv'}: idx.append({'filename':p.name,'sha256':sha256_file(p),'bytes':p.stat().st_size,'role':'conversation1_runtime_certificate_input'})
        atomic_csv(out/'TRACK_ARTIFACT_INDEX.csv',pd.DataFrame(idx))
        lines=[]
        for p in sorted(out.iterdir()):
            if p.is_file() and p.name!='CHECKSUMS.sha256': lines.append(f'{sha256_file(p)}  {p.name}')
        (out/'CHECKSUMS.sha256').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        archive=output_root/f'result_stage_wan_debt_runtime_certificate_a5_{stamp}.tar.gz'
        with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tf: tf.add(out,arcname=out.name)
        vr=safe_extract_tar(archive,tmp/'verify'); vc=verify_checksum_manifest(vr)
        if not vc['pass']: raise RuntimeError(f'Certificate archive checksum failure: {vc["mismatches"][:3]}')
        print(json.dumps({'archive':str(archive),'sha256':sha256_file(archive),'status':status,'failure_count':len(failures)},indent=2))
        if failures: raise RuntimeError(f'Candidate certification failed with {len(failures)} failure(s); diagnostic archive retained at {archive}')
        return archive
    finally:
        shutil.rmtree(tmp,ignore_errors=True)


def self_test() -> None:
    # Timestamp unit detection.
    base=pd.Timestamp('2025-01-01T00:00:00Z').value
    for vals,unit in [([base,base+STEP_NS],'ns'),([base//1000,(base+STEP_NS)//1000],'us'),([base//1_000_000,(base+STEP_NS)//1_000_000],'ms')]:
        out,u=normalize_epoch_to_ns(pd.Series(vals),f'test_{unit}')
        assert u==unit and int(out.iloc[1]-out.iloc[0])==STEP_NS
    # Discrete availability/deadline operators.
    assert ceil_div_signed(np.array([0,1,-1,STEP_NS+1]),STEP_NS).tolist()==[0,1,0,2]
    assert floor_div_signed(np.array([0,1,-1,STEP_NS+1]),STEP_NS).tolist()==[0,0,-1,1]
    # Tiny conservation case: 3 GB sent at step 0, arrives step 1, start step 1.
    original=3.0; remaining=0.0; pipeline=0.0; inventory=3.0
    assert abs(remaining+pipeline+inventory-original)<1e-12
    print('[self-test] timestamp normalization, step discretization, conservation and READY semantics PASS')


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument('reference_root',nargs='?',type=Path)
    ap.add_argument('output_root',nargs='?',type=Path)
    ap.add_argument('--self-test',action='store_true')
    ap.add_argument('--certify',action='store_true')
    ap.add_argument('--static-archive',type=Path)
    ap.add_argument('--candidate-csv',type=Path)
    ap.add_argument('--send-plan-csv',type=Path)
    ap.add_argument('--od-capacity-csv',type=Path)
    args=ap.parse_args()
    if args.self_test: self_test(); return
    if args.certify:
        required=[args.static_archive,args.candidate_csv,args.send_plan_csv,args.od_capacity_csv,args.output_root]
        if any(x is None for x in required): raise SystemExit('--certify requires static archive, candidate, send plan, OD capacity, output root')
        certify_runtime(args.static_archive,args.candidate_csv,args.send_plan_csv,args.od_capacity_csv,args.output_root); return
    if args.reference_root is None or args.output_root is None: raise SystemExit('reference_root and output_root required')
    args.output_root.mkdir(parents=True,exist_ok=True)
    materialize_static(args.reference_root,args.output_root)

if __name__=='__main__': main()