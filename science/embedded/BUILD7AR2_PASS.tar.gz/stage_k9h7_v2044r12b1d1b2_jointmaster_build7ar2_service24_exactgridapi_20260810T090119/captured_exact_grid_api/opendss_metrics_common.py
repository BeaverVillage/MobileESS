#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import traceback
from pathlib import Path
from typing import Any, Iterable

V_MIN_PU = 0.95
V_MAX_PU = 1.05
LOADING_LIMIT_PU = 1.0
TOL = 1e-8


def json_dump(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def fnum(v: Any, label: str) -> float:
    try:
        x = float(v)
    except Exception as e:
        raise RuntimeError(f"non-numeric {label}: {v!r}") from e
    if not math.isfinite(x):
        raise RuntimeError(f"non-finite {label}: {v!r}")
    return x


def bval(v: Any) -> bool:
    return str(v).strip().lower() in {"1", "true", "yes", "y"}


def q(path: Path) -> str:
    return str(path.resolve()).replace('"', '""')


def get_error(odd: Any) -> dict[str, Any]:
    try:
        number = int(odd.Error.Number() or 0)
    except Exception:
        number = 0
    try:
        desc = str(odd.Error.Description() or "")
    except Exception:
        desc = ""
    return {"number": number, "description": desc}


def cmd(odd: Any, command: str, audit: list[dict[str, Any]], *, fatal: bool = True) -> str:
    result = odd.Text.Command(command)
    err = get_error(odd)
    row = {"command": command, "result": str(result or ""), "error_number": err["number"], "error_description": err["description"]}
    audit.append(row)
    if fatal and err["number"] != 0:
        raise RuntimeError(f"OpenDSS command failed: {command}; error={err}")
    return str(result or "")


def set_named_load(odd: Any, name: str, kw: float, kvar: float) -> None:
    all_names = {str(n).lower() for n in odd.Loads.AllNames()}
    if name.lower() not in all_names:
        raise RuntimeError(f"missing OpenDSS Load.{name}")
    odd.Loads.Name(name)
    odd.Loads.kW(float(kw))
    odd.Loads.kvar(float(kvar))


def set_named_generator(odd: Any, name: str, kw: float, kvar: float) -> None:
    all_names = {str(n).lower() for n in odd.Generators.AllNames()}
    if name.lower() not in all_names:
        raise RuntimeError(f"missing OpenDSS Generator.{name}")
    odd.Generators.Name(name)
    odd.Generators.kW(float(kw))
    odd.Generators.kvar(float(kvar))


def validate_inputs(root: Path) -> dict[str, Any]:
    fac = read_csv(root / "FACILITY_PQ_FALLBACK_CANDIDATE.csv")
    phase = read_csv(root / "PHASE_INJECTION_C00_A020_AC_REMEDIATION_CANDIDATE.csv")
    mess = read_csv(root / "MESS_STATE_AC_REMEDIATION_CANDIDATE.csv")
    remed = read_csv(root / "MESS_REACTIVE_REMEDIATION_CANDIDATE.csv")
    if len(fac) != 12 or len(mess) != 4 or len(remed) != 4 or len(phase) != 48:
        raise RuntimeError(
            f"candidate row-count contract failed: facility={len(fac)}, mess={len(mess)}, "
            f"remediation={len(remed)}, phase={len(phase)}"
        )
    expected_idcs = {f"IDC{i:02d}" for i in range(1, 13)}
    if {r["idc_id"] for r in fac} != expected_idcs:
        raise RuntimeError("facility IDC identity mismatch")
    if any(r.get("phase_binding") != "C00/A020" for r in fac):
        raise RuntimeError("facility phase binding is not C00/A020")
    if any(str(r.get("within_provisional_transformer_template", "")).strip().lower() not in {"true", "1"} for r in fac):
        raise RuntimeError("provisional 750-kVA transformer template preflight is not all PASS")
    if any(str(r.get("final_transformer_nameplate_authorized", "")).strip().lower() in {"true", "1"} for r in fac):
        raise RuntimeError("candidate incorrectly authorizes final transformer nameplate")

    phase_by_asset: dict[str, list[dict[str, str]]] = {}
    for r in phase:
        if r.get("phase_allocation_id") != "C00" or r.get("phase_allocation_lineage_id") != "A020":
            raise RuntimeError(f"C00/A020 binding mismatch for {r.get('asset_id')}")
        if r.get("runtime_element_binding_status") != "EXACT_GENERATED_PCC_V3_BOUND":
            raise RuntimeError(f"runtime element binding not exact for {r.get('asset_id')}")
        phase_by_asset.setdefault(r["asset_id"], []).append(r)

    for fr in fac:
        rows = phase_by_asset.get(fr["idc_id"], [])
        if len(rows) != 3 or {r["phase"] for r in rows} != {"A", "B", "C"}:
            raise RuntimeError(f"phase rows incomplete for {fr['idc_id']}")
        p = sum(fnum(r["p_kw_consumption"], "phase P") for r in rows)
        qv = sum(fnum(r["q_kvar_consumption_lagging"], "phase Q") for r in rows)
        if abs(p - fnum(fr["facility_active_power_kw"], "facility P")) > 2e-8:
            raise RuntimeError(f"phase P conservation failed for {fr['idc_id']}: {p}")
        if abs(qv - fnum(fr["facility_reactive_power_kvar"], "facility Q")) > 2e-8:
            raise RuntimeError(f"phase Q conservation failed for {fr['idc_id']}: {qv}")

    expected_mess = {
        "MESS01": ("IDC01", 0.0, 0.0),
        "MESS02": ("IDC06", 0.0, 0.0),
        "MESS03": ("IDC10", 0.0, -25.0),
        "MESS04": ("IDC12", 0.0, 0.0),
    }
    mess_by_id = {r["mess_id"]: r for r in mess}
    remed_by_id = {r["mess_id"]: r for r in remed}
    if set(mess_by_id) != set(expected_mess) or set(remed_by_id) != set(expected_mess):
        raise RuntimeError("Four-MESS identity mismatch")
    for mid, (loc, ep, eq) in expected_mess.items():
        mr = mess_by_id[mid]
        rr = remed_by_id[mid]
        if mr["location_idc_id"] != loc or rr["location_idc_id"] != loc:
            raise RuntimeError(f"{mid} location mismatch")
        p = fnum(mr["p_kw"], "MESS p_kw")
        qv = fnum(mr["q_kvar"], "MESS q_kvar")
        rp = fnum(rr["p_kw_grid_injection"], "remediation P")
        rq = fnum(rr["q_kvar_grid_injection"], "remediation Q")
        load_q = fnum(rr["opendss_charge_load_kvar_positive_absorption"], "OpenDSS load kvar")
        if abs(p-ep) > TOL or abs(qv-eq) > TOL or abs(rp-ep) > TOL or abs(rq-eq) > TOL:
            raise RuntimeError(f"{mid} remediation setpoint mismatch")
        if abs(load_q - max(-eq, 0.0)) > TOL:
            raise RuntimeError(f"{mid} grid/OpenDSS reactive sign conversion mismatch")
        plim = fnum(mr["pcs_p_limit_kw"], "MESS P limit")
        slim = fnum(mr["pcs_s_limit_kva"], "MESS S limit")
        if abs(plim-550.0) > TOL or abs(slim-700.0) > TOL:
            raise RuntimeError(f"{mid} P550_S700 contract mismatch")
        if abs(p) > plim + TOL or p*p + qv*qv > slim*slim + 1e-6:
            raise RuntimeError(f"MESS PCS capability violation in input: {mid}")
        if not (bval(mr["parked"]) and bval(mr["plugged"]) and bval(mr["grid_connected"])) or bval(mr["in_transit"]):
            raise RuntimeError(f"{mid} initial plug/parking state mismatch")
        prows = phase_by_asset.get(mid, [])
        if len(prows) != 3 or {r["phase"] for r in prows} != {"A", "B", "C"}:
            raise RuntimeError(f"MESS phase rows incomplete for {mid}")
        pp = sum(fnum(r["p_kw_grid_injection"], "MESS phase P") for r in prows)
        qq = sum(fnum(r["q_kvar_grid_injection"], "MESS phase Q") for r in prows)
        if abs(pp-p) > 2e-8 or abs(qq-qv) > 2e-8:
            raise RuntimeError(f"MESS phase conservation failed for {mid}: P={pp}, Q={qq}")
    if any(r.get("candidate_case_id") != "QSWEEP_IDC10_025" for r in remed):
        raise RuntimeError("remediation candidate case ID mismatch")

    return {
        "facility_rows": len(fac),
        "phase_rows": len(phase),
        "mess_rows": len(mess),
        "remediation_rows": len(remed),
        "facility_total_p_kw": sum(fnum(r["facility_active_power_kw"], "facility P") for r in fac),
        "facility_total_q_kvar": sum(fnum(r["facility_reactive_power_kvar"], "facility Q") for r in fac),
        "mess_total_p_kw_grid_injection": sum(fnum(r["p_kw"], "MESS P") for r in mess),
        "mess_total_q_kvar_grid_injection": sum(fnum(r["q_kvar"], "MESS Q") for r in mess),
        "selected_mess_id": "MESS03",
        "selected_location_idc_id": "IDC10",
        "selected_p_kw_grid_injection": 0.0,
        "selected_q_kvar_grid_injection": -25.0,
        "selected_opendss_load_kvar": 25.0,
        "pcs_contract": "P550_S700",
        "phase_contract": "C00/A020",
    }

def collect_voltage_rows(odd: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for bus in odd.Circuit.AllBusNames():
        odd.Circuit.SetActiveBus(bus)
        nodes = list(odd.Bus.Nodes())
        vals = list(odd.Bus.puVmagAngle())
        if len(vals) != 2 * len(nodes):
            raise RuntimeError(f"puVmagAngle length mismatch at bus {bus}")
        for i, node in enumerate(nodes):
            pu = float(vals[2*i]); angle = float(vals[2*i+1])
            if not math.isfinite(pu) or not math.isfinite(angle):
                raise RuntimeError(f"non-finite bus voltage at {bus}.{node}")
            rows.append({
                "bus": str(bus), "node": int(node), "voltage_pu": pu, "angle_deg": angle,
                "below_0p95": pu < V_MIN_PU - TOL,
                "above_1p05": pu > V_MAX_PU + TOL,
                "hard_violation": pu < V_MIN_PU - TOL or pu > V_MAX_PU + TOL,
            })
    return rows


def element_terminal_powers(odd: Any) -> list[dict[str, float]]:
    ncond = int(odd.CktElement.NumConductors())
    nterm = int(odd.CktElement.NumTerminals())
    vals = [float(x) for x in odd.CktElement.Powers()]
    expected = 2 * ncond * nterm
    if len(vals) < expected:
        raise RuntimeError(f"CktElement.Powers length {len(vals)} < expected {expected}")
    out: list[dict[str, float]] = []
    for t in range(nterm):
        p = qv = 0.0
        for c in range(ncond):
            k = 2 * (t*ncond + c)
            p += vals[k]; qv += vals[k+1]
        out.append({"terminal": float(t+1), "p_kw": p, "q_kvar": qv, "s_kva": math.hypot(p, qv)})
    return out


def collect_line_rows(odd: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    summary: list[dict[str, Any]] = []
    detail: list[dict[str, Any]] = []
    for name in odd.Lines.AllNames():
        odd.Lines.Name(name)
        norm = float(odd.Lines.NormAmps())
        ncond = int(odd.CktElement.NumConductors())
        nterm = int(odd.CktElement.NumTerminals())
        vals = [float(x) for x in odd.CktElement.CurrentsMagAng()]
        expected = 2*ncond*nterm
        if len(vals) < expected:
            raise RuntimeError(f"line current vector too short for {name}")
        mags: list[float] = []
        for t in range(nterm):
            for c in range(ncond):
                k = 2*(t*ncond+c)
                mag, angle = vals[k], vals[k+1]
                mags.append(mag)
                detail.append({"line": str(name), "terminal": t+1, "conductor": c+1, "current_a": mag, "angle_deg": angle, "norm_amps": norm, "loading_pu": mag/norm if norm > 0 else None})
        mx = max(mags) if mags else 0.0
        loading = mx/norm if norm > 0 else float("inf")
        summary.append({"line": str(name), "max_all_terminal_current_a": mx, "norm_amps": norm, "loading_pu": loading, "hard_violation": loading > LOADING_LIMIT_PU + TOL})
    return summary, detail


def collect_transformer_rows(odd: Any) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for name in odd.Transformers.AllNames():
        odd.Transformers.Name(name)
        try:
            odd.Transformers.Wdg(1)
        except Exception:
            pass
        try:
            rating = float(odd.Transformers.kVA())
        except Exception:
            rating = 0.0
        terms = element_terminal_powers(odd)
        max_s = max((t["s_kva"] for t in terms), default=0.0)
        loading = max_s/rating if rating > 0 else float("inf")
        rows.append({
            "transformer": str(name), "rating_kva_wdg1": rating,
            "max_all_terminal_s_kva": max_s, "loading_pu": loading,
            "terminal_powers_json": json.dumps(terms, ensure_ascii=False, sort_keys=True),
            "hard_violation": loading > LOADING_LIMIT_PU + TOL,
        })
    return rows


def collect_idc_pcc_rows(voltage_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    idx: dict[str, list[dict[str, Any]]] = {}
    for r in voltage_rows:
        idx.setdefault(str(r["bus"]).lower(), []).append(r)
    out: list[dict[str, Any]] = []
    for i in range(1, 13):
        idc = f"IDC{i:02d}"
        bus = f"idc_{idc.lower()}_pcc"
        rows = idx.get(bus, [])
        for r in rows:
            out.append({"idc_id": idc, "pcc_bus": bus, "node": r["node"], "voltage_pu": r["voltage_pu"], "angle_deg": r["angle_deg"], "hard_violation": r["hard_violation"]})
    return out


def collect_control_state(odd: Any) -> dict[str, Any]:
    capacitors: list[dict[str, Any]] = []
    try:
        names = list(odd.Capacitors.AllNames())
    except Exception:
        names = []
    for name in names:
        row: dict[str, Any] = {"name": str(name)}
        try:
            odd.Capacitors.Name(name)
            row["kvar"] = float(odd.Capacitors.kvar())
        except Exception as e:
            row["kvar_error"] = repr(e)
        try:
            row["states"] = [int(x) for x in odd.Capacitors.States()]
        except Exception as e:
            row["states_error"] = repr(e)
        capacitors.append(row)

    regcontrols: list[dict[str, Any]] = []
    try:
        names = list(odd.RegControls.AllNames())
    except Exception:
        names = []
    for name in names:
        row = {"name": str(name)}
        try:
            odd.RegControls.Name(name)
        except Exception:
            pass
        for key, getter in [
            ("transformer", lambda: odd.RegControls.Transformer()),
            ("winding", lambda: odd.RegControls.Winding()),
            ("tap_number", lambda: odd.RegControls.TapNumber()),
            ("vreg", lambda: odd.RegControls.ForwardVreg()),
            ("band", lambda: odd.RegControls.ForwardBand()),
        ]:
            try:
                value = getter()
                row[key] = float(value) if isinstance(value, (int, float)) else str(value)
            except Exception as e:
                row[key + "_error"] = repr(e)
        tx = row.get("transformer")
        if tx:
            try:
                odd.Transformers.Name(str(tx))
                wdg = int(float(row.get("winding", 1)))
                odd.Transformers.Wdg(wdg)
                row["transformer_tap"] = float(odd.Transformers.Tap())
            except Exception as e:
                row["transformer_tap_error"] = repr(e)
        regcontrols.append(row)
    c83 = next((r for r in capacitors if str(r.get("name", "")).lower() == "c83"), None)
    return {"capacitors": capacitors, "regcontrols": regcontrols, "c83": c83}


def write_mess_binding_audit(path: Path, mess_rows: list[dict[str, str]]) -> None:
    rows: list[dict[str, Any]] = []
    for r in mess_rows:
        p = fnum(r["p_kw"], "MESS P")
        qv = fnum(r["q_kvar"], "MESS Q")
        loc = r["location_idc_id"]
        rows.append({
            "mess_id": r["mess_id"],
            "location_idc_id": loc,
            "p_kw_grid_injection": p,
            "q_kvar_grid_injection": qv,
            "opendss_generator_kw": max(p, 0.0),
            "opendss_generator_kvar": max(qv, 0.0),
            "opendss_load_kw": max(-p, 0.0),
            "opendss_load_kvar": max(-qv, 0.0),
            "generator_element": f"Generator.MESS_DIS_{loc}",
            "load_element": f"Load.MESS_CHG_{loc}",
            "sign_contract_pass": abs(max(-qv, 0.0) - (25.0 if r["mess_id"] == "MESS03" else 0.0)) <= TOL,
        })
    write_csv(path, rows)

