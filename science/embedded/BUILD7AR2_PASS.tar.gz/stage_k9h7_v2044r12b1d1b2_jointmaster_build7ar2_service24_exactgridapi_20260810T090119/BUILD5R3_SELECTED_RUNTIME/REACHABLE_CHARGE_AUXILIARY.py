#!/usr/bin/env python3
from __future__ import annotations
import math
import numpy as np
P_MAX=550.0;S_MAX=700.0;ETA_CH=0.95;DT=5.0/60.0
def solve_reachable(connected,feeder,transformer,battery,q=None,tail_kwh=0.0):
 import gurobipy as gp
 from gurobipy import GRB
 connected=np.asarray(connected,int);feeder=np.asarray(feeder,float);transformer=np.asarray(transformer,float);battery=np.asarray(battery,float)
 if not (len(connected)==len(feeder)==len(transformer)==len(battery)):raise ValueError("length mismatch")
 q=np.zeros(len(connected)) if q is None else np.asarray(q,float)
 m=gp.Model("reachable_charge_aux");m.Params.OutputFlag=0;m.Params.Threads=1;m.Params.Seed=0;m.Params.MIPGap=0;m.Params.NumericFocus=2
 p=[]
 for t in range(len(connected)):
  pcs=min(P_MAX,math.sqrt(max(0.0,S_MAX*S_MAX-float(q[t])**2)));ub=min(pcs,float(feeder[t]),float(transformer[t])) if connected[t] else 0.0
  p.append(m.addVar(lb=0.0,ub=max(0.0,ub),name=f"pch_{t}"))
 cum=0
 for t,v in enumerate(p):
  cum=cum+ETA_CH*DT*v;m.addConstr(cum<=float(battery[t])+1e-9)
 m.setObjective(gp.quicksum(ETA_CH*DT*v for v in p)+max(0.0,float(tail_kwh)),GRB.MAXIMIZE);m.optimize()
 if m.Status!=GRB.OPTIMAL:raise RuntimeError(f"aux status {m.Status}")
 return {"reachable_charge_kWh":float(m.ObjVal),"charging_power_kW":[float(v.X) for v in p],"tail_kWh":max(0.0,float(tail_kwh))}
