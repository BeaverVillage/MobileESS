#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
MOBILITY_MAIN_SHA="1b0ac60ae49e1b4573d469e95c2b2857d17dbe64b7184bc81a28d433c02adbcc"
BANK_SHA="88cafd6cfcf94607825072bcc6b304193f23a8ebc6aeaea8a9a35e5eb958a60f"
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
 return h.hexdigest()
def find_run(base):
 hits=[]
 for d in (Path(base)/"run_packages").glob("K9H7_V2044R12B1D1B2_E4A_E4B_CONSOLIDATED_DUALHORIZON_FIX1_*"):
  p=d/"main.py"
  if p.is_file() and sha(p)==MOBILITY_MAIN_SHA:hits.append(d)
 if not hits:raise RuntimeError("exact dual-horizon runtime package unavailable")
 return sorted(hits,key=lambda x:x.stat().st_mtime,reverse=True)[0]
def load_main(root):
 sys.path.insert(0,str(root));p=root/"main.py"
 spec=importlib.util.spec_from_file_location("mobility_exact_profile_runtime",p)
 m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--base",default="/home/jaewon/mobile_ess_work")
 ap.add_argument("--bank",required=True);ap.add_argument("--level",required=True);ap.add_argument("--group",required=True)
 ap.add_argument("--safe-eta-sec",type=float,required=True);ap.add_argument("--q50-kwh",type=float,required=True)
 ap.add_argument("--safe-kwh",type=float,required=True);ap.add_argument("--out",required=True);a=ap.parse_args()
 root=find_run(a.base);fm=load_main(root);bank=Path(a.bank)
 if sha(bank)!=BANK_SHA:raise RuntimeError("E4B bank SHA drift")
 b=pd.read_parquet(bank);lc=fm.col(b,"profile_template_level","level",contains=("level",));gc=fm.col(b,"profile_template_group","group_key",contains=("group",))
 hit=b[(b[lc].astype(str)==a.level)&(b[gc].astype(str)==a.group)]
 if len(hit)!=1:raise RuntimeError(f"template key cardinality {len(hit)}")
 core,_=fm.locate_signed_core(Path(a.out).parent)
 o=fm.call_profile(core,hit.iloc[0],a.safe_eta_sec,a.q50_kwh,a.safe_kwh);q,s,p,L=fm.normalized_profile_output(o)
 np.savez_compressed(a.out,q50_net_energy_kWh=q.astype(np.float32),safe_net_energy_kWh=s.astype(np.float32),safe_depletion_prefix_kWh=p.astype(np.float32))
 print(json.dumps({"status":"PASS","length":L,"q50_sum":float(q.sum()),"safe_sum":float(s.sum()),"peak_depletion":float(np.max(p)),"future_regeneration_precredit":False},indent=2))
if __name__=="__main__":main()
