#!/usr/bin/env python3
from pathlib import Path
import ast,hashlib,json,subprocess,sys,tarfile,tempfile
ROOT=Path(__file__).resolve().parent
EXP={"base":"70dd6eb55000890f08398a80faeef3d673ca900bb196519f5753ce846c798b2b","patched":"9defcb7ea7046709424198c4cc515e90c6d44ec9c027db709cf55f0d53cc8159","failure":"2e64d87f7533fb4559b1c6c86d1f46738ac864271ffe01d1030e63fa18e7d60c","op1":"1627d752ec77bbe9d2a72ebf14cee43c104b83d11d79ccf028ad1cd72208215e"}
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
 return h.hexdigest()
def fhash(src):
 t=ast.parse(src);o={}
 for n in t.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   seg=ast.get_source_segment(src,n);o[n.name]=hashlib.sha256(seg.encode()).hexdigest()
 return o
c={}
c["base_sha"]=sha(ROOT/"BUILD4_BASE_MAIN_AUTHORITY.py")==EXP["base"]
c["patched_sha"]=sha(ROOT/"main.py")==EXP["patched"]
c["failure_sha"]=sha(ROOT/"embedded/BUILD4_FAILURE_AUTHORITY.tar.gz")==EXP["failure"]
c["op1_sha"]=sha(ROOT/"embedded/OP1R1_MAIN_AUTHORITY.py")==EXP["op1"]
with tempfile.TemporaryDirectory(prefix="b4r1rel_") as td:
 d=Path(td)
 with tarfile.open(ROOT/"embedded/BUILD4_FAILURE_AUTHORITY.tar.gz","r:gz") as tf:
  try:tf.extractall(d,filter="data")
  except TypeError:tf.extractall(d)
 ch=list(d.rglob("CHECKSUMS.sha256"));c["failure_checksum_unique"]=len(ch)==1
 if len(ch)==1:
  root=ch[0].parent;rows=0;ok=True
  for line in ch[0].read_text().splitlines():
   if not line.strip():continue
   exp,rel=line.split(None,1);p=root/rel.strip().lstrip("*");rows+=1;ok=ok and p.is_file() and sha(p)==exp
  c["failure_checksums_14of14"]=ok and rows==14
  f=json.loads((root/"_FAILURE.json").read_text())
  c["failure_semantics"]="KeyError('remaining_steps')" in f.get("error","") and "exact_commit_check" in f.get("traceback","")
# Authority API really requires remaining_steps.
osrc=(ROOT/"embedded/OP1R1_MAIN_AUTHORITY.py").read_text(encoding="utf-8")
c["exact_commit_requires_remaining_steps"]='j["remaining_steps"]' in osrc
bs=(ROOT/"BUILD4_BASE_MAIN_AUTHORITY.py").read_text(encoding="utf-8")
ps=(ROOT/"main.py").read_text(encoding="utf-8")
ast.parse(ps);c["syntax"]=True
bh=fhash(bs);ph=fhash(ps)
changed=sorted(k for k in set(bh)|set(ph) if bh.get(k)!=ph.get(k))
c["expected_function_changes"]=changed==["commitment_cert","commitment_job_view","main","prospective_rack","write_live_rolling_state"]
for tok in ["commitment_job_view","duration_steps","remaining_steps","ROLLING54_PROGRESS_LIVE.json",
            "future_plans_persisted","SOLVED_BEFORE_CERTIFICATES","FIRSTSTEP_COMMITTED"]:
 c["guard_"+tok[:30]]=tok in ps
c["new_start_is_normalized_before_commit_check"]="active[str(rr[\"rack_pool_id\"])].append(rr)" in ps
cp=subprocess.run([sys.executable,str(ROOT/"main.py"),"--self-test"],capture_output=True,text=True,check=True)
so=json.loads(cp.stdout);c["semantic_selftest"]=so.get("PASS") is True and so.get("commitment_new_start_schema_adapter") is True
c={k:bool(v) for k,v in c.items()};c["PASS"]=all(c.values())
print(json.dumps(c,indent=2,sort_keys=True))
if not c["PASS"]:raise SystemExit(2)
