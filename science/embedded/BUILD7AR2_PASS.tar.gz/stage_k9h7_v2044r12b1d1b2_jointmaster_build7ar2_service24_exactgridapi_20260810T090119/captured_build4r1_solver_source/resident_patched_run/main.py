#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,importlib.util,json,math,os,shutil,sys,tarfile,tempfile,traceback
from collections import defaultdict
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd

STAGE="V2044R12B1D1B2_JOINTMASTER_BUILD4_ROLLING54_CONSOLIDATED"
PASS="PASS_V2044R12B1D1B2_JOINTMASTER_BUILD4_54ISSUE_FUSED_FIRSTSTEP_ROLLING_CLOSED"

SHA={
 "parent":"0e80203b2f3a539ef83ec2922df2739e076e71ecdc3dcbd0f4cdc0e721dcdf71",
 "b2r1":"74b615950cdd0917364c9b2ec27b0058f6289d27e6fd14d45e7a1cbbcdc03f77",
 "op1":"1627d752ec77bbe9d2a72ebf14cee43c104b83d11d79ccf028ad1cd72208215e",
 "rack_auth":"066e90e6e19da3536acf66e906bb115a86b3b6eb498059fc9d0742ca43915dba",
 "rack_engine":"e28ebc1dc8c0fa18a67de049d7a24c119c89fefdc551888b1f86b3d9c6259d6d",
 "cr_auth":"3bac29b8ea96a28a95992a23d9bbf67aeb239fdf8ff96c29aedc878cedd7e66c",
 "grid":"89eb3d6a6e4f8f9940091410ba11fd2e27394496a8dd76a6b92f7e1350d520d4",
 "metrics":"3184fd256c50a5cd2625d2cd0346a9d3ab8d2bc7e58a34ebb5d9126caa7df007",
 "mobility_archive":"aa5ec83752514d687188deb862a5323a6081fe0dceb67e6a8775ce3a2ed61928",
 "debt_archive":"412f31a21dce9be42b59de0fd82c364d9a4df7e8d1f971ac58cdfef31771ec5a",
}
AXIS0=pd.Timestamp("2024-12-31T14:00:00Z")
AXIS_N=105120
ROLL_H=54
PUE=1.30
PF=0.95
TANPHI=math.tan(math.acos(PF))
TX_P_LIMIT=750.0*PF
MESS_P_MAX=550.0
MESS_S_MAX=700.0
E_FLOOR=440.0
E_MAX=1080.0
ETA_CH=0.95
ETA_DIS=0.95
DT_H=5.0/60.0
ROOT_BUS="150"
EPS=1e-9

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
 return h.hexdigest()

def jwrite(p:Path,o:Any):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(o,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")

def cwrite(p:Path,rows:list[dict[str,Any]]):
 p.parent.mkdir(parents=True,exist_ok=True)
 if not rows:
  p.write_text("",encoding="utf-8");return
 fields=[]
 for r in rows:
  for k in r:
   if k not in fields:fields.append(k)
 with p.open("w",encoding="utf-8",newline="") as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore");w.writeheader();w.writerows(rows)

def extract_verified(arc:Path,expected_sha:str,tmp:Path,expected_checks:int|None=None)->Path:
 if sha(arc)!=expected_sha:raise RuntimeError(f"archive SHA drift {arc.name}")
 with tarfile.open(arc,"r:gz") as tf:
  try:tf.extractall(tmp,filter="data")
  except TypeError:tf.extractall(tmp)
 ch=list(tmp.rglob("CHECKSUMS.sha256"))
 if len(ch)!=1:raise RuntimeError(f"{arc.name} CHECKSUMS count={len(ch)}")
 root=ch[0].parent;n=0
 for line in ch[0].read_text().splitlines():
  if not line.strip():continue
  exp,rel=line.split(None,1);p=root/rel.strip().lstrip("*")
  if not p.is_file() or sha(p)!=exp:raise RuntimeError(f"{arc.name} checksum mismatch {rel}")
  n+=1
 if expected_checks is not None and n!=expected_checks:raise RuntimeError(f"{arc.name} checksum rows={n}, expected={expected_checks}")
 return root

def bind_parents(pkg:Path,out:Path):
 td1=Path(tempfile.mkdtemp(prefix="b4_parent_"));r1=extract_verified(pkg/"embedded/BUILD3R2_PASS.tar.gz",SHA["parent"],td1,31)
 res=json.loads((r1/"_RESULT.json").read_text())
 if res.get("status")!="PASS_V2044R12B1D1B2_JOINTMASTER_BUILD3R2_HARDLDF_EXACTLEX_CORE_CLOSED":
  raise RuntimeError("BUILD3R2 parent status drift")
 td2=Path(tempfile.mkdtemp(prefix="b4_b2r1_"));r2=extract_verified(pkg/"embedded/BUILD2R1_ANCHORED_LDF_PASS.tar.gz",SHA["b2r1"],td2,27)
 jwrite(out/"BUILD4_PARENT_BINDING.json",{"BUILD3R2_sha256":SHA["parent"],"BUILD3R2_checksums":31,
   "BUILD2R1_sha256":SHA["b2r1"],"BUILD2R1_checksums":27,"status":"PASS"})
 return [td1,td2],r1,r2

def load_module(p:Path,name:str):
 spec=importlib.util.spec_from_file_location(name,p)
 if spec is None or spec.loader is None:raise RuntimeError(f"cannot import {p}")
 m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def preload(pkg:Path):
 for fn,key in [("OP1R1_MAIN_AUTHORITY.py","op1"),("RACK_R2R5R3_MAIN_AUTHORITY.py","rack_auth"),
  ("RACK_PILOT_ENGINE.py","rack_engine"),("CR1R2R2_WAN_AUTHORITY.py","cr_auth"),
  ("EXACT_GRID_RUNNER_AUTHORITY.py","grid"),("opendss_metrics_common.py","metrics")]:
  if sha(pkg/"embedded"/fn)!=SHA[key]:raise RuntimeError(f"embedded SHA drift {fn}")
 sys.path.insert(0,str(pkg/"embedded"))
 load_module(pkg/"embedded/RACK_PILOT_ENGINE.py","RACK_PILOT_ENGINE")
 rack=load_module(pkg/"embedded/RACK_R2R5R3_MAIN_AUTHORITY.py","rack_b4")
 op1=load_module(pkg/"embedded/OP1R1_MAIN_AUTHORITY.py","op1_b4")
 cr=load_module(pkg/"embedded/CR1R2R2_WAN_AUTHORITY.py","cr_b4")
 mp=pkg/"embedded/opendss_metrics_common.py"
 sp=importlib.util.spec_from_file_location("opendss_metrics_common",mp)
 mm=importlib.util.module_from_spec(sp);sys.modules["opendss_metrics_common"]=mm;sp.loader.exec_module(mm)
 grid=load_module(pkg/"embedded/EXACT_GRID_RUNNER_AUTHORITY.py","grid_b4")
 return rack,op1,cr,grid,mm

def find_exact_run(base:Path,pattern:str,main_sha:str)->Path:
 hits=[]
 for d in (base/"run_packages").glob(pattern):
  p=d/"main.py"
  if p.is_file():
   try:
    if sha(p)==main_sha:hits.append(d)
   except Exception:pass
 if not hits:raise RuntimeError(f"exact run package absent: {pattern}")
 return sorted(hits,key=lambda x:x.stat().st_mtime,reverse=True)[0]

def prepare_scope(base:Path,rack,op1,out:Path):
 cr_root=find_exact_run(base,"K9H7_V2044R12B1CR1R2R2_*",SHA["cr_auth"])
 rack_root=find_exact_run(base,"K9H7_V2044R12B1D1AR3R1R3R4R6R2R5R3_*",SHA["rack_auth"])
 op1.verify_runtime_files(cr_root,rack_root,out)
 tp,dp=rack.load_runtime_sources(out)
 alljobs,cohort=rack.prepare_jobs(rack_root,tp,out)
 start=int(cohort["arrival_step"].min());end=start+ROLL_H-1
 if start!=113:raise RuntimeError(f"pilot start drift {start}")
 pilot_jobs=cohort[(cohort["arrival_step"]>=start)&(cohort["arrival_step"]<=end)].copy()
 maxdur=int(max(pilot_jobs["duration_steps"].max(),1))
 max_target=AXIS0+pd.Timedelta(minutes=5*(end+maxdur+ROLL_H+5))
 loaded=rack.load_parents(rack_root,out,max_target)
 td11,td2,td4,tdb,initial,cap,wa,q50,boundary,rack_actual,inf,joint,longtail=loaded
 env=rack.Envelope(cap,wa,q50,boundary,rack_actual,inf,joint,longtail);capidx=cap.set_index("rack_pool_id")
 domains=rack.read_full_rack_domains(dp,set(pilot_jobs["job_uid"].astype(str)),set(cap["rack_pool_id"].astype(str)),out)
 inp=cr_root/"inputs"
 wan_cap=pd.read_csv(inp/"WAN_COMMON_PUBLIC_RUNTIME_FACTOR_A3.csv.gz",compression="gzip")
 if len(wan_cap)!=AXIS_N or not (wan_cap["nonlocal_pipeline_delay_steps"].astype(int)==1).all():raise RuntimeError("WAN runtime drift")
 wan_job=pd.read_parquet(inp/"JOB_DERIVED_WAN_DEMAND_NOMINAL_V2044R6.parquet",engine="pyarrow")
 wan_map=dict(zip(wan_job["job_uid"].astype(str),pd.to_numeric(wan_job["scenario_input_GB"],errors="raise").astype(float)))
 pmap={}
 for r in pilot_jobs.itertuples(index=False):
  pmap[str(r.job_uid)]={"job_uid":str(r.job_uid),"origin_IDC_id":str(r.origin_dc),
   "arrival_step":int(r.arrival_step),"latest_start_step":int(r.latest_start_step),
   "latest_completion_step_exclusive":int(r.latest_completion_step_exclusive),"duration_steps":int(r.duration_steps),
   "requested_gpu":float(r.gpus_requested),"IT_power_kW":float(r.IT_power_kW)}
 arrivals={int(k):g.copy() for k,g in pilot_jobs.groupby("arrival_step")}
 running={}
 for _,r in initial.iterrows():
  rem=int(r["remaining_duration_steps"])-start
  if rem<=0:continue
  uid=str(r["job_uid"]);running[uid]={"job_uid":uid,"state":"RUNNING","destination_IDC_id":str(r["destination_IDC_id"]),
   "rack_pool_id":str(r["rack_pool_id"]),"remaining_steps":rem,"requested_gpu":float(r["requested_gpu"]),
   "IT_power_kW":float(r["IT_power_kW"]),"source":"H6B2_OFFSET0_IMMUTABLE_DETERMINISTIC_ADVANCE"}
 d2=pd.read_parquet(inp/"MESS_ENERGY_TIMELINE_CONNECTION_DELAY_D2_V2044R8.parquet",engine="pyarrow")
 d2["slot5"]=pd.to_numeric(d2["slot5"],errors="raise").astype(int)
 for c in ["moving","plugged","connection_delay_active"]:d2[c]=d2[c].astype(bool)
 d2["connected"]=(~d2["moving"])&d2["plugged"]&(~d2["connection_delay_active"])
 s0=d2[d2["slot5"]==start].sort_values("mess_id")
 if len(s0)!=4:raise RuntimeError("D2 start cardinality")
 mess_E={str(r.mess_id):float(r.safe_energy_start_kWh) for r in s0.itertuples(index=False)}
 return {"cr_root":cr_root,"rack_root":rack_root,"start":start,"end":end,"pilot_jobs":pilot_jobs,"pmap":pmap,
  "arrivals":arrivals,"running":running,"domains":domains,"env":env,"cap":cap,"capidx":capidx,
  "wan_cap":wan_cap,"wan_map":wan_map,"inp":inp,"d2":d2,"mess_E":mess_E,"temps":[td11,td2,td4,tdb]}

def busbase(x:str)->str:return str(x).split(".")[0].strip().lower()

def build_grid_static(pkg:Path,grid,metrics,scope,b2root:Path):
 cr_root=scope["cr_root"];work=Path(tempfile.mkdtemp(prefix="b4_grid_"));paths=grid.prepare_sources(cr_root,work)
 raw_tree=pd.read_csv(b2root/"LINDISTFLOW_PLANNING_TREE.csv")
 store=grid.PowerStore(Path(paths["primary"]),Path(paths["tail"]))
 return {"work":work,"paths":paths,"raw_tree":raw_tree,"store":store}

def fixed_facility(scope,issue:int,running:dict[str,dict]):
 issue_ts=AXIS0+pd.Timedelta(minutes=5*issue);cap=scope["cap"];capidx=scope["capidx"];env=scope["env"]
 it={f"IDC{i:02d}":0.0 for i in range(1,13)}
 for rk in cap["rack_pool_id"].astype(str):
  d=str(capidx.loc[rk,"idc_id"]);_,fp=env.current_fixed(issue_ts,rk);it[d]+=float(fp)
 for j in running.values():it[str(j["destination_IDC_id"])]+=float(j["IT_power_kW"])
 return it

def reference_grid(scope,grid,metrics,gstatic,issue:int,running:dict,out:Path):
 import opendssdirect as odd
 bp,bq,pv,tns=gstatic["store"].step(issue)
 paths=gstatic["paths"];assets=Path(paths["assets"]);contract=Path(paths["contract"]);audit=[]
 odd.Basic.ClearAll();metrics.cmd(odd,f'Compile "{assets/"IEEE123Master.dss"}"',audit);metrics.cmd(odd,"MakeBusList",audit)
 metrics.cmd(odd,f'Redirect "{assets/"Generated_ThreePhase_PCC_v3.dss"}"',audit);metrics.cmd(odd,"MakeBusList",audit);metrics.cmd(odd,"CalcVoltageBases",audit)
 metrics.cmd(odd,f'Redirect "{assets/"Generated_Planning_Line_Ratings_u080.dss"}"',audit);metrics.cmd(odd,f'Redirect "{contract/"Generated_PhasePV.dss"}"',audit)
 bind=grid.apply_background(odd,bp,bq,pv,contract)
 fit=fixed_facility(scope,issue,running)
 for d in grid.IDCS:
  p=PUE*fit[d];metrics.set_named_load(odd,f"IDC_{d}",p,p*TANPHI)
 for name in list(odd.Generators.AllNames()):
  if str(name).lower().startswith("mess_dis_"):metrics.set_named_generator(odd,str(name),0.0,0.0)
 for name in list(odd.Loads.AllNames()):
  if str(name).lower().startswith("mess_chg_"):metrics.set_named_load(odd,str(name),0.0,0.0)
 metrics.cmd(odd,"Set Mode=Snapshot",audit);metrics.cmd(odd,"Set ControlMode=Static",audit)
 metrics.cmd(odd,"Set MaxControlIter=100",audit);metrics.cmd(odd,"Set MaxIterations=100",audit);metrics.cmd(odd,"Set Tolerance=0.0001",audit)
 odd.Solution.Solve()
 if not bool(odd.Solution.Converged()):raise RuntimeError(f"reference OpenDSS nonconverged issue={issue}")
 vr=metrics.collect_voltage_rows(odd);by=defaultdict(list)
 for r in vr:by[busbase(r["bus"])].append(float(r["voltage_pu"]))
 vpu={b:math.sqrt(sum(v*v for v in vals)/len(vals)) for b,vals in by.items() if vals}
 bkv={}
 for b in odd.Circuit.AllBusNames():odd.Circuit.SetActiveBus(b);bkv[busbase(b)]=float(odd.Bus.kVBase())
 idc_bus={};mess_bus={}
 for i in range(1,13):
  d=f"IDC{i:02d}";odd.Loads.Name(f"IDC_{d}");odd.Circuit.SetActiveElement(f"Load.IDC_{d}");idc_bus[d]=busbase(list(odd.CktElement.BusNames())[0])
  odd.Generators.Name(f"MESS_DIS_{d}");odd.Circuit.SetActiveElement(f"Generator.MESS_DIS_{d}");mess_bus[d]=busbase(list(odd.CktElement.BusNames())[0])
 taps={}
 for name in odd.Transformers.AllNames():
  odd.Transformers.Name(name);odd.Circuit.SetActiveElement(f"Transformer.{name}");bn=list(odd.CktElement.BusNames())
  if len(bn)<2:continue
  w=[]
  for k in range(1,int(odd.Transformers.NumWindings())+1):
   odd.Transformers.Wdg(k);w.append({"kv":float(odd.Transformers.kV()),"tap":float(odd.Transformers.Tap())})
  taps[str(name).lower()]={"bus1":busbase(bn[0]),"bus2":busbase(bn[1]),"windings":w}
 rows=[]
 for r in gstatic["raw_tree"].to_dict("records"):
  x=dict(r)
  if str(r["edge_kind"])=="TRANSFORMER_FIXED_RATIO":
   ratios=[]
   for n in [z.strip().lower() for z in str(r["members"]).split(";") if z.strip()]:
    z=taps[n];a=(z["windings"][1]["kv"]*z["windings"][1]["tap"])/(z["windings"][0]["kv"]*z["windings"][0]["tap"])
    if str(r["parent"]).lower()!=z["bus1"]:a=1.0/a
    ratios.append(a*a)
   x["ratio2_ref"]=float(sum(ratios)/len(ratios))
  else:x["ratio2_ref"]=1.0
  rows.append(x)
 return {"issue":issue,"paths":paths,"tree":pd.DataFrame(rows),"vpu":vpu,"bkv":bkv,"idc_bus":idc_bus,"mess_bus":mess_bus,
  "bind":bind,"vmin":float(min(vpu.values())),"vmax":float(max(vpu.values()))}

def conservative_fixed(op1,scope,rack,issue:int,t:int):
 issue_ts=AXIS0+pd.Timedelta(minutes=5*issue)
 return op1.conservative_fixed(scope["env"],issue_ts,t-issue,rack)

def mess_horizon(scope,issue:int):
 s=scope["d2"][(scope["d2"]["slot5"]>=issue)&(scope["d2"]["slot5"]<=issue+ROLL_H)].copy()
 if len(s)!=(ROLL_H+1)*4:raise RuntimeError(f"D2 horizon rows={len(s)} issue={issue}")
 return s

def solve_issue(scope,op1,issue:int,queue,running,inventory,dest_commit,mess_E,ref,out:Path):
 import gurobipy as gp
 from gurobipy import GRB
 jobs=sorted(queue);horizon_end=min(issue+ROLL_H-1,AXIS_N-1);pmap={j:queue[j] for j in jobs}
 choices=[];byj={j:[] for j in jobs};byjd={}
 for j in jobs:
  if issue>int(pmap[j]["latest_start_step"]):raise RuntimeError(f"deadline before solve issue={issue} job={j}")
  opts=scope["domains"][j]
  if dest_commit.get(j):opts=[o for o in opts if o["destination_IDC_id"]==dest_commit[j]]
  maxst=min(int(pmap[j]["latest_start_step"]),horizon_end,int(pmap[j]["latest_completion_step_exclusive"])-int(pmap[j]["duration_steps"]))
  for o in opts:
   for st in range(issue,maxst+1):choices.append((j,o["destination_IDC_id"],o["rack_pool_id"],st))
 m=gp.Model(f"JM_BUILD4_{issue}");m.Params.OutputFlag=0;m.Params.Threads=1;m.Params.Seed=0;m.Params.MIPGap=0;m.Params.MIPGapAbs=0
 m.Params.NumericFocus=3;m.Params.FeasibilityTol=1e-9;m.Params.IntFeasTol=1e-9;m.Params.OptimalityTol=1e-9
 x={k:m.addVar(vtype=GRB.BINARY,name=f"x_{i}") for i,k in enumerate(choices)};defer={};m.update()
 for k,v in x.items():
  j,d,r,st=k;byj[j].append(v);byjd.setdefault((j,d),[]).append(v)
 for j in jobs:
  if int(pmap[j]["latest_start_step"])<=horizon_end:
   if not byj[j]:raise RuntimeError(f"no urgent choice issue={issue} job={j}")
   m.addConstr(gp.quicksum(byj[j])==1)
  else:
   defer[j]=m.addVar(vtype=GRB.BINARY,name=f"defer_{j}");m.addConstr(gp.quicksum(byj[j])+defer[j]==1)
 maxcomp=issue
 for jj in running.values():maxcomp=max(maxcomp,issue+int(jj["remaining_steps"]))
 for j,d,r,st in choices:maxcomp=max(maxcomp,st+int(pmap[j]["duration_steps"]))
 bypool={};byidc={}
 for jj in running.values():
  r=str(jj["rack_pool_id"]);d=str(jj["destination_IDC_id"])
  for t in range(issue,issue+int(jj["remaining_steps"])):
   bypool.setdefault((r,t),[]).append((None,float(jj["requested_gpu"]),float(jj["IT_power_kW"])))
   byidc.setdefault((d,t),[]).append((None,float(jj["IT_power_kW"])))
 for (j,d,r,st),v in x.items():
  q=pmap[j]
  for t in range(st,st+int(q["duration_steps"])):
   bypool.setdefault((r,t),[]).append((v,float(q["requested_gpu"]),float(q["IT_power_kW"])))
   byidc.setdefault((d,t),[]).append((v,float(q["IT_power_kW"])))
 racks=scope["cap"]["rack_pool_id"].astype(str).tolist()
 cache={}
 def ff(r,t):
  if (r,t) not in cache:cache[(r,t)]=conservative_fixed(op1,scope,r,issue,t)
  return cache[(r,t)]
 for t in range(issue,maxcomp):
  for r in racks:
   fg,fp,_=ff(r,t);cr=scope["capidx"].loc[r];terms=bypool.get((r,t),[])
   m.addConstr(fg+sum(g for v,g,p in terms if v is None)+gp.quicksum(g*v for v,g,p in terms if v is not None)<=float(cr["deliverable_active_gpu_capacity"])+1e-9)
   m.addConstr(fp+sum(p for v,g,p in terms if v is None)+gp.quicksum(p*v for v,g,p in terms if v is not None)<=float(cr["rack_power_cap_kw"])+1e-9)
  for d in [f"IDC{i:02d}" for i in range(1,13)]:
   dr=[r for r in racks if str(scope["capidx"].loc[r,"idc_id"])==d];fit=sum(ff(r,t)[1] for r in dr);terms=byidc.get((d,t),[])
   m.addConstr(PUE*(fit+sum(p for v,p in terms if v is None)+gp.quicksum(p*v for v,p in terms if v is not None))<=TX_P_LIMIT+1e-9)
 F={};times=range(issue,horizon_end+1);widx=scope["wan_cap"].set_index("oracle_step")
 for j in jobs:
  origin=str(pmap[j]["origin_IDC_id"]);size=float(scope["wan_map"][j])
  for d in sorted({k[1] for k in choices if k[0]==j and k[1]!=origin}):
   y=gp.quicksum(byjd.get((j,d),[]));inv=float(inventory.get(j,0.0)) if dest_commit.get(j)==d else 0.0;rem=max(0.0,size-inv)
   for t in times:F[(j,d,t)]=m.addVar(lb=0.0,ub=rem,name=f"F_{j}_{d}_{t}")
   m.addConstr(gp.quicksum(F[(j,d,t)] for t in times)==rem*y)
   for (jj,dd,r,st),v in x.items():
    if jj==j and dd==d:
     usable=inv+gp.quicksum(F[(j,d,t)] for t in times if t<=st-1)
     if size>1e-12:m.addConstr(usable+1e-10>=size*v)
 for t in times:
  fs=[v for (j,d,tt),v in F.items() if tt==t]
  if fs:m.addConstr(gp.quicksum(fs)<=float(widx.loc[t,"public_path_safe_capacity_GB_per_5min"])+1e-12)
 ms=mess_horizon(scope,issue);mids=sorted(ms["mess_id"].astype(str).unique());bym={(str(r.mess_id),int(r.slot5)):r for r in ms.itertuples(index=False)}
 E={};Pdis={};Pchg={};Q={};mode={}
 for mid in mids:
  for k in range(ROLL_H+1):E[(mid,k)]=m.addVar(lb=E_FLOOR,ub=E_MAX,name=f"E_{mid}_{k}")
  m.addConstr(E[(mid,0)]==float(mess_E[mid]))
  for k in range(ROLL_H):
   rr=bym[(mid,issue+k)];active=bool(rr.connected) and k==0
   Pdis[(mid,k)]=m.addVar(lb=0,ub=MESS_P_MAX if active else 0,name=f"Pdis_{mid}_{k}")
   Pchg[(mid,k)]=m.addVar(lb=0,ub=MESS_P_MAX if active else 0,name=f"Pchg_{mid}_{k}")
   Q[(mid,k)]=m.addVar(lb=-MESS_S_MAX if active else 0,ub=MESS_S_MAX if active else 0,name=f"Q_{mid}_{k}")
   mode[(mid,k)]=m.addVar(vtype=GRB.BINARY,name=f"mode_{mid}_{k}")
   m.addConstr(Pdis[(mid,k)]<=MESS_P_MAX*mode[(mid,k)]);m.addConstr(Pchg[(mid,k)]<=MESS_P_MAX*(1-mode[(mid,k)]))
   pn=Pdis[(mid,k)]-Pchg[(mid,k)];m.addQConstr(pn*pn+Q[(mid,k)]*Q[(mid,k)]<=MESS_S_MAX*MESS_S_MAX)
   mob=float(rr.safe_energy_start_kWh)-float(bym[(mid,issue+k+1)].safe_energy_start_kWh)
   m.addConstr(E[(mid,k+1)]==E[(mid,k)]-mob-DT_H*Pdis[(mid,k)]/ETA_DIS+DT_H*ETA_CH*Pchg[(mid,k)])
 tree=ref["tree"];parent={str(r.child).lower():str(r.parent).lower() for r in tree.itertuples(index=False)};depth={ROOT_BUS:0}
 for r in sorted(tree.itertuples(index=False),key=lambda z:int(z.depth)):depth[str(r.child).lower()]=int(r.depth)
 edge={str(r["child"]).lower():r for r in tree.to_dict("records")};nodes={ROOT_BUS}|set(parent)
 ownP={n:gp.LinExpr(0) for n in nodes};ownQ={n:gp.LinExpr(0) for n in nodes}
 for (j,d,r,st),v in x.items():
  if st==issue:
   p=PUE*float(pmap[j]["IT_power_kW"]);ownP[ref["idc_bus"][d]]+=p*v;ownQ[ref["idc_bus"][d]]+=p*TANPHI*v
 for mid in mids:
  rr=bym[(mid,issue)]
  if bool(rr.connected):
   b=ref["mess_bus"][str(rr.location_service_id)];ownP[b]+=-Pdis[(mid,0)]+Pchg[(mid,0)];ownQ[b]+=-Q[(mid,0)]
 dP=dict(ownP);dQ=dict(ownQ)
 for n in sorted(nodes,key=lambda z:depth.get(z,0),reverse=True):
  if n!=ROOT_BUS:
   p=parent[n];dP[p]=dP[p]+dP[n];dQ[p]=dQ[p]+dQ[n]
 dU={ROOT_BUS:gp.LinExpr(0)}
 for n in sorted(nodes,key=lambda z:depth.get(z,0)):
  if n==ROOT_BUS:continue
  r=edge[n];p=str(r["parent"]).lower()
  dU[n]=dU[p]-0.002*(float(r["r_total_ohm"])*dP[n]+float(r["x_total_ohm"])*dQ[n]) if str(r["edge_kind"])=="LINE" else float(r["ratio2_ref"])*dU[p]
 bounds={}
 for n in sorted(nodes):
  kv=float(ref["bkv"][n]);U0=(math.sqrt(3)*kv*float(ref["vpu"][n]))**2;lo=(0.95*math.sqrt(3)*kv)**2;hi=(1.05*math.sqrt(3)*kv)**2
  ex=U0+dU[n];m.addConstr(ex>=lo,name=f"vhard_lo_{n}");m.addConstr(ex<=hi,name=f"vhard_hi_{n}");bounds[n]=(ex,kv,lo,hi)
 obj_defer=gp.quicksum(defer.values()) if defer else 0.0
 obj_wait=gp.quicksum((st-int(pmap[j]["arrival_step"]))*v for (j,d,r,st),v in x.items())
 obj_remote=gp.quicksum(v for (j,d,r,st),v in x.items() if d!=str(pmap[j]["origin_IDC_id"]))
 obj_send=gp.quicksum(F.values()) if F else 0.0
 absq=[]
 for v in Q.values():
  a=m.addVar(lb=0);m.addConstr(a>=v);m.addConstr(a>=-v);absq.append(a)
 obj_pq=gp.quicksum(Pdis.values())+gp.quicksum(Pchg.values())+0.001*gp.quicksum(absq)
 m.setObjectiveN(obj_defer,0,priority=4,abstol=0,reltol=0);m.setObjectiveN(obj_wait,1,priority=3,abstol=0,reltol=0)
 m.setObjectiveN(obj_remote,2,priority=2,abstol=0,reltol=0);m.setObjectiveN(obj_send+1e-4*obj_pq,3,priority=1,abstol=0,reltol=0)
 m.optimize()
 if m.Status!=GRB.OPTIMAL:
  try:m.computeIIS();m.write(str(out/f"IIS_ISSUE_{issue}.ilp"))
  except Exception:pass
  raise RuntimeError(f"Gurobi nonoptimal issue={issue} status={m.Status}")
 ldf=[]
 for n,(ex,kv,lo,hi) in bounds.items():
  u=float(ex.getValue());v=math.sqrt(max(u,0))/(math.sqrt(3)*kv);ldf.append({"issue_step":issue,"bus":n,"v_pu":v,"lo_headroom_U":u-lo,"hi_headroom_U":hi-u})
 if min(x["v_pu"] for x in ldf)<0.95-2e-9 or max(x["v_pu"] for x in ldf)>1.05+2e-9:raise RuntimeError(f"LDF postsolve bound fail issue={issue}")
 plan=[]
 for (j,d,r,st),v in x.items():
  if v.X>0.5:
   q=pmap[j];plan.append({"job_uid":j,"origin_IDC_id":q["origin_IDC_id"],"destination_IDC_id":d,"rack_pool_id":r,
    "start_step":int(st),"completion_step_exclusive":int(st)+int(q["duration_steps"]),"arrival_step":int(q["arrival_step"]),
    "latest_start_step":int(q["latest_start_step"]),"duration_steps":int(q["duration_steps"]),"requested_gpu":float(q["requested_gpu"]),
    "IT_power_kW":float(q["IT_power_kW"]),"input_size_GB":float(scope["wan_map"][j]),"remote":d!=q["origin_IDC_id"]})
 send_now=[{"job_uid":j,"destination_IDC_id":d,"send_GB":float(v.X)} for (j,d,t),v in F.items() if t==issue and v.X>1e-10]
 wan_all={k:float(v.X) for k,v in F.items()}
 mess=[]
 for mid in mids:
  rr=bym[(mid,issue)];mess.append({"mess_id":mid,"location_service_id":str(rr.location_service_id),"moving":bool(rr.moving),
   "connection_delay_active":bool(rr.connection_delay_active),"grid_connected":bool(rr.connected),
   "P_discharge_kW":float(Pdis[(mid,0)].X),"P_charge_kW":float(Pchg[(mid,0)].X),
   "P_net_grid_injection_kW":float(Pdis[(mid,0)].X-Pchg[(mid,0)].X),"Q_grid_injection_kvar":float(Q[(mid,0)].X),
   "E0_kWh":float(E[(mid,0)].X),"E1_kWh":float(E[(mid,1)].X)})
 return {"plan":plan,"send_now":send_now,"wan_all":wan_all,"mess":mess,"ldf":ldf,
  "objective":{"defer":float(obj_defer.getValue()) if hasattr(obj_defer,"getValue") else float(obj_defer),"wait":float(obj_wait.getValue()),
   "remote":float(obj_remote.getValue()),"send_GB":float(obj_send.getValue()) if hasattr(obj_send,"getValue") else float(obj_send)}}

def commitment_job_view(job,issue:int):
 row=dict(job)
 # exact_commit_check() consumes a current-time remaining-duration view.
 # A newly selected first-step start carries duration_steps, whereas an
 # already-running checkpoint carries remaining_steps.
 if "remaining_steps" not in row:
  if "duration_steps" not in row:
   raise RuntimeError(f"commitment job missing remaining_steps/duration_steps issue={issue} keys={sorted(row)}")
  row["remaining_steps"]=int(row["duration_steps"])
 row["remaining_steps"]=int(row["remaining_steps"])
 if row["remaining_steps"]<=0:
  raise RuntimeError(f"commitment job has nonpositive remaining_steps issue={issue} job={row.get('job_uid')}")
 for k in ["requested_gpu","IT_power_kW"]:
  if k not in row:raise RuntimeError(f"commitment job missing {k} issue={issue} job={row.get('job_uid')}")
  row[k]=float(row[k])
 return row

def prospective_rack(scope,issue,running,plan):
 active=defaultdict(list)
 for j in running.values():
  jj=commitment_job_view(j,issue);active[str(jj["rack_pool_id"])].append(jj)
 for r in plan:
  if int(r["start_step"])==issue:
   rr=commitment_job_view(r,issue);active[str(rr["rack_pool_id"])].append(rr)
 issue_ts=AXIS0+pd.Timedelta(minutes=5*issue);rows=[];ok=True
 for rk in scope["cap"]["rack_pool_id"].astype(str):
  fg,fp=scope["env"].current_fixed(issue_ts,rk);cr=scope["capidx"].loc[rk];js=active.get(rk,[])
  gh=float(cr["deliverable_active_gpu_capacity"])-(float(fg)+sum(float(j["requested_gpu"]) for j in js))
  ph=float(cr["rack_power_cap_kw"])-(float(fp)+sum(float(j["IT_power_kW"]) for j in js))
  good=gh>=-EPS and ph>=-EPS;ok&=good;rows.append({"issue_step":issue,"rack_pool_id":rk,"pass":good,"gpu_headroom":gh,"kw_headroom":ph,"job_count":len(js)})
 return ok,rows,active

def commitment_cert(scope,op1,rackmod,issue,active):
 issue_ts=AXIS0+pd.Timedelta(minutes=5*issue);rows=[];ok=True
 for rk,js0 in sorted(active.items()):
  js=[commitment_job_view(j,issue) for j in js0]
  good,a=op1.exact_commit_check(rackmod,scope["env"],scope["capidx"],issue_ts,rk,js);ok&=bool(good);rows.append({"issue_step":issue,"rack_pool_id":rk,"pass":bool(good),**a})
 return ok,rows

def wan_cert(scope,issue,sol,inventory,dest_commit):
 widx=scope["wan_cap"].set_index("oracle_step");h=min(issue+ROLL_H-1,AXIS_N-1);ok=True;rows=[]
 for r in sol["plan"]:
  if not r["remote"]:continue
  j=str(r["job_uid"]);d=str(r["destination_IDC_id"]);st=int(r["start_step"]);size=float(scope["wan_map"][j])
  inv=float(inventory.get(j,0)) if dest_commit.get(j)==d else 0.0
  sent=sum(float(sol["wan_all"].get((j,d,t),0)) for t in range(issue,h+1))
  ready=inv+sum(float(sol["wan_all"].get((j,d,t),0)) for t in range(issue,min(st-1,h)+1)) if st-1>=issue else inv
  late=sum(float(sol["wan_all"].get((j,d,t),0)) for t in range(max(issue,st),h+1))
  good=abs(inv+sent-size)<=1e-7 and ready+1e-7>=size and late<=1e-7;ok&=good
  rows.append({"issue_step":issue,"job_uid":j,"destination_IDC_id":d,"start_step":st,"required_GB":size,"inventory_before_GB":inv,
   "planned_send_GB":sent,"ready_by_start_GB":ready,"send_at_or_after_start_GB":late,"pass":good})
 for t in range(issue,h+1):
  sent=sum(v for (j,d,tt),v in sol["wan_all"].items() if tt==t);cap=float(widx.loc[t,"public_path_safe_capacity_GB_per_5min"])
  if sent>cap+1e-9:ok=False
 first_remote=[r for r in sol["plan"] if int(r["start_step"])==issue and r["remote"]]
 for r in first_remote:
  j=str(r["job_uid"]);d=str(r["destination_IDC_id"]);inv=float(inventory.get(j,0)) if dest_commit.get(j)==d else 0
  if inv+EPS<float(scope["wan_map"][j]):ok=False
 return ok,rows

def exact_candidate(scope,grid,gstatic,issue,running,plan,mess):
 fit=fixed_facility(scope,issue,running)
 for r in plan:
  if int(r["start_step"])==issue:fit[str(r["destination_IDC_id"])]+=float(r["IT_power_kW"])
 pp=[];qq=[]
 for i in range(1,13):
  p=PUE*fit[f"IDC{i:02d}"];pp.append(p);qq.append(p*TANPHI)
 ms=scope["d2"][scope["d2"]["slot5"]==issue].sort_values("mess_id");md={x["mess_id"]:x for x in mess}
 loc=[];park=[];plug=[];conn=[];trans=[];mp=[];mq=[]
 for r in ms.itertuples(index=False):
  mid=str(r.mess_id);loc.append(int(str(r.location_service_id)[-2:]));park.append(not bool(r.moving));plug.append(bool(r.plugged))
  conn.append(bool(r.connected));trans.append(bool(r.moving));mp.append(float(md[mid]["P_net_grid_injection_kW"]));mq.append(float(md[mid]["Q_grid_injection_kvar"]))
 return grid.solve_step(gstatic["paths"],issue,{"facility_p_kw":pp,"facility_q_kvar":qq,"mess_location_idc":loc,
  "mess_p_kw":mp,"mess_q_kvar":mq,"mess_parked":park,"mess_plugged":plug,"mess_grid_connected":conn,"mess_in_transit":trans})

def audit_external_authorities(base:Path,scope,out:Path):
 # Mobility archive coverage audit.
 roots=[base/"frozen_artifacts",Path("/mnt/c/Users/kjw39/Downloads"),Path("/mnt/data")]
 mob=None;debt=None
 for r in roots:
  if not r.exists():continue
  for p in r.glob("*.tar.gz"):
   try:
    h=sha(p)
    if h==SHA["mobility_archive"]:mob=p
    if h==SHA["debt_archive"]:debt=p
   except Exception:pass
 if mob:
  td=Path(tempfile.mkdtemp(prefix="b4_mob_"))
  try:
   mr=extract_verified(mob,SHA["mobility_archive"],td,42)
   q=pd.read_parquet(mr/"ARBITRARY_E4A_E4B_MOBILITY_ENERGY_INTERFACE.parquet",engine="pyarrow")
   audit={"archive_found":True,"archive_path":str(mob),"sha256":SHA["mobility_archive"],"rows":len(q),
    "origin_unique":sorted(str(x) for x in q["origin"].unique()),"origin_count":int(q["origin"].nunique()),
    "datetime_min":str(q["datetime"].min()),"datetime_max":str(q["datetime"].max()),
    "rolling_issue_specific_mobility_generation_bound":False,
    "reason":"frozen arbitrary authority contains two predeclared arbitrary origins, not a 54-issue generator for steps 113..166"}
  finally:shutil.rmtree(td,ignore_errors=True)
 else:audit={"archive_found":False,"sha256":SHA["mobility_archive"],"rolling_issue_specific_mobility_generation_bound":False}
 jwrite(out/"MOBILITY_RUNTIME_AUTHORITY_COVERAGE_AUDIT.json",audit)
 # D2 non-vacuity replay in the known movement window.
 s=scope["d2"][(scope["d2"]["slot5"]>=70704)&(scope["d2"]["slot5"]<=70757)]
 jwrite(out/"MOBILITY_D2_BRANCH_REPLAY_AUDIT.json",{"rows":len(s),"steps":54,"moving_rows":int(s["moving"].sum()),
  "connection_delay_rows":int(s["connection_delay_active"].sum()),"connected_rows":int(s["connected"].sum()),
  "P_Q_must_be_zero_when_moving_or_delay":True})
 jwrite(out/"DEBT_AUTHORITY_BINDING_AUDIT.json",{"archive_found":bool(debt),"sha256":SHA["debt_archive"],
  "natural_rolling_debt_certificate_is_zero-generation-only":True,"full_dual_debt_optimization_bound":False})
 # Strict filename/manifest census only; never activate a candidate automatically.
 cands=[]
 search_roots=[Path("/home/jaewon/mobile_ess_sumo/research_pipeline"),base/"run_packages",base/"frozen_artifacts"]
 for r in search_roots:
  if not r.exists():continue
  for pat in ["*forecast*.json","*forecast*.parquet","*prediction*.json","*prediction*.parquet"]:
   for p in list(r.rglob(pat))[:2000]:
    low=p.name.lower()
    if any(x in low for x in ["e5c","realized","actual_target","label"]):continue
    if any(x in low for x in ["demand","load","pv","price","rrp","power"]):
     cands.append({"path":str(p),"name":p.name,"sha256":sha(p) if p.stat().st_size<200_000_000 else "SKIPPED_LARGE"})
 jwrite(out/"CAUSAL_GRID_FORECAST_AUTHORITY_CENSUS.json",{"candidate_count":len(cands),"candidates":cands[:200],
  "automatically_promoted_to_authority":False,"future_horizon_grid_forecast_constraints_active":False,
  "reason":"No forecast artifact is promoted without an explicit frozen causal demand/PV/price manifest and schema contract."})
 return audit,bool(debt),len(cands)

def write_live_rolling_state(out:Path,stage:str,issue:int,queue,running,inventory,pipeline,dest_commit,mess_E,completed,extra=None):
 payload={
  "stage":stage,"issue_step":int(issue),
  "queue_jobs":len(queue),"running_jobs":len(running),"inventory_jobs":len(inventory),
  "pipeline_jobs":len(pipeline),"completed_jobs":len(completed),
  "queue_state":{str(k):str(v.get("state","")) for k,v in sorted(queue.items())},
  "running_remaining_steps":{str(k):int(v["remaining_steps"]) for k,v in sorted(running.items())},
  "inventory_GB":{str(k):float(v) for k,v in sorted(inventory.items())},
  "pipeline_GB":{str(k):float(v) for k,v in sorted(pipeline.items())},
  "destination_commit":{str(k):str(v) for k,v in sorted(dest_commit.items())},
  "mess_energy_kWh":{str(k):float(v) for k,v in sorted(mess_E.items())},
  "future_plans_persisted":False
 }
 if extra:payload["extra"]=extra
 jwrite(out/"ROLLING54_PROGRESS_LIVE.json",payload)

def main(pkg:Path,out:Path,base:Path)->int:
 out.mkdir(parents=True,exist_ok=True);temps=[];gwork=None
 try:
  tds,p3,p2=bind_parents(pkg,out);temps.extend(tds)
  rack,op1,cr,grid,metrics=preload(pkg);scope=prepare_scope(base,rack,op1,out);temps.extend(scope["temps"])
  gstatic=build_grid_static(pkg,grid,metrics,scope,p2);gwork=gstatic["work"]
  mob_a,debt_bound,forecast_candidates=audit_external_authorities(base,scope,out)
  queue={};running={k:dict(v) for k,v in scope["running"].items()};inventory={};pipeline={};dest_commit={};completed=set()
  mess_E=dict(scope["mess_E"]);starts=[];event=[];solver=[];rackcur=[];rackcom=[];wanc=[];exactrows=[];messrows=[];checkpoints=[];ldfrows=[]
  total_send=0.0;remote_starts=0
  for issue in range(scope["start"],scope["end"]+1):
   ts=AXIS0+pd.Timedelta(minutes=5*issue)
   # pipeline arrival
   for uid,amt in list(pipeline.items()):
    if amt>EPS:
     inventory[uid]=inventory.get(uid,0.0)+float(amt);event.append({"issue_step":issue,"job_uid":uid,"event":"WAN_PIPELINE_ARRIVED","GB":float(amt),"destination_IDC_id":dest_commit.get(uid)})
   pipeline={}
   if issue in scope["arrivals"]:
    for _,r in scope["arrivals"][issue].iterrows():
     uid=str(r["job_uid"]);queue[uid]={**scope["pmap"][uid],"state":"QUEUED"};inventory[uid]=0.0
     event.append({"issue_step":issue,"job_uid":uid,"event":"ACTUAL_ARRIVAL","GB":0.0,"destination_IDC_id":None})
   for uid,q in queue.items():
    d=dest_commit.get(uid)
    if d is not None and inventory.get(uid,0.0)+EPS>=scope["wan_map"][uid]:q["state"]="READY"
    elif d is not None:q["state"]="PREFETCHING"
   ref=reference_grid(scope,grid,metrics,gstatic,issue,running,out)
   sol=solve_issue(scope,op1,issue,queue,running,inventory,dest_commit,mess_E,ref,out)
   write_live_rolling_state(out,"SOLVED_BEFORE_CERTIFICATES",issue,queue,running,inventory,pipeline,dest_commit,mess_E,completed,
    {"candidate_firststep_start_count":sum(1 for r in sol["plan"] if int(r["start_step"])==issue),"candidate_send_now_count":len(sol["send_now"])})
   solver.append({"issue_step":issue,"queue_jobs":len(queue),"reference_vmin_pu":ref["vmin"],"reference_vmax_pu":ref["vmax"],**sol["objective"]})
   ldfrows.extend(sol["ldf"])
   rc,rr,active=prospective_rack(scope,issue,running,sol["plan"]);cc,crr=commitment_cert(scope,op1,rack,issue,active);wc,wr=wan_cert(scope,issue,sol,inventory,dest_commit)
   if not rc:raise RuntimeError(f"Current Rack certificate fail issue={issue}")
   if not cc:raise RuntimeError(f"Commitment Rack certificate fail issue={issue}")
   if not wc:raise RuntimeError(f"WAN certificate fail issue={issue}")
   ex=exact_candidate(scope,grid,gstatic,issue,running,sol["plan"],sol["mess"])
   jwrite(out/f"exact_grid/FRESH_EXACT_OPENDSS_ISSUE_{issue}.json",ex)
   if not ex.get("hard_constraint_pass",False):raise RuntimeError(f"Fresh OpenDSS fail issue={issue}: {ex}")
   exactrows.append({"issue_step":issue,**ex});rackcur.extend(rr);rackcom.extend(crr);wanc.extend(wr);messrows.extend([{"issue_step":issue,**x} for x in sol["mess"]])
   # Commit WAN first-step only after every gate passed.
   next_pipeline={}
   for sr in sol["send_now"]:
    uid=sr["job_uid"];d=sr["destination_IDC_id"];amt=float(sr["send_GB"])
    if dest_commit.get(uid) not in {None,d}:raise RuntimeError(f"destination mutation {uid}")
    if dest_commit.get(uid) is None:dest_commit[uid]=d;queue[uid]["state"]="PREFETCHING"
    rem=scope["wan_map"][uid]-inventory.get(uid,0)-next_pipeline.get(uid,0)
    if amt>rem+1e-7:raise RuntimeError(f"WAN oversend {uid}")
    next_pipeline[uid]=next_pipeline.get(uid,0)+amt;total_send+=amt;event.append({"issue_step":issue,"job_uid":uid,"event":"WAN_SEND_COMMIT","GB":amt,"destination_IDC_id":d})
   # Commit first-step starts.
   for r in sol["plan"]:
    if int(r["start_step"])!=issue:continue
    uid=str(r["job_uid"]);q=queue.get(uid)
    if q is None:raise RuntimeError(f"start nonqueued {uid}")
    if r["remote"]:
     if dest_commit.get(uid)!=r["destination_IDC_id"] or inventory.get(uid,0)+EPS<float(scope["wan_map"][uid]):raise RuntimeError(f"remote start before READY {uid}")
     remote_starts+=1
    running[uid]={"job_uid":uid,"state":"RUNNING","destination_IDC_id":r["destination_IDC_id"],"rack_pool_id":r["rack_pool_id"],
     "remaining_steps":int(r["duration_steps"]),"requested_gpu":float(r["requested_gpu"]),"IT_power_kW":float(r["IT_power_kW"])}
    starts.append({"issue_step":issue,**r,"start_delay_steps":issue-int(r["arrival_step"])})
    del queue[uid];event.append({"issue_step":issue,"job_uid":uid,"event":"START_RUNNING_OPERATIONAL","GB":float(inventory.get(uid,0)),"destination_IDC_id":r["destination_IDC_id"]})
    inventory.pop(uid,None);dest_commit.pop(uid,None)
   # Commit MESS first-step energy.
   for x in sol["mess"]:
    mess_E[str(x["mess_id"])]=float(x["E1_kWh"])
   # Checkpoint immutable running transition.
   prev={uid:dict(j) for uid,j in running.items()};finished=[]
   for uid,j in running.items():
    j["remaining_steps"]=int(j["remaining_steps"])-1
    if j["remaining_steps"]==0:finished.append(uid)
   for uid in finished:
    running.pop(uid);completed.add(uid);event.append({"issue_step":issue+1,"job_uid":uid,"event":"COMPLETED","GB":0.0,"destination_IDC_id":None})
   pipeline=next_pipeline
   checkpoints.append({"issue_step":issue+1,"running_jobs":len(running),"queued_jobs":len(queue),"pipeline_jobs":len(pipeline),
    **{f"{m}_E_kWh":float(e) for m,e in sorted(mess_E.items())}})
   write_live_rolling_state(out,"FIRSTSTEP_COMMITTED",issue+1,queue,running,inventory,pipeline,dest_commit,mess_E,completed,
    {"last_committed_issue":issue})
  # Materialize all 54-issue artifacts.
  cwrite(out/"ROLLING54_SOLVER_AUDIT.csv",solver);cwrite(out/"ROLLING54_FIRSTSTEP_STARTS.csv",starts);cwrite(out/"ROLLING54_EVENT_LOG.csv",event)
  cwrite(out/"ROLLING54_RACK_CURRENT_CERTIFICATE.csv",rackcur);cwrite(out/"ROLLING54_RACK_COMMITMENT_CERTIFICATE.csv",rackcom)
  cwrite(out/"ROLLING54_WAN_CERTIFICATE.csv",wanc);cwrite(out/"ROLLING54_EXACT_GRID_SUMMARY.csv",exactrows)
  cwrite(out/"ROLLING54_MESS_FIRSTSTEP_DISPATCH.csv",messrows);cwrite(out/"ROLLING54_CHECKPOINTS.csv",checkpoints)
  cwrite(out/"ROLLING54_LDF_HARD_AUDIT.csv",ldfrows)
  max_delay=max([int(x["start_delay_steps"]) for x in starts],default=0)
  support_exchange=sum(DT_H*(float(x["P_discharge_kW"])/ETA_DIS-ETA_CH*float(x["P_charge_kW"])) for x in messrows)
  debt_zero=(max_delay==0 and abs(support_exchange)<=1e-7)
  jwrite(out/"ROLLING54_NATURAL_DEBT_ZERO_CERTIFICATE.json",{
    "status":"PASS_ZERO_GENERATION" if debt_zero else "NOT_ZERO_REQUIRES_FULL_DUAL_DEBT_MODEL",
    "maximum_actual_start_delay_steps":max_delay,"net_battery_energy_change_due_to_grid_support_kWh":support_exchange,
    "workload_debt_generation_zero_certifiable":max_delay==0,
    "support_energy_debt_generation_zero_certifiable":abs(support_exchange)<=1e-7,
    "full_dual_debt_optimization_claimed":False})
  contract=json.loads((pkg/"embedded/BUILD4_CONTRACT.json").read_text())
  res={"stage":STAGE,"status":PASS,"rolling_issue_count":ROLL_H,"pilot_start_step":scope["start"],"pilot_end_step":scope["end"],
   "actual_jobs_in_window":int(len(scope["pilot_jobs"])),"actual_firststep_starts":len(starts),"completed_by_end":len(completed),
   "running_at_end":len(running),"queued_at_end":len(queue),"WAN_total_send_GB":total_send,"WAN_remote_start_count":remote_starts,
   "all_54_Current_Rack_certificates_pass":True,"all_54_Commitment_Rack_certificates_pass":True,
   "all_54_WAN_certificates_pass":True,"all_54_Fresh_Exact_OpenDSS_certificates_pass":True,
   "same_Gurobi_fused_firststep_core_reoptimized_each_issue":True,
   "MESS_shared_SOC_checkpoint_transition_closed":True,"MESS_fixed_D2_schedule_used":True,"MESS_route_reoptimized":False,
   "natural_zero_dual_debt_generation_certified":bool(debt_zero),"full_dual_debt_optimized":False,
   "causal_future_grid_forecast_candidate_count":forecast_candidates,"causal_future_grid_forecast_bound":False,
   "future_horizon_grid_forecast_constraints_active":False,"future_actual_used_for_optimizer":False,
   "B1D1B2_arbitrary_mobility_archive_found":bool(mob_a.get("archive_found")),"rolling_issue_specific_mobility_generator_bound":False,
   "one_sided_LinDistFlow_margin_calibrated":False,"full_54step_joint_master_executed":False,
   "2025_parameter_fit_used":False,"E5C_realized_used":False,"hyperparameter_retuning":False,
   "next_stage":"MOBILITY_RUNTIME_GENERATOR_PLUS_CAUSAL_GRID_FORECAST_PLUS_FULL_DUAL_DEBT",
   "contract":contract}
  jwrite(out/"_RESULT.json",res);print(json.dumps(res,ensure_ascii=False,indent=2));return 0
 except Exception as e:
  f={"stage":STAGE,"status":"FAIL_CLOSED_"+STAGE,"error":repr(e),"traceback":traceback.format_exc(),
   "2025_parameter_fit_used":False,"E5C_realized_used":False,"future_actual_used_for_optimizer":False,"hyperparameter_retuning":False}
  jwrite(out/"_FAILURE.json",f);print(json.dumps(f,ensure_ascii=False,indent=2));return 2
 finally:
  for x in temps:
   try:shutil.rmtree(x,ignore_errors=True)
   except Exception:pass
  if gwork is not None:shutil.rmtree(gwork,ignore_errors=True)

if __name__=="__main__":
 ap=argparse.ArgumentParser();ap.add_argument("--output");ap.add_argument("--base",default="/home/jaewon/mobile_ess_work");ap.add_argument("--self-test",action="store_true");a=ap.parse_args()
 if a.self_test:
  e=960-DT_H*100/ETA_DIS
  assert E_FLOOR<e<960 and abs(TANPHI-math.tan(math.acos(PF)))<1e-12
  nr=commitment_job_view({"job_uid":"NEW","duration_steps":7,"requested_gpu":2,"IT_power_kW":3.5,"rack_pool_id":"R"},113)
  rr=commitment_job_view({"job_uid":"RUN","remaining_steps":4,"requested_gpu":1,"IT_power_kW":2.0,"rack_pool_id":"R"},113)
  assert nr["remaining_steps"]==7 and rr["remaining_steps"]==4
  print(json.dumps({"PASS":True,"rolling_issues":54,"firststep_only_grid_decision":True,"future_actual_optimizer":False,
   "commitment_new_start_schema_adapter":True,"commitment_running_schema_adapter":True,
   "full_joint_master_claimed":False,"fixed_D2_scope_explicit":True},indent=2));raise SystemExit(0)
 if not a.output:raise SystemExit("--output required")
 raise SystemExit(main(Path(__file__).resolve().parent,Path(a.output),Path(a.base)))
