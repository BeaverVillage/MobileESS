BUILD4R1 — Commitment Job Schema Fix + Rolling Failure Hardening

BUILD4 entered the rolling fused solve and failed at the first commitment-Rack
certificate. The selected planning row contains duration_steps, while the
authoritative OP1R1 exact_commit_check() API requires remaining_steps because
it evaluates the prospective CURRENT commitment state.

BUILD4R1 adds an explicit schema boundary:
  planning first-step start: duration_steps -> commitment remaining_steps
  already RUNNING checkpoint: remaining_steps -> unchanged

The adapter also validates requested_gpu and IT_power_kW. commitment_cert()
normalizes defensively a second time before calling the exact authority.

No Gurobi equation, objective, threshold, OpenDSS gate, WAN chronology,
MESS SOC equation, or future-data rule is changed.

To avoid repeated blind reruns, BUILD4R1 also writes
ROLLING54_PROGRESS_LIVE.json:
- after each Gurobi candidate is solved but before certificates;
- after every fully certified first-step is committed.
It contains realized queue/RUNNING/WAN/MESS checkpoint state only and never
persists future plans.
