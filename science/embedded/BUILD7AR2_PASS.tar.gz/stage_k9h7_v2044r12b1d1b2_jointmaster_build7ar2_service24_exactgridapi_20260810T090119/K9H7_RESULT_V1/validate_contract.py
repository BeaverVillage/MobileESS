#!/usr/bin/env python3
from pathlib import Path
import ast,json
R=Path(__file__).resolve().parent
idx=json.loads((R/"K9H7_RESULT_V1_SCHEMA_INDEX.json").read_text())
assert idx["result_schema_version"]=="K9H7_RESULT_V1" and idx["table_count"]==12
for n in idx["tables"]:
 o=json.loads((R/"schemas"/f"{n}.schema.json").read_text())
 names=[x["name"] for x in o["fields"]]
 assert len(names)==len(set(names));assert set(o["required_columns"]).issubset(names)
cfg=[]
for p in sorted((R/"configs/methods").glob("*.json")):
 c=json.loads(p.read_text());cfg.append(c)
 if c["method_id"]=="B6":assert c["oracle"] and c["future_actual_optimizer"] and not c["causal_eligible"]
 else:assert not c["oracle"] and not c["future_actual_optimizer"] and c["causal_eligible"]
assert {x["method_id"] for x in cfg}=={f"B{i}" for i in range(7)}|{f"A{i}" for i in range(1,9)}
assert len(cfg)==15
for p in (R/"tools").glob("*.py"):ast.parse(p.read_text())
print(json.dumps({"PASS":True,"schema":"K9H7_RESULT_V1","tables":12,"methods":15,"oracle_firewall":"PASS","python_syntax":"PASS"},indent=2))
