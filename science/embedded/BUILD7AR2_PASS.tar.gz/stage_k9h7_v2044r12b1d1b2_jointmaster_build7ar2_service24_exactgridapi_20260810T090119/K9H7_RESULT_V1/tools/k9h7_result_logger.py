#!/usr/bin/env python3
from pathlib import Path
import json,os,uuid
import pyarrow as pa
import pyarrow.parquet as pq
SCHEMA_VERSION="K9H7_RESULT_V1"
TYPE={"string":pa.string(),"bool":pa.bool_(),"int8":pa.int8(),"int16":pa.int16(),"int32":pa.int32(),"int64":pa.int64(),"float64":pa.float64(),"timestamp[ns]":pa.timestamp("ns")}
def load_contract(root,table):
 o=json.loads((Path(root)/"schemas"/f"{table}.schema.json").read_text())
 sch=pa.schema([pa.field(x["name"],TYPE[x["type"]],nullable=True) for x in o["fields"]]);return o,sch
def validate_table(tab,root,table):
 meta,sch=load_contract(root,table);names=set(tab.column_names)
 miss=[x for x in meta["required_columns"] if x not in names]
 if miss:raise ValueError(f"{table}: required columns missing {miss}")
 unk=[x for x in tab.column_names if x not in sch.names]
 if unk:raise ValueError(f"{table}: unknown columns {unk}")
 if "result_schema_version" in names:
  vals={x.as_py() for x in tab["result_schema_version"] if x.as_py() is not None}
  if vals and vals!={SCHEMA_VERSION}:raise ValueError(f"schema version drift {vals}")
 arrays=[]
 for f in sch:
  arrays.append(tab[f.name].cast(f.type,safe=True) if f.name in names else pa.nulls(tab.num_rows,type=f.type))
 return pa.Table.from_arrays(arrays,schema=sch)
def write_atomic(tab,contract_root,result_root,table,partition_rel,basename=None):
 tab=validate_table(tab,contract_root,table);d=Path(result_root)/table/partition_rel;d.mkdir(parents=True,exist_ok=True)
 name=basename or f"part-{uuid.uuid4().hex}.parquet";tmp=d/(name+".tmp");final=d/name
 pq.write_table(tab,tmp,compression="zstd",use_dictionary=True);pq.read_schema(tmp);os.replace(tmp,final);return final
def read_method_config(root,method_id):
 return json.loads((Path(root)/"configs/methods"/f"{method_id}.json").read_text())
def assert_optimizer_information_firewall(cfg,future_actual_read):
 if future_actual_read and not (cfg.get("oracle") and cfg.get("future_actual_optimizer")):
  raise RuntimeError(f"future actual optimizer read forbidden for {cfg['method_id']}")
def assert_wan_invariants(tab):
 for c in ["same_step_send_start_violation","destination_changed_after_prefetch"]:
  if c in tab.column_names and any(v is True for v in tab[c].to_pylist()):raise RuntimeError("WAN invariant violation "+c)
