#!/usr/bin/env python3
from pathlib import Path
import json,sys
import pyarrow as pa
import pyarrow.parquet as pq
R=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
O=Path(sys.argv[2] if len(sys.argv)>2 else R/"templates").resolve();O.mkdir(parents=True,exist_ok=True)
m={"string":pa.string(),"bool":pa.bool_(),"int8":pa.int8(),"int16":pa.int16(),"int32":pa.int32(),"int64":pa.int64(),"float64":pa.float64(),"timestamp[ns]":pa.timestamp("ns")}
for p in sorted((R/"schemas").glob("*.schema.json")):
 o=json.loads(p.read_text());fields=[pa.field(x["name"],m[x["type"]],nullable=True) for x in o["fields"]]
 sch=pa.schema(fields);tab=pa.Table.from_arrays([pa.array([],type=f.type) for f in sch],schema=sch)
 pq.write_table(tab,O/f"{o['table']}.parquet",compression="zstd")
print(json.dumps({"PASS":True,"templates":len(list(O.glob('*.parquet'))),"output":str(O)},indent=2))
