# K9-H7 Experimental Comparison and Result Contract — Frozen

Main methods: B0–B6.
Ablations: A1–A8.
Result schema: K9H7_RESULT_V1.

Critical decisions:
- B1 uses the same four battery/PCS assets as B5 but fixes them at IDC01/06/10/12.
- B6 is an offline perfect-foresight oracle only; it is excluded from causal claims.
- A8 disables Fresh Exact OpenDSS only as a commit gate, not as an offline evaluator.
- Workload debt (GPUh) and support-energy debt (kWh) remain separate.
- Current Rack and commitment Rack results are logged separately.
- AUD metrics contain monetized terms only; Gurobi lexicographic objective levels remain separate.
- Forecast-vs-realized data is evaluation-only and is stored once per forecast authority.
- Statistical inference uses paired day-level blocks, not 5-minute samples as independent observations.
