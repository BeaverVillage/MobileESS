import sys,importlib.util
from pathlib import Path
SCI=Path(sys.argv[1]);OUT=Path(sys.argv[2]);WORK=Path(sys.argv[3]);OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(SCI))
spec=importlib.util.spec_from_file_location('r25m_b6r1_science',SCI/'main.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
rc=mod.rolling54_main(OUT,WORK)
raise SystemExit(int(rc))
