"""One release/source/policy/budget authority gate for every public launcher."""
import json
from pathlib import Path
import subprocess

from .a_engine import digest
from .m_engine import file_record


def checked_json(record):
    if file_record(record['path'])!=record:raise ValueError('LAUNCH_AUTHORITY_DOCUMENT_BYTES_DRIFT')
    return json.loads(Path(record['path']).read_text(encoding='utf8'))


def release_identity():
    from .table_v_campaign import executor_sources
    root=Path(__file__).resolve().parents[1]
    records=executor_sources()
    revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    return dict(release_sha=digest(records),release_sources=records,release_git_sha=revision)


def validate_launch_identity(plan,gate):
    """No boolean or CLI scope can mint authority for a changed release."""
    from .table_v_budget import require_authorization
    from .table_v_flex_planning import require_flex_case
    scope=plan.get('execution_scope')
    if scope=='PREPARED_ONLY':raise PermissionError('PREPARED_ONLY_NO_HEAVY_LAUNCH')
    if scope not in ('MAY01_VALIDATION','MAY31_APPROVED'):
        raise PermissionError('EXPLICIT_TABLE_V_EXECUTION_SCOPE_REQUIRED')
    current=release_identity()
    if any(plan.get(k)!=v for k,v in current.items()):
        raise PermissionError('CURRENT_RELEASE_SOURCE_OR_GIT_SHA_REQUIRED')
    approval=checked_json(gate['launch_authorization'])
    if (approval.get('schema')!='TABLE_V_EXPLICIT_RELEASE_LAUNCH_APPROVAL_V1'
            or approval.get('approved') is not True or not approval.get('human_approval_reference')
            or approval.get('approved_plan_sha')!=digest(plan) or approval.get('dates')!=plan['dates']
            or approval.get('execution_scope')!=scope or approval.get('approved_release_sha')!=current['release_sha']
            or approval.get('approved_release_git_sha')!=current['release_git_sha']
            or approval.get('approved_policy_bindings_sha')!=digest(plan.get('policy_bindings'))
            or approval.get('approved_budget_bindings_sha')!=digest(plan.get('budget_authorizations'))):
        raise PermissionError('EXACT_RELEASE_POLICY_BUDGET_AND_HUMAN_LAUNCH_APPROVAL_REQUIRED')
    if scope=='MAY01_VALIDATION' and plan['dates']!=['2025-05-01']:
        raise PermissionError('MAY01_VALIDATION_CANNOT_LAUNCH_OTHER_DATES')
    for day in plan['dates']:
        root=Path(plan['execution_roots'][day]).resolve()
        manifest=require_flex_case(json.loads((root/'INPUTS/FULL_FLEX/TABLE_V_FLEX_CASE_MANIFEST.json').read_text(encoding='utf8')))
        expected=dict(day=day,source_sha=manifest['source_sha'],source_identity=manifest['identity'])
        policy=json.loads((root/'INPUTS/FULL_FLEX/TABLE_V_FLEXIBILITY_POLICY_FREEZE.json').read_text(encoding='utf8'))['spec']
        if (manifest['day']!=day or plan['case_bindings'].get(day)!=expected
                or policy!=manifest['science_derivation']['policy']
                or plan['policy_bindings'].get(day)!=digest(policy)):
            raise PermissionError('CURRENT_DATE_SCIENCE_CASE_SOURCE_POLICY_SHA_REQUIRED')
        for kind in ('PLANNING','K48'):
            record=plan['budget_authorizations'][day][kind]
            if Path(record['path']).resolve()!=root/(kind+'_AUTHORIZATION.json'):
                raise PermissionError('ONE_EXACT_DATE_BUDGET_AUTHORIZATION_DOCUMENT_REQUIRED')
            authority=require_authorization(checked_json(record))
            ledger_path=root/(kind+'_NATIVE_LEDGER.json')
            if (Path(authority['authorized_ledger_path']).resolve()!=ledger_path
                    or authority['source_cases']!=[expected]):
                raise PermissionError('CURRENT_DATE_APPROVED_BUDGET_SOURCE_CASE_REQUIRED')
            ledger=json.loads(ledger_path.read_text(encoding='utf8'))
            if (ledger.get('authorization_document')!=authority
                    or ledger.get('release_identity',{}).get('authorization_sha')!=digest(authority)
                    or ledger.get('inflight') is not None or ledger.get('active_stage_context') is not None):
                raise PermissionError('CURRENT_BUDGET_AUTHORITY_OR_UNRECONCILED_NATIVE_STATE')
    return approval
