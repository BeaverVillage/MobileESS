# Table V 날짜별 Native0 생산 바인딩 감사

상태: NOT_CERTIFIED_NATIVE0_MONTH. 31일 × 4 Arm = 124 Case를 기록했고 날짜별 PASS 31, 미인증 0일이다. 실제 날짜별 compiler와 E1/FLEX30 compiler를 사용해 독립 준비하고 production dispatch 바인딩을 검사했다. May02·May10·May12는 날짜·초기상태·Native 원본·CC4·Typed Input SHA를 개별 기록했다. 96슬롯·원본 물리권한·R1·R2 HOLD·P2 0회가 유지된다.

Native/model build/geometry/Actual/AC/미래 실현정보 parsing은 모두 0회다. 원본 source receipt의 SHA 확인은 ACTUAL bundle·raw archive byte hashing을 포함하며, 미래 정보 사용과 구분했다. 계획 범위는 PREPARED_ONLY이며, 이 감사가 May02–31 자동 실행이나 예산 추가를 허용하지 않는다.
