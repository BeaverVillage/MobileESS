"""Table V prepare/serial arm command. No automatic retry or overwrite."""
from pathlib import Path
import argparse
import sys

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from v42_integration.table_v_run import DEFAULT,prepare,run_arm

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('operation',choices=['prepare','B0','B1','B2','B3'])
    p.add_argument('--output',type=Path,default=DEFAULT)
    p.add_argument('--attempt',default=None)
    p.add_argument('--carry-forward-native-ledger',type=Path,action='append',default=[])
    a=p.parse_args()
    result=prepare(a.output,carry_forward_native_ledgers=a.carry_forward_native_ledger) if a.operation=='prepare' else run_arm(a.operation,a.output,attempt=a.attempt)
    print('PREPARED' if a.operation=='prepare' else {k:result.get(k) for k in ('arm','status','failed_stage','error','wall_seconds')},flush=True)
