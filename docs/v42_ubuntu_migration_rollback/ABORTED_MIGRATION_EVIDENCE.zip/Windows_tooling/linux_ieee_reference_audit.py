"""Native Linux content-reference audit (rg unavailable); originals retained in place."""
import os,re,csv,json,hashlib,shutil,subprocess
from pathlib import Path
H=Path.home();O=H/'mobileess_worktrees/root_lp_compression/docs/v42_ubuntu_gpu_migration';D=H/'mobileess_research/IEEE8500';rx=re.compile(r'ieee[_-]?8500|8500[-_ ]?node',re.I)
rows=list(csv.DictReader((O/'IEEE8500_FILE_MANIFEST.csv').open()));new=[];matches=[];seen={r['original'] for r in rows}
roots=[H/'mobile_ess_work',H/'mobile_ess_tools',H/'codex_mobileess_workspace']
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for root in roots:
    for folder,dirs,files in os.walk(root,followlinks=False):
        dirs[:]=[n for n in dirs if n not in ('.git','__pycache__','site-packages','v42_ubuntu_gpu_migration','frozen_artifacts','raw_data','datasets','outputs','results') and not (Path(folder)/n).is_symlink()]
        for n in files:
            p=Path(folder)/n;lower=n.lower()
            if not (p.suffix.lower() in ('.py','.md','.ps1','.sh','.r','.toml','.yaml','.yml','.ini','.ipynb') or (p.suffix=='.json' and ('manifest' in lower or 'config' in lower))):continue
            if not p.is_file() or p.stat().st_size>16*1024**2:continue
            if not rx.search(p.read_text(encoding='utf8',errors='replace')):continue
            matches.append(str(p))
            if str(p) in seen:continue
            digest=sha(p);obj=D/'objects'/digest[:2]/digest;obj.parent.mkdir(exist_ok=True)
            if not obj.exists():shutil.copy2(p,obj)
            assert obj.stat().st_size==p.stat().st_size and sha(obj)==digest
            link=D/'linux_content_references'/root.name/p.relative_to(root);link.parent.mkdir(parents=True,exist_ok=True)
            if not link.exists():link.symlink_to(obj)
            info=subprocess.run(['git','rev-parse','--show-toplevel'],cwd=p.parent,capture_output=True,text=True);repo=info.stdout.strip() if info.returncode==0 else ''
            head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() if repo else ''
            tracked=bool(repo and subprocess.run(['git','ls-files','--error-unmatch',str(p.relative_to(repo))],cwd=repo,capture_output=True).returncode==0)
            new.append(dict(original=str(p),bytes=p.stat().st_size,sha256=digest,git_tracked=tracked,destination=str(link),preservation_status='LINUX_CONTENT_REFERENCE_HASH_VERIFIED',git_repository=repo,git_HEAD=head,ubuntu_sha256=digest,hash_pass=True))
rows+=new
with (O/'IEEE8500_FILE_MANIFEST.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
receipt=json.loads((O/'IEEE8500_PRESERVATION_MANIFEST.json').read_text());objects={r['sha256']:int(r['bytes']) for r in rows}
receipt.update(files=len(rows),local_only_files=sum(str(r['git_tracked'])=='False' for r in rows),unique_sha256_objects=len(objects),total_logical_bytes=sum(int(r['bytes']) for r in rows),unique_verified_object_bytes=sum(objects.values()),additional_Linux_content_reference_files=len(new),existing_Linux_content_reference_search_complete=True)
(O/'IEEE8500_PRESERVATION_MANIFEST.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
(O/'IEEE8500_LINUX_REFERENCE_SEARCH.json').write_text(json.dumps(dict(roots=list(map(str,roots)),matches=matches,additional_files=len(new),source_mutations=0,search='rg not installed in distro; targeted Python content scan of scripts/configs/docs <=16MiB, excludes libraries, generated migration docs and bulk frozen/raw/output/result trees; bulk research trees were separately traversed in the complete existing-Linux path inventory and retained in place',all_originals_retained=True),ensure_ascii=False,indent=2)+'\n')
print('LINUX_REFERENCE_AUDIT',len(matches),'ADDITIONAL_PRESERVED',len(new),flush=True)
