"""Resolve scanner self-reference separately from protected research; never deletes a file."""
import csv,json
from pathlib import Path
H=Path.home();O=H/'mobileess_worktrees/root_lp_compression/docs/v42_ubuntu_gpu_migration'
p=O/'IEEE8500_FILE_MANIFEST.csv';rows=list(csv.DictReader(p.open()))
tooling=[r for r in rows if '/v42_root_lp_compression_pr/docs/v42_ubuntu_gpu_migration/' in r['original'].replace('\\','/')]
assert len(tooling)==3 and {Path(r['original'].replace('\\','/')).name for r in tooling}=={'IEEE8500_FILE_MANIFEST.csv','preserve_ieee8500.py','WINDOWS_IEEE8500_REFS.json'}
research=[r for r in rows if r not in tooling]
assert all(r['hash_pass']=='True' for r in research),[r for r in research if r['hash_pass']!='True']
with p.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(research)
receipt=json.loads((O/'IEEE8500_PRESERVATION_MANIFEST.json').read_text())
objects={r['sha256']:int(r['bytes']) for r in research}
receipt.update(IEEE8500_PRESERVED=True,IEEE8500_UNRESOLVED_FILES=0,files=len(research),local_only_files=sum(r['git_tracked']=='False' for r in research),unique_sha256_objects=len(objects),total_logical_bytes=sum(int(r['bytes']) for r in research),unique_verified_object_bytes=sum(objects.values()),errors=[],scanner_generated_tool_artifacts_excluded=3,initial_discovered_paths=len(rows),initial_copy_errors_preserved=receipt['errors'],research_only_scope='Exclude only the three migration-tool artifacts created by this task, including scanner self-referential manifest; no research file omitted. All Windows originals, Linux copies and Git tooling evidence retained.')
(O/'IEEE8500_SCAN_EXCLUSIONS.json').write_text(json.dumps(dict(reason='Three generated migration tooling files are not pre-existing IEEE8500 research. A live SHA manifest cannot validate a historical hash of itself after appending/classifying its rows.',rows=tooling,source_or_destination_deleted=False,excluded_files_preserved='Windows originals retained; stable tools/Git reference and final manifest committed in canonical Git'),ensure_ascii=False,indent=2)+'\n')
(O/'IEEE8500_PRESERVATION_MANIFEST.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False),flush=True)
