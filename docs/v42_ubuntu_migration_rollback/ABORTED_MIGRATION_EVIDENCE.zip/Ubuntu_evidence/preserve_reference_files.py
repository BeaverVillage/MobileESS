"""Protect content-reference files too, including untracked generic script names."""
import csv,json,hashlib,shutil
from pathlib import Path
H=Path.home();O=H/'mobileess_worktrees/root_lp_compression/docs/v42_ubuntu_gpu_migration';W=Path('/mnt/d/ChatGPT/Mobile ESS 2/v42_root_lp_compression_pr/docs/v42_ubuntu_gpu_migration');D=H/'mobileess_research/IEEE8500'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
research=list(csv.DictReader((O/'IEEE8500_FILE_MANIFEST.csv').open()));seen={r['original'] for r in research}
refs=list(csv.DictReader((W/'IEEE8500_CONTENT_REFERENCE_MANIFEST.csv').open()));new=[]
for r in refs:
    if r['original'] in seen:continue
    s=r['original'].replace('\\','/');source=Path('/mnt/'+s[0].lower()+s[2:]);obj=D/'objects'/r['sha256'][:2]/r['sha256'];obj.parent.mkdir(exist_ok=True)
    if not obj.exists():shutil.copy2(source,obj)
    assert sha(obj)==r['sha256'] and obj.stat().st_size==int(r['bytes']),r
    link=D/'windows'/s.replace(':','');link.parent.mkdir(parents=True,exist_ok=True)
    if not link.exists():link.symlink_to(obj)
    new.append(dict(original=r['original'],bytes=r['bytes'],sha256=r['sha256'],git_tracked=r['git_tracked'],destination=str(link),preservation_status='LINUX_HASH_SIZE_VERIFIED_CONTENT_REFERENCE',git_repository=r['git_repository'],git_HEAD=r['git_HEAD'],ubuntu_sha256=r['sha256'],hash_pass=True))
research+=new
with (O/'IEEE8500_FILE_MANIFEST.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(research[0]));w.writeheader();w.writerows(research)
for n in ('IEEE8500_CONTENT_REFERENCE_MANIFEST.csv','IEEE8500_REFERENCE_GIT_STATES.json','IEEE8500_REFERENCE_SEARCH.json'):shutil.copy2(W/n,O/n)
receipt=json.loads((O/'IEEE8500_PRESERVATION_MANIFEST.json').read_text());objects={r['sha256']:int(r['bytes']) for r in research}
receipt.update(files=len(research),filename_path_based_research_files=len(research)-len(new),additional_content_reference_files=len(new),local_only_files=sum(r['git_tracked']=='False' for r in research),unique_sha256_objects=len(objects),total_logical_bytes=sum(int(r['bytes']) for r in research),unique_verified_object_bytes=sum(objects.values()),content_reference_search_complete=True)
(O/'IEEE8500_PRESERVATION_MANIFEST.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print('ADDITIONAL_REFERENCE_FILES_PRESERVED',len(new),flush=True)
