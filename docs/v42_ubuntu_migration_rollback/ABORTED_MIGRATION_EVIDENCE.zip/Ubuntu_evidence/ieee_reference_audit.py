"""Read-only H audit of scripts/configs/docs mentioning IEEE8500; no disk-wide search."""
import subprocess,csv,json,hashlib,shutil
from pathlib import Path
O=Path(__file__).absolute().parent;roots=json.loads((O/'IEEE8500_WINDOWS_SCAN_RECEIPT.json').read_text(encoding='utf8'))['roots']
cmd=[shutil.which('rg'),'-l','-i','--hidden']
for g in ('*.py','*.ps1','*.md','*.toml','*.yaml','*.yml','*.ini','*.sh','*.r','*.ipynb','*manifest*.json','*config*.json','!**/.git/**','!**/Lib/**','!**/site-packages/**','!**/__pycache__/**','!**/v42_ubuntu_gpu_migration/**'):
    cmd+=['--iglob',g]
r=subprocess.run(cmd+['ieee[_-]?8500|8500[-_ ]?node',*roots],capture_output=True,text=True,encoding='utf8',errors='replace')
assert r.returncode in (0,1),(r.returncode,r.stderr)
rows=[];states={};git_errors=[]
def git(p,*a):
    result=subprocess.run(['git','-C',str(p),*a],capture_output=True,text=True,encoding='utf8',errors='replace')
    if result.returncode:git_errors.append(dict(path=str(p),command=list(a),error=result.stderr))
    return result.stdout.strip() if result.returncode==0 else ''
for s in sorted(set(r.stdout.splitlines())):
    p=Path(s);repo=next((x for x in p.parents if (x/'.git').exists()),None)
    if repo and str(repo) not in states:
        states[str(repo)]=dict(HEAD=git(repo,'rev-parse','HEAD'),branch=git(repo,'branch','--show-current'),tracked=git(repo,'ls-files').splitlines(),status=git(repo,'status','--porcelain'),diff=git(repo,'diff'),cached_diff=git(repo,'diff','--cached'))
    with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    tracked=bool(repo and p.relative_to(repo).as_posix() in states[str(repo)]['tracked'])
    rows.append(dict(original=str(p),bytes=p.stat().st_size,sha256=digest,git_tracked=tracked,git_repository=str(repo) if repo else '',git_HEAD=states[str(repo)]['HEAD'] if repo else ''))
with (O/'IEEE8500_CONTENT_REFERENCE_MANIFEST.csv').open('w',encoding='utf8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['original','bytes','sha256','git_tracked','git_repository','git_HEAD']);w.writeheader();w.writerows(rows)
(O/'IEEE8500_REFERENCE_GIT_STATES.json').write_text(json.dumps(states,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(O/'IEEE8500_REFERENCE_SEARCH.json').write_text(json.dumps(dict(files=len(rows),roots=roots,rg_stderr=r.stderr,Git_metadata_errors=git_errors,Git_metadata_error_disposition='Original directories retained; matching file bytes copied and hashed independently of invalid Git metadata; none are safe-delete targets.',scope='Targeted source/config/document content, excluded generated migration tooling and environment libraries',candidate_V42_mentions_reviewed='Only explicit non-run flags, network rejection tests and scope exclusions in job-capability/exact worktrees; no IEEE8500 data path/research ownership. Reference-episode worktree has no match.'),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('IEEE_REFERENCE_AUDIT',len(rows),'Git_states',len(states),flush=True)
